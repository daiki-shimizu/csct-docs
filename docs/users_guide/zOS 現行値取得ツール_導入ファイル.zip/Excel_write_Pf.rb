#! ruby -Ku
require 'win32ole'

require_relative 'lib/zos_ftp'
require_relative 'lib/zos_function'
Dir[File.expand_path('..', __FILE__) << '/lib/*.rb'].each do |library|
  require library
end
include ZOS_FTP, ZOS_function

def get_absolute_path(path)
  WIN32OLE.new('Scripting.FileSystemObject').GetAbsolutePathName(path)
end

ZOS_function.directory_path = ARGV.empty? ? 'SAMPLE' : ARGV[0]
template_filename =
  get_absolute_path(ZOS_FTP.absolute_path('zOS_pf(full).xls'))
output_filename = get_absolute_path(add_path('new_form.xls'))
ZOS_FTP.log_initialize

def current_value_changed(current_value_cell, current_sheet, *_args)
  return unless current_value_cell.Column == 34

  specified_value_cell = current_value_cell.Next
  if current_value_cell.Value == non_supported_message
    specified_value_cell.Value = required_message
  else
    specified_value_cell.Value = current_value_cell.Value
    if current_value_cell.Value.split.collect(&:size).max > @column_max_length
      @column_max_length = current_value_cell.Value.split.collect(&:size).max
      current_sheet.Activate
      current_sheet.Columns('AH:AI').ColumnWidth = @column_max_length * 34 / 28
    end
  end
end

excel = WIN32OLE.new('Excel.Application')
begin
  WIN32OLE.const_load(excel)
  excel.WindowState = WIN32OLE::XlMaximized
  excel.Visible = true
  workbook = excel.Workbooks.Open(template_filename, true)

  event = WIN32OLE_EVENT.new(workbook, 'WorkbookEvents')
  event.on_event('SheetChange') do |*args|
    current_value_changed(*args)
  end

  # 1-1 基本導入パラメーター
  worksheet = workbook.Worksheets(4)
  worksheet.Activate
  excel.ActiveWindow.ScrollRow = 8
  @column_max_length = 25

  # 1-1-1 DASD構成
  worksheet.Cells.Item(11, 34).Value = non_supported_message
  worksheet.Cells.Item(12, 34).Value = non_supported_message
  worksheet.Cells.Item(13, 34).Value = non_supported_message
  worksheet.Cells.Item(14, 34).Value = non_supported_message
  worksheet.Cells.Item(15, 34).Value = non_supported_message
  worksheet.Cells.Item(16, 34).Value = non_supported_message

  worksheet.Cells.Item(17, 34).Value = non_supported_message
  worksheet.Cells.Item(18, 34).Value = non_supported_message
  worksheet.Cells.Item(19, 34).Value = non_supported_message

  worksheet.Cells.Item(20, 34).Value = non_supported_message
  worksheet.Cells.Item(21, 34).Value = non_supported_message
  worksheet.Cells.Item(22, 34).Value = non_supported_message

  worksheet.Cells.Item(23, 34).Value = non_supported_message
  worksheet.Cells.Item(24, 34).Value = non_supported_message
  worksheet.Cells.Item(25, 34).Value = non_supported_message

  worksheet.Cells.Item(26, 34).Value = non_supported_message
  worksheet.Cells.Item(27, 34).Value = non_supported_message
  worksheet.Cells.Item(28, 34).Value = non_supported_message

  worksheet.Cells.Item(29, 34).Value = non_supported_message
  worksheet.Cells.Item(30, 34).Value = non_supported_message
  worksheet.Cells.Item(31, 34).Value = non_supported_message

  worksheet.Cells.Item(32, 34).Value = non_supported_message
  worksheet.Cells.Item(33, 34).Value = non_supported_message
  worksheet.Cells.Item(34, 34).Value = non_supported_message

  worksheet.Cells.Item(35, 34).Value = non_supported_message
  worksheet.Cells.Item(36, 34).Value = non_supported_message
  worksheet.Cells.Item(37, 34).Value = non_supported_message

  worksheet.Cells.Item(38, 34).Value = non_supported_message
  worksheet.Cells.Item(39, 34).Value = non_supported_message
  worksheet.Cells.Item(40, 34).Value = non_supported_message

  worksheet.Cells.Item(41, 34).Value = non_supported_message
  worksheet.Cells.Item(42, 34).Value = non_supported_message
  worksheet.Cells.Item(43, 34).Value = non_supported_message

  worksheet.Cells.Item(44, 34).Value = non_supported_message
  worksheet.Cells.Item(45, 34).Value = non_supported_message
  worksheet.Cells.Item(46, 34).Value = non_supported_message

  worksheet.Cells.Item(47, 34).Value = non_supported_message
  worksheet.Cells.Item(48, 34).Value = non_supported_message
  worksheet.Cells.Item(49, 34).Value = non_supported_message

  worksheet.Cells.Item(50, 34).Value = non_supported_message
  worksheet.Cells.Item(51, 34).Value = non_supported_message
  worksheet.Cells.Item(52, 34).Value = non_supported_message

  worksheet.Cells.Item(53, 34).Value = non_supported_message
  worksheet.Cells.Item(54, 34).Value = non_supported_message
  worksheet.Cells.Item(55, 34).Value = non_supported_message

  worksheet.Cells.Item(56, 34).Value = non_supported_message
  worksheet.Cells.Item(57, 34).Value = non_supported_message
  worksheet.Cells.Item(58, 34).Value = non_supported_message

  worksheet.Cells.Item(59, 34).Value = non_supported_message
  worksheet.Cells.Item(60, 34).Value = non_supported_message
  worksheet.Cells.Item(61, 34).Value = non_supported_message

  worksheet.Cells.Item(62, 34).Value = non_supported_message

  # 1-1-2 端末構成
  excel.ActiveWindow.ScrollRow = 35
  worksheet.Cells.Item(68, 34).Value = CONSOLxx.master_addr.join
  worksheet.Cells.Item(69, 34).Value = CONSOLxx.master_name.join
  worksheet.Cells.Item(70, 34).Value = CONSOLxx.sub_addr.join
  worksheet.Cells.Item(71, 34).Value = CONSOLxx.sub_name.join
  worksheet.Cells.Item(72, 34).Value = non_supported_message
  worksheet.Cells.Item(73, 34).Value = non_supported_message
  worksheet.Cells.Item(74, 34).Value = non_supported_message
  worksheet.Cells.Item(75, 34).Value = non_supported_message

  # 1-1-3 基本構成
  excel.ActiveWindow.ScrollRow = 48
  worksheet.Cells.Item(81, 34).Value = IEASYSxx.system_name
  worksheet.Cells.Item(82, 34).Value = SMFPRMxx.sid
  worksheet.Cells.Item(83, 34).Value = LOADxx.sysplex_name
  worksheet.Cells.Item(84, 34).Value = CLOCKxx.timezone
  worksheet.Cells.Item(85, 34).Value = CLOCKxx.stpmode

  # 1-1-4 カタログ構成
  excel.ActiveWindow.ScrollRow = 58
  worksheet.Cells.Item(91, 34).Value = LOADxx.syscat_dsn
  worksheet.Cells.Item(92, 34).Value = LOADxx.syscat_volume
  worksheet.Cells.Item(93, 34).Value = LOADxx.mcat_size
  worksheet.Cells.Item(94, 34).Value = non_supported_message
  worksheet.Cells.Item(95, 34).Value = non_supported_message
  worksheet.Cells.Item(96, 34).Value = non_supported_message
  worksheet.Cells.Item(97, 34).Value = non_supported_message
  worksheet.Cells.Item(98, 34).Value = non_supported_message
  worksheet.Cells.Item(99, 34).Value = non_supported_message
  worksheet.Cells.Item(100, 34).Value = non_supported_message
  worksheet.Cells.Item(101, 34).Value = non_supported_message
  worksheet.Cells.Item(102, 34).Value = non_supported_message
  worksheet.Cells.Item(103, 34).Value = non_supported_message
  worksheet.Cells.Item(104, 34).Value = non_supported_message
  worksheet.Cells.Item(105, 34).Value = non_supported_message

  # 1-1-5 システム・データセット構成
  excel.ActiveWindow.ScrollRow = 78

  # 1 UADS
  worksheet.Cells.Item(111, 34).Value = UADS.datasets
  worksheet.Cells.Item(112, 34).Value = UADS.volumes
  worksheet.Cells.Item(113, 34).Value = UADS.size

  # 2 BRODCAST
  worksheet.Cells.Item(114, 34).Value = BRODCAST.datasets
  worksheet.Cells.Item(115, 34).Value = BRODCAST.volumes
  worksheet.Cells.Item(116, 34).Value = BRODCAST.size

  # 3～5 SYS1.DUMPxx
  worksheet.Cells.Item(117, 34).Value = DUMP.datasets[0]
  worksheet.Cells.Item(118, 34).Value = DUMP.volumes[0]
  worksheet.Cells.Item(119, 34).Value = DUMP.size[0] || undefined_message

  worksheet.Cells.Item(120, 34).Value = DUMP.datasets[1] || undefined_message
  worksheet.Cells.Item(121, 34).Value = DUMP.volumes[1] || undefined_message
  worksheet.Cells.Item(122, 34).Value = DUMP.size[1] || undefined_message

  worksheet.Cells.Item(123, 34).Value = DUMP.datasets[2] || undefined_message
  worksheet.Cells.Item(124, 34).Value = DUMP.volumes[2] || undefined_message
  worksheet.Cells.Item(125, 34).Value = DUMP.size[2] || undefined_message

  # 6～8 SYS1.MANx
  worksheet.Cells.Item(126, 34).Value = SMF.smf_datasets[0]
  worksheet.Cells.Item(127, 34).Value = SMF.volumes[0]
  worksheet.Cells.Item(128, 34).Value = SMF.size[0]
  worksheet.Cells.Item(129, 34).Value = SMF.smf_datasets[1]
  worksheet.Cells.Item(130, 34).Value = SMF.volumes[1]
  worksheet.Cells.Item(131, 34).Value = SMF.size[1]
  worksheet.Cells.Item(132, 34).Value = SMF.smf_datasets[2]
  worksheet.Cells.Item(133, 34).Value = SMF.volumes[2]
  worksheet.Cells.Item(134, 34).Value = SMF.size[2]

  # 9 LOGREC
  worksheet.Cells.Item(135, 34).Value = LOGREC.datasets
  worksheet.Cells.Item(136, 34).Value = LOGREC.volumes
  worksheet.Cells.Item(137, 34).Value = LOGREC.size

  # 10 STGINDEX
  excel.ActiveWindow.ScrollRow = 138
  worksheet.Cells.Item(138, 34).Value = non_supported_message
  worksheet.Cells.Item(139, 34).Value = STGINDEX.datasets
  worksheet.Cells.Item(140, 34).Value = STGINDEX.volumes
  worksheet.Cells.Item(141, 34).Value = STGINDEX.size

  # 11 HASPACE
  worksheet.Cells.Item(142, 34).Value = HASPACE.datasets
  worksheet.Cells.Item(143, 34).Value = HASPACE.volumes
  worksheet.Cells.Item(144, 34).Value = HASPACE.size

  # 12 HASPCKPT
  worksheet.Cells.Item(145, 34).Value = HASPCKPT.datasets
  worksheet.Cells.Item(146, 34).Value = HASPCKPT.volumes
  worksheet.Cells.Item(147, 34).Value = HASPCKPT.size

  # 13 HASPCKP2
  worksheet.Cells.Item(148, 34).Value = HASPCKP2.datasets
  worksheet.Cells.Item(149, 34).Value = HASPCKP2.volumes
  worksheet.Cells.Item(150, 34).Value = HASPCKP2.size

  # 14 PAGEPLPA
  worksheet.Cells.Item(151, 34).Value = PAGEPLPA.datasets
  worksheet.Cells.Item(152, 34).Value = PAGEPLPA.volumes
  worksheet.Cells.Item(153, 34).Value = PAGEPLPA.size

  # 15 PAGECOMMON
  worksheet.Cells.Item(154, 34).Value = PAGECOMMON.datasets
  worksheet.Cells.Item(155, 34).Value = PAGECOMMON.volumes
  worksheet.Cells.Item(156, 34).Value = PAGECOMMON.size

  # 16 PAGELOCAL 1
  worksheet.Cells.Item(157, 34).Value = PAGELOCAL.datasets.join
  worksheet.Cells.Item(158, 34).Value = PAGELOCAL.volumes.join
  worksheet.Cells.Item(159, 34).Value = PAGELOCAL.size.join

  # 17 IODF
  worksheet.Cells.Item(160, 34).Value = IODF.dataset_name
  worksheet.Cells.Item(161, 34).Value = IODF.volume
  worksheet.Cells.Item(162, 34).Value = IODF.size

  # 18 SYSPLEX COUPLE
  excel.ActiveWindow.ScrollRow = 163
  worksheet.Cells.Item(163, 34).Value = COUPLE.sysplexcds_datasets[0]
  worksheet.Cells.Item(164, 34).Value = COUPLE.sysplexcds_volumes[0]
  worksheet.Cells.Item(165, 34).Value = COUPLE.sysplexcds_datasets[1]
  worksheet.Cells.Item(166, 34).Value = COUPLE.sysplexcds_volumes[1]
  worksheet.Cells.Item(167, 34).Value = COUPLE.sysplexcds_datasets[2]
  worksheet.Cells.Item(168, 34).Value = COUPLE.sysplexcds_volumes[2]
  worksheet.Cells.Item(169, 34).Value = COUPLE.sysplexcds_itemname[0]
  worksheet.Cells.Item(170, 34).Value = COUPLE.sysplexcds_itemname[1]
  worksheet.Cells.Item(171, 34).Value = COUPLE.sysplexcds_itemname[3]
  worksheet.Cells.Item(172, 34).Value = COUPLE.sysplexcds_itemname[5]

  # 19 LOGGER COUPLE
  worksheet.Cells.Item(173, 34).Value = COUPLE.loggercds_datasets[0]
  worksheet.Cells.Item(174, 34).Value = COUPLE.loggercds_volumes[0]
  worksheet.Cells.Item(175, 34).Value = COUPLE.loggercds_datasets[1]
  worksheet.Cells.Item(176, 34).Value = COUPLE.loggercds_volumes[1]
  worksheet.Cells.Item(177, 34).Value = COUPLE.loggercds_datasets[2]
  worksheet.Cells.Item(178, 34).Value = COUPLE.loggercds_volumes[2]
  worksheet.Cells.Item(179, 34).Value = COUPLE.loggercds_itemname[0]
  worksheet.Cells.Item(180, 34).Value = COUPLE.loggercds_itemname[1]
  worksheet.Cells.Item(181, 34).Value = COUPLE.loggercds_itemname[2]
  worksheet.Cells.Item(182, 34).Value = COUPLE.loggercds_itemname[3]

  # 20 WLM COUPLE
  excel.ActiveWindow.ScrollRow = 183
  worksheet.Cells.Item(183, 34).Value = COUPLE.wlmcds_datasets[0]
  worksheet.Cells.Item(184, 34).Value = COUPLE.wlmcds_volumes[0]
  worksheet.Cells.Item(185, 34).Value = COUPLE.wlmcds_datasets[1]
  worksheet.Cells.Item(186, 34).Value = COUPLE.wlmcds_volumes[1]
  worksheet.Cells.Item(187, 34).Value = COUPLE.wlmcds_datasets[2]
  worksheet.Cells.Item(188, 34).Value = COUPLE.wlmcds_volumes[2]
  worksheet.Cells.Item(189, 34).Value = COUPLE.wlmcds_itemname[0]
  worksheet.Cells.Item(190, 34).Value = COUPLE.wlmcds_itemname[1]
  worksheet.Cells.Item(191, 34).Value = COUPLE.wlmcds_itemname[2]
  worksheet.Cells.Item(192, 34).Value = COUPLE.wlmcds_itemname[3]
  worksheet.Cells.Item(193, 34).Value = COUPLE.wlmcds_itemname[4]
  worksheet.Cells.Item(194, 34).Value = COUPLE.wlmcds_itemname[5]
  worksheet.Cells.Item(195, 34).Value = COUPLE.wlmcds_itemname[6]
  worksheet.Cells.Item(196, 34).Value = COUPLE.wlmcds_itemname[7]
  worksheet.Cells.Item(197, 34).Value = COUPLE.wlmcds_itemname[8]
  worksheet.Cells.Item(198, 34).Value = COUPLE.wlmcds_itemname[9]

  # 21-23 SMS SCDS/ACDS/COMMDS
  worksheet.Cells.Item(199, 34).Value = SMS.smsscds_datasets
  worksheet.Cells.Item(200, 34).Value = SMS.smsscds_volumes
  worksheet.Cells.Item(201, 34).Value = SMS.smsscds_size
  worksheet.Cells.Item(202, 34).Value = SMS.smsacds_datasets
  worksheet.Cells.Item(203, 34).Value = SMS.smsacds_volumes
  worksheet.Cells.Item(204, 34).Value = SMS.smsacds_size
  worksheet.Cells.Item(205, 34).Value = SMS.smscommds_datasets
  worksheet.Cells.Item(206, 34).Value = SMS.smscommds_volumes
  worksheet.Cells.Item(207, 34).Value = SMS.smscommds_size

  # 24 SMS ACS ROUTINE
  worksheet.Cells.Item(208, 34).Value = non_supported_message
  worksheet.Cells.Item(209, 34).Value = non_supported_message
  worksheet.Cells.Item(210, 34).Value = non_supported_message

  # 25-26 RACF PRIMARY/BACKUP
  excel.ActiveWindow.ScrollRow = 181
  worksheet.Cells.Item(211, 34).Value = RACF.racfprim_datasets
  worksheet.Cells.Item(212, 34).Value = RACF.racfprim_volumes
  worksheet.Cells.Item(213, 34).Value = RACF.racfprim_size
  worksheet.Cells.Item(214, 34).Value = RACF.racfback_datasets
  worksheet.Cells.Item(215, 34).Value = RACF.racfback_volumes
  worksheet.Cells.Item(216, 34).Value = RACF.racfback_size

  # 27 File System
  worksheet.Cells.Item(217, 34).Value = OMVS.root_filesystem_type
  worksheet.Cells.Item(218, 34).Value = OMVS.root_filesystem_name
  worksheet.Cells.Item(219, 34).Value = OMVS.root_filesystem_volumes
  worksheet.Cells.Item(220, 34).Value = non_supported_message
  worksheet.Cells.Item(221, 34).Value = non_supported_message
  worksheet.Cells.Item(222, 34).Value = non_supported_message
  worksheet.Cells.Item(223, 34).Value = non_supported_message
  worksheet.Cells.Item(224, 34).Value = non_supported_message

  # 28 SMP/E GLOBAL
  worksheet.Cells.Item(225, 34).Value = non_supported_message
  worksheet.Cells.Item(226, 34).Value = non_supported_message

  # 29 SMP/E TARGET
  worksheet.Cells.Item(227, 34).Value = non_supported_message
  worksheet.Cells.Item(228, 34).Value = non_supported_message
  worksheet.Cells.Item(229, 34).Value = non_supported_message

  # 30 SMP/E DLIB
  worksheet.Cells.Item(230, 34).Value = non_supported_message
  worksheet.Cells.Item(231, 34).Value = non_supported_message
  worksheet.Cells.Item(232, 34).Value = non_supported_message

  # 1-2 IODF導入パラメーター
  excel.ActiveWindow.ScrollRow = 236
  worksheet.Cells.Item(239, 34).Value = non_supported_message
  worksheet.Cells.Item(240, 34).Value = non_supported_message

  worksheet.Cells.Item(241, 34).Value = non_supported_message
  worksheet.Cells.Item(242, 34).Value = non_supported_message
  worksheet.Cells.Item(243, 34).Value = non_supported_message
  worksheet.Cells.Item(244, 34).Value = non_supported_message

  worksheet.Cells.Item(245, 34).Value = IODF.configid
  worksheet.Cells.Item(246, 34).Value = IODF.edtid

  # 1-3 SMS導入パラメーター
  excel.ActiveWindow.ScrollRow = 250

  # 1-3-1 File System
  worksheet.Cells.Item(253, 34).Value = SMS.enabled(SMS.root_filesystem_name) # SMS
  worksheet.Cells.Item(254, 34).Value = SMS.hlq(SMS.root_filesystem_name) # HLQ
  worksheet.Cells.Item(255, 34).Value = SMS.vol(SMS.root_filesystem_name) # VOL
  worksheet.Cells.Item(256, 34).Value = SMS.sc(SMS.root_filesystem_name)  # SC
  worksheet.Cells.Item(257, 34).Value = SMS.sg(SMS.root_filesystem_name)  # SG

  # 1-3-2 OPERLOG
  worksheet.Cells.Item(258, 34).Value = SMS.structure('OPERLOG')
  worksheet.Cells.Item(259, 34).Value = SMS.logr_hlq('OPERLOG') # HLQ
  worksheet.Cells.Item(260, 34).Value = SMS.logr_enabled('OPERLOG') # SMS
  worksheet.Cells.Item(261, 34).Value = SMS.logr_vol('OPERLOG') # VOL
  worksheet.Cells.Item(262, 34).Value = SMS.logr_sc('OPERLOG') # SC
  worksheet.Cells.Item(263, 34).Value = SMS.logr_sg('OPERLOG') # SG

  # 1-3-3 LOGREC
  worksheet.Cells.Item(264, 34).Value = SMS.structure('LOGREC')
  worksheet.Cells.Item(265, 34).Value = SMS.logr_hlq('LOGREC') # HLQ
  worksheet.Cells.Item(266, 34).Value = SMS.logr_enabled('LOGREC') # SMS
  worksheet.Cells.Item(267, 34).Value = SMS.logr_vol('LOGREC') # VOL
  worksheet.Cells.Item(268, 34).Value = SMS.logr_sc('LOGREC') # SC
  worksheet.Cells.Item(269, 34).Value = SMS.logr_sg('LOGREC') # SG

  # 1-4 RACF導入パラメーター
  worksheet.Cells.Item(276, 34).Value = non_supported_message
  worksheet.Cells.Item(277, 34).Value = non_supported_message
  worksheet.Cells.Item(278, 34).Value = non_supported_message

  # 1-5 UNIX導入パラメーター
  excel.ActiveWindow.ScrollRow = 282
  worksheet.Cells.Item(285, 34).Value = OMVS.superuser
  worksheet.Cells.Item(286, 34).Value = non_supported_message

  # 1-6 JES2導入パラメーター
  worksheet.Cells.Item(293, 34).Value = non_supported_message
  worksheet.Cells.Item(294, 34).Value = non_supported_message
  worksheet.Cells.Item(295, 34).Value = non_supported_message
  worksheet.Cells.Item(296, 34).Value = JES2.mode
  worksheet.Cells.Item(297, 34).Value = JES2.exit5

  # 1-7 SMP/E導入パラメーター
  worksheet.Cells.Item(303, 34).Value = SMPE.smptlib_prefix
  worksheet.Cells.Item(304, 34).Value = SMPE.smptlib_vol

  # 1-8 Stand Alone導入パラメーター
  excel.ActiveWindow.ScrollRow = 311

  # 1-8-1 Stand Alone DUMP
  worksheet.Cells.Item(314, 34).Value = non_supported_message
  worksheet.Cells.Item(315, 34).Value = non_supported_message
  worksheet.Cells.Item(316, 34).Value = non_supported_message
  worksheet.Cells.Item(317, 34).Value = non_supported_message
  worksheet.Cells.Item(318, 34).Value = non_supported_message
  worksheet.Cells.Item(319, 34).Value = non_supported_message
  worksheet.Cells.Item(320, 34).Value = non_supported_message

  # 1-8-2 Stand Alone UTILITY
  worksheet.Cells.Item(326, 34).Value = non_supported_message
  worksheet.Cells.Item(327, 34).Value = non_supported_message

  # 1-9 PARMLIB導入パラメーター
  excel.ActiveWindow.ScrollRow = 331

  # 1-9-1 SYSn.IPLPARM 作成
  worksheet.Cells.Item(334, 34).Value = non_supported_message
  worksheet.Cells.Item(335, 34).Value = IPLPARM.dataset_name

  # 1-9-2 PARMLIB 連結データセット
  worksheet.Cells.Item(336, 34).Value = PARMLIB.dataset_first
  worksheet.Cells.Item(337, 34).Value = PARMLIB.dataset_second
  worksheet.Cells.Item(338, 34).Value = PARMLIB.dataset_others

  # 1-9-3 PARMLIB
  worksheet.Cells.Item(339, 34).Value = ParmlibSuffix.load
  worksheet.Cells.Item(340, 34).Value = ParmlibSuffix.ieasys

  # 行の高さを自動調整
  worksheet.Range('11:338').Rows.AutoFit

  # 2-1 基本カスタマイズ・パラメーター
  worksheet = workbook.Worksheets(5)
  worksheet.Activate
  excel.ActiveWindow.ScrollRow = 8
  @column_max_length = 25

  # 2-1-1 現在の基本構成と移行対象
  worksheet.Cells.Item(11, 34).Value = IPLPARM.release
  worksheet.Cells.Item(12, 34).Value = non_supported_message
  worksheet.Cells.Item(13, 34).Value = non_supported_message
  worksheet.Cells.Item(14, 34).Value = non_supported_message
  worksheet.Cells.Item(15, 34).Value = non_supported_message

  # 2-2 PARMLIBカスタマイズ・パラメーター
  excel.ActiveWindow.ScrollRow = 21

  # 2-2-1 現在のPARMLIBメンバー構成と新設定項目
  worksheet.Cells.Item(26, 34).Value = ParmlibSuffix.adyset.parmlib_names.join
  worksheet.Cells.Item(28, 34).Value = ParmlibSuffix.alloc.parmlib_names.join
  worksheet.Cells.Item(30, 34).Value = ParmlibSuffix.antmin00.parmlib_names.join
  worksheet.Cells.Item(32, 34).Value = ParmlibSuffix.antxin00.parmlib_names.join
  worksheet.Cells.Item(34, 34).Value = ParmlibSuffix.appcpm.parmlib_names.join
  worksheet.Cells.Item(36, 34).Value = ParmlibSuffix.aschpm.parmlib_names.join
  worksheet.Cells.Item(38, 34).Value = ParmlibSuffix.autor.parmlib_names.join
  worksheet.Cells.Item(40, 34).Value = ParmlibSuffix.axr.parmlib_names.join
  # No.9 移行対象外
  worksheet.Cells.Item(44, 34).Value = datasets_member_names(PARMLIB.datasets, 'BLSCUSER').join
  worksheet.Cells.Item(46, 34).Value = ParmlibSuffix.bpxprm.parmlib_names.join
  worksheet.Cells.Item(48, 34).Value = ParmlibSuffix.ceaprm.parmlib_names.join
  worksheet.Cells.Item(50, 34).Value = ParmlibSuffix.ceeprm.parmlib_names.join
  worksheet.Cells.Item(52, 34).Value = ParmlibSuffix.clock.parmlib_names.join
  worksheet.Cells.Item(54, 34).Value = ParmlibSuffix.cngrp.parmlib_names.join
  worksheet.Cells.Item(56, 34).Value = ParmlibSuffix.cnidtr.parmlib_names.join
  worksheet.Cells.Item(58, 34).Value = CONSOLxx.cnlcccxx_member_names.parmlib_names.join
  worksheet.Cells.Item(60, 34).Value = ParmlibSuffix.cofdlf.parmlib_names.join
  worksheet.Cells.Item(62, 34).Value = ParmlibSuffix.cofvlf.parmlib_names.join
  worksheet.Cells.Item(64, 34).Value = ParmlibSuffix.commnd.parmlib_names.join
  worksheet.Cells.Item(66, 34).Value = ParmlibSuffix.config.parmlib_names.join
  worksheet.Cells.Item(68, 34).Value = ParmlibSuffix.consol.parmlib_names.join
  worksheet.Cells.Item(70, 34).Value = ParmlibSuffix.couple.parmlib_names.join
  worksheet.Cells.Item(72, 34).Value = ParmlibSuffix.csvlla.parmlib_names.join
  worksheet.Cells.Item(74, 34).Value = ParmlibSuffix.csvrtl.parmlib_names.join
  # No.26 移行対象外
  excel.ActiveWindow.ScrollRow = 77
  worksheet.Cells.Item(78, 34).Value = ParmlibSuffix.cununi.parmlib_names.join
  worksheet.Cells.Item(80, 34).Value = CUNUNIxx.image
  worksheet.Cells.Item(82, 34).Value = ParmlibSuffix.devsup.parmlib_names.join
  worksheet.Cells.Item(84, 34).Value = ParmlibSuffix.dfhssi.parmlib_names.join
  worksheet.Cells.Item(86, 34).Value = ParmlibSuffix.diag.parmlib_names.join
  worksheet.Cells.Item(88, 34).Value = ParmlibSuffix.ephwp00.parmlib_names.join
  worksheet.Cells.Item(90, 34).Value = ParmlibSuffix.exit.parmlib_names.join
  worksheet.Cells.Item(92, 34).Value = ParmlibSuffix.exspat.parmlib_names.join
  worksheet.Cells.Item(94, 34).Value = ParmlibSuffix.grscnf.parmlib_names.join
  worksheet.Cells.Item(96, 34).Value = ParmlibSuffix.grsrnl.parmlib_names.join
  # No.37 移行対象外
  worksheet.Cells.Item(100, 34).Value = ParmlibSuffix.hzsprm.parmlib_names.join
  worksheet.Cells.Item(102, 34).Value = ParmlibSuffix.idavdt.parmlib_names.join
  worksheet.Cells.Item(104, 34).Value = ParmlibSuffix.ieaabd00.parmlib_names.join
  worksheet.Cells.Item(106, 34).Value = ParmlibSuffix.ieaapf.parmlib_names.join
  worksheet.Cells.Item(108, 34).Value = ParmlibSuffix.ieaapp00.parmlib_names.join
  worksheet.Cells.Item(110, 34).Value = ParmlibSuffix.ieacmd00.parmlib_names.join
  worksheet.Cells.Item(112, 34).Value = ParmlibSuffix.ieadmc.sys1_parmlib_names.join
  worksheet.Cells.Item(114, 34).Value = ParmlibSuffix.ieadmp00.parmlib_names.join
  worksheet.Cells.Item(116, 34).Value = ParmlibSuffix.ieadmr00.parmlib_names.join
  worksheet.Cells.Item(118, 34).Value = ParmlibSuffix.ieafix.parmlib_names.join
  worksheet.Cells.Item(120, 34).Value = ParmlibSuffix.ieaics.parmlib_names.join
  worksheet.Cells.Item(122, 34).Value = ParmlibSuffix.ieaips.parmlib_names.join
  worksheet.Cells.Item(124, 34).Value = ParmlibSuffix.iealpa.parmlib_names.join
  worksheet.Cells.Item(126, 34).Value = ParmlibSuffix.ieaopt.parmlib_names.join
  worksheet.Cells.Item(128, 34).Value = ParmlibSuffix.ieapak.parmlib_names.join
  worksheet.Cells.Item(130, 34).Value = ParmlibSuffix.ieaslp.parmlib_names.join
  worksheet.Cells.Item(132, 34).Value = ParmlibSuffix.ieasvc.parmlib_names.join
  worksheet.Cells.Item(134, 34).Value = ParmlibSuffix.ieasym.parmlib_names.join
  worksheet.Cells.Item(136, 34).Value = ParmlibSuffix.ieasys.parmlib_names.join
  worksheet.Cells.Item(138, 34).Value = ParmlibSuffix.iecios.parmlib_names.join
  worksheet.Cells.Item(140, 34).Value = ParmlibSuffix.iefssn.parmlib_names.join
  # No.59 移行対象外
  excel.ActiveWindow.ScrollRow = 143
  worksheet.Cells.Item(144, 34).Value = datasets_member_names(PARMLIB.datasets, 'IFGPSEDI').join
  worksheet.Cells.Item(146, 34).Value = datasets_member_names(PARMLIB.datasets, 'IGDDFPKG').join
  worksheet.Cells.Item(148, 34).Value = ParmlibSuffix.igdsms.parmlib_names.join
  worksheet.Cells.Item(150, 34).Value = ParmlibSuffix.iggcat.parmlib_names.join
  # No.64 移行対象外
  worksheet.Cells.Item(154, 34).Value = ParmlibSuffix.ikjtso.parmlib_names.join
  worksheet.Cells.Item(156, 34).Value = ParmlibSuffix.ioeprm.parmlib_names.join
  worksheet.Cells.Item(158, 34).Value = ParmlibSuffix.ipcsprnn.parmlib_names.join
  worksheet.Cells.Item(160, 34).Value = ParmlibSuffix.ivtprm00.parmlib_names.join
  worksheet.Cells.Item(162, 34).Value = ParmlibSuffix.ixgcnf.parmlib_names.join
  worksheet.Cells.Item(164, 34).Value = ParmlibSuffix.lnklst.parmlib_names.join
  worksheet.Cells.Item(166, 34).Value = ParmlibSuffix.load.iplparm_names.join
  worksheet.Cells.Item(168, 34).Value = ParmlibSuffix.lpalst.parmlib_names.join
  worksheet.Cells.Item(170, 34).Value = ParmlibSuffix.mmslst.parmlib_names.join
  worksheet.Cells.Item(172, 34).Value = ParmlibSuffix.mpflst.parmlib_names.join
  worksheet.Cells.Item(174, 34).Value = ParmlibSuffix.msgfld.parmlib_names.join
  worksheet.Cells.Item(176, 34).Value = ParmlibSuffix.mstjcl.parmlib_names.join
  worksheet.Cells.Item(178, 34).Value = ParmlibSuffix.nuclst.iplparm_names.join
  worksheet.Cells.Item(180, 34).Value = ParmlibSuffix.pfktab.parmlib_names.join
  worksheet.Cells.Item(182, 34).Value = ParmlibSuffix.prog.parmlib_names.join
  worksheet.Cells.Item(184, 34).Value = ParmlibSuffix.sched.parmlib_names.join
  worksheet.Cells.Item(186, 34).Value = ParmlibSuffix.smfprm.parmlib_names.join
  worksheet.Cells.Item(188, 34).Value = ParmlibSuffix.tsokey00.parmlib_names.join
  worksheet.Cells.Item(190, 34).Value = ParmlibSuffix.vatlst.parmlib_names.join
  worksheet.Cells.Item(192, 34).Value = ParmlibSuffix.xcfpol.parmlib_names.join

  # 2-3 JES2カスタマイズ・パラメーター
  excel.ActiveWindow.ScrollRow = row = 199

  # 1 JES2
  worksheet.Cells.Item(row + 3, 34).Value = JES2.dataset_name

  # 2 JES2PARM
  worksheet.Cells.Item(row + 4, 34).Value = JES2.haspparm_datasets

  # 3 JES2PARM NODE 定義
  worksheet.Cells.Item(row + 5, 34).Value = JES2.ownnode
  worksheet.Cells.Item(row + 6, 34).Value = JES2.ownname

  # 2-4.VTAMカスタマイズ・パラメーター
  excel.ActiveWindow.ScrollRow = row = 212

  # 1 VTAM
  worksheet.Cells.Item(row + 3, 34).Value = VTAM.dataset_name

  # 2 VTAMLST
  worksheet.Cells.Item(row + 4, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 5, 34).Value = VTAM.vtamlst_dataset_concatenate
  worksheet.Cells.Item(row + 6, 34).Value = VTAM.atcstrxx_vtamlst_dataset
  worksheet.Cells.Item(row + 7, 34).Value = VTAM.atcconxx_vtamlst_dataset

  # 3 VTAMLIB USS テーブル
  worksheet.Cells.Item(220, 34).Value = non_supported_message
  worksheet.Cells.Item(221, 34).Value = VTAM.vtamlib_dataset_concatenate
  worksheet.Cells.Item(222, 34).Value = VTAM.vtamlib_volser_concatenate
  worksheet.Cells.Item(223, 34).Value = non_supported_message
  worksheet.Cells.Item(224, 34).Value = non_supported_message
  worksheet.Cells.Item(225, 34).Value = non_supported_message
  worksheet.Cells.Item(226, 34).Value = non_supported_message
  worksheet.Cells.Item(227, 34).Value = non_supported_message
  worksheet.Cells.Item(228, 34).Value = non_supported_message
  worksheet.Cells.Item(229, 34).Value = non_supported_message

  # 4 VTAMLIB Logon mode テーブル
  worksheet.Cells.Item(230, 34).Value = non_supported_message
  worksheet.Cells.Item(231, 34).Value = VTAM.vtamlib_dataset_concatenate
  worksheet.Cells.Item(232, 34).Value = VTAM.vtamlib_volser_concatenate
  worksheet.Cells.Item(233, 34).Value = non_supported_message
  worksheet.Cells.Item(234, 34).Value = non_supported_message
  worksheet.Cells.Item(235, 34).Value = non_supported_message
  worksheet.Cells.Item(236, 34).Value = non_supported_message
  worksheet.Cells.Item(237, 34).Value = non_supported_message
  worksheet.Cells.Item(238, 34).Value = non_supported_message
  worksheet.Cells.Item(239, 34).Value = non_supported_message

  # 5 VTAMLIB COS テーブル
  worksheet.Cells.Item(240, 34).Value = non_supported_message
  worksheet.Cells.Item(241, 34).Value = VTAM.vtamlib_dataset_concatenate
  worksheet.Cells.Item(242, 34).Value = VTAM.vtamlib_volser_concatenate
  worksheet.Cells.Item(243, 34).Value = non_supported_message

  # 2-5 RACFカスタマイズ・パラメーター
  excel.ActiveWindow.ScrollRow = 250

  # 1 RACF DATABASE
  worksheet.Cells.Item(253, 34).Value = non_supported_message

  # 2 ICHRIN03 (STC TABLE)
  worksheet.Cells.Item(254, 34).Value = non_supported_message
  worksheet.Cells.Item(255, 34).Value = non_supported_message

  # 3 RACF SPECIAL USER
  worksheet.Cells.Item(256, 34).Value = non_supported_message
  worksheet.Cells.Item(257, 34).Value = non_supported_message
  worksheet.Cells.Item(258, 34).Value = non_supported_message

  # 2-6 TSOカスタマイズ・パラメーター
  # 1 UADS
  worksheet.Cells.Item(268, 34).Value = non_supported_message

  # 2-7 SMSカスタマイズ・パラメーター
  excel.ActiveWindow.ScrollRow = row = 275
  worksheet.Cells.Item(row + 3, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 4, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 5, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 6, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 7, 34).Value = non_supported_message

  # 2-8 UNIXカスタマイズ・パラメーター
  excel.ActiveWindow.ScrollRow = row = 289
  worksheet.Cells.Item(row + 3, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 4, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 5, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 6, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 7, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 8, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 9, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 10, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 11, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 12, 34).Value = OMVS.superuser
  worksheet.Cells.Item(row + 13, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 14, 34).Value = non_supported_message

  # 2-9 TCP/IPカスタマイズ・パラメーター
  excel.ActiveWindow.ScrollRow = row = 310

  # 1
  worksheet.Cells.Item(row + 3, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 4, 34).Value = TCPIP.dataset_names.join
  worksheet.Cells.Item(row + 5, 34).Value = TCPIP.profile_names.join
  worksheet.Cells.Item(row + 6, 34).Value = TCPIP.tcpdata_names.join
  # 2
  worksheet.Cells.Item(row + 7, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 8, 34).Value = TN3270.portno
  worksheet.Cells.Item(row + 9, 34).Value = TN3270.dataset_names
  worksheet.Cells.Item(row + 10, 34).Value = TN3270.profile_names
  worksheet.Cells.Item(row + 11, 34).Value = TN3270.tcpdata_name
  worksheet.Cells.Item(row + 12, 34).Value = non_supported_message
  # 3
  worksheet.Cells.Item(row + 13, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 14, 34).Value = FTPD.portnos.join
  worksheet.Cells.Item(row + 15, 34).Value = FTPD.dataset_names.join
  worksheet.Cells.Item(row + 16, 34).Value = FTPD.ftpsdata_names.join
  worksheet.Cells.Item(row + 17, 34).Value = FTPD.tcpdata_names.join
  worksheet.Cells.Item(row + 18, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 19, 34).Value = non_supported_message
  # 4
  worksheet.Cells.Item(row + 20, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 21, 34).Value = non_supported_message
  # 5
  worksheet.Cells.Item(row + 22, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 23, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 24, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 25, 34).Value = non_supported_message
  # 6
  worksheet.Cells.Item(row + 26, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 27, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 28, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 29, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 30, 34).Value = non_supported_message
  # 7
  worksheet.Cells.Item(row + 31, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 32, 34).Value = non_supported_message

  # 2-10 SDSFカスタマイズ・パラメーター
  excel.ActiveWindow.ScrollRow = row = 349
  worksheet.Cells.Item(row + 3, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 4, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 5, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 6, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 7, 34).Value = SDSF.dataset_name
  worksheet.Cells.Item(row + 8, 34).Value = SDSF.isfprmxx_dataset_name

  # 2-11 RMFカスタマイズ・パラメーター
  # 1 for RMF MONITOR I
  excel.ActiveWindow.ScrollRow = row = 364
  worksheet.Cells.Item(row + 3, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 4, 34).Value = RMF.dataset_name.join
  worksheet.Cells.Item(row + 5, 34).Value = RMF.rmf1_parm_dataset.join

  # 2 for RMF MONITOR II
  worksheet.Cells.Item(row + 6, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 7, 34).Value = non_supported_message

  # 3 for RMF MONITOR III
  worksheet.Cells.Item(row + 8, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 9, 34).Value = RMF.dataset_name('RMFGAT').join
  worksheet.Cells.Item(row + 10, 34).Value = RMF.rmf3_parm_dataset.join

  #2-12 DFSORTカスタマイズ・パラメーター
  excel.ActiveWindow.ScrollRow = row = 381

  # 1 Using USERMOD
  worksheet.Cells.Item(row + 3, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 4, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 5, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 6, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 7, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 8, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 9, 34).Value = non_supported_message

  # 2 Using PARMLIB ICEPRMxx
  worksheet.Cells.Item(row + 10, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 11, 34).Value = DFSORT.dataset_name.join
  worksheet.Cells.Item(row + 12, 34).Value = DFSORT.iceprm_dataset.join

  # 2-13 言語環境カスタマイズ・パラメーター
  excel.ActiveWindow.ScrollRow = row = 400

  # 1 ASSEMBLER ASSEMBLE OPT SOURCE
  worksheet.Cells.Item(row + 3, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 4, 34).Value = non_supported_message

  # 2 COBOL for MVS COMPILE OPT SOURCE
  worksheet.Cells.Item(row + 5, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 6, 34).Value = non_supported_message

  # 3 ENT COBOL COMPILE OPT SOURCE
  worksheet.Cells.Item(row + 7, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 8, 34).Value = non_supported_message

  # 4 PL/I for MVS COMPILE OPT SOURCE
  worksheet.Cells.Item(row + 9, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 10, 34).Value = non_supported_message

  # 5 ENT PL/I COMPILE OPT SOURCE
  worksheet.Cells.Item(row + 11, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 12, 34).Value = non_supported_message

  # 6 LE OS RUNTIME OPT SOURCE
  worksheet.Cells.Item(row + 13, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 14, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 15, 34).Value = non_supported_message

  # 6 LE CICS RUNTIME OPT SOURCE
  worksheet.Cells.Item(row + 16, 34).Value = non_supported_message

  # 7 CEEPRMxx
  worksheet.Cells.Item(row + 17, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 18, 34).Value = LE.ceeprm_dataset

  # 2-14 WLMカスタマイズ・パラメーター
  # 1 WLM POLICY SAVE
  worksheet.Cells.Item(row + 28, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 29, 34).Value = non_supported_message
  worksheet.Cells.Item(row + 30, 34).Value = non_supported_message

  # 行の高さを自動調整
  worksheet.Range('11:430').Rows.AutoFit

rescue => exception
  ZOS_FTP.log_error exception.message
  ZOS_FTP.log_error exception.backtrace

ensure
  event.off_event('SheetChange')
  excel.DisplayAlerts = false
  begin
    workbook.SaveAs(output_filename) if workbook
  rescue
    if output_filename == 'new_form.xls'
      new_output_filename = 'new_form_1.xls'
    else
      new_output_filename = 'new_form_' + (output_filename[/_(\d+)\./, 1].to_i + 1).to_s + '.xls'
    end
    puts "#{output_filename} is used. Trying a new filename #{new_output_filename}"
    output_filename = new_output_filename
    retry
  end

  excel.DisplayAlerts = true
  excel.Quit
end
