# Provides FTP related accessors.
class FTP
  attr_accessor :ipaddress, :userid, :passowrd
end
