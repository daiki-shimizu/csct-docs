# Provide information on SMFPRMxx.
class SMFPRMxx
  def self.content
    ParmlibContentFactory.collect(ParmlibSuffix.smfprm)
  end

  def self.sid
    content.scan(/SID\(([\w\s\#\%]+)\)/)
  end
end
