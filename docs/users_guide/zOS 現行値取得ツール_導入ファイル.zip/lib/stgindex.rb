# Provide information on STGINDEX.
class STGINDEX
  def self.datasets
    dsn = IEASYSxx.content.scan(/VIODSN=(#{dataset_regexp})/)
    if dsn.nil?
      'SYS1.STGINDEX'
    elsif dsn =~ /^IGNORE/
      'IGNORE'
    else
      dsn
    end
  end

  def self.volumes
    if datasets == 'IGNORE'
      undefined_message
    else
      submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{datasets}\') ALL") \
        .scan_volser_hyphen
    end
  end

  def self.size
    if datasets == 'IGNORE'
      undefined_message
    else
      SYSTEM_DATASET.dataset_size_vsam(datasets)
    end
  end
end
