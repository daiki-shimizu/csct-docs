require_relative 'parmlib_content'

# CommndxxContent
class CommndxxContent < ParmlibContent
  def remove_comments(content)
    content.split("\n").collect do |line|
      line.scan(/^COM='(.+)'/).flatten.first
    end.compact.join("\n")
  end
end
