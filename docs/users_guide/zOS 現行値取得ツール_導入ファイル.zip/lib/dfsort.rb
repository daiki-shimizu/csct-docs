# Provides information on DFSORT.
class DFSORT
  def self.procname
    'ICEOPT'
  end

  def self.dataset_name
    datasets_member_name(JES2.proc00_datasets, procname)
  end

  def self.iceprm_dataset
    iceprm_suffix.parmlib_names
  end

  def self.iceprm_suffix
    submit_jcl('icetool.jcl.erb', 'DEFAULTS LIST(LIST1)') \
      .get_suffix_list('ICEPRM')
  end
end
