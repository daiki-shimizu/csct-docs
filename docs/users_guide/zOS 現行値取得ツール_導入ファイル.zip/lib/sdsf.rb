# Provide information on SDSF.
class SDSF
  def self.procname
    'SDSF'
  end

  def self.dataset_name
    datasets_member_name(JES2.proc00_datasets, procname)
  end

  def self.content
    StartedProcedureFactory.create(
      datasets_member(JES2.proc00_datasets, procname)
    )
  end

  def self.isfprmxx_suffix
    content.scan_suffix(/PGM=ISFHCTL.+?PARM='M\((\w\w)\)/).set_default_suffix
  end

  def self.isfprmxx_dataset_name
    datasets_member_name(PARMLIB.datasets, 'ISFPRM' + isfprmxx_suffix.to_s)
  end
end
