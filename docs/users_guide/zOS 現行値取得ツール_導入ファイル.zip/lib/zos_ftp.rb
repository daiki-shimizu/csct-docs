#! ruby -Ku
require 'logger'

# ZOS_FTP provides methods to access the target z/OS via FTP and
# submit a JCL, and get the job log.
module ZOS_FTP
  require 'net/ftp'
  require 'erb'

  @@ftp_port = 21
  @@ssh_port = 22
  @@sockets = {}
  @@temporary_jcl_filename = 'temporary.jcl'
  @@temporary_joblog_filename = 'temporary.joblog'
  @@submit_rexx_filename = 'submit.rexx'
  @@log = nil

  module_function

  # Returns an absolute path of the file
  def absolute_path(filename)
    File.join(
      File.expand_path('../..', __FILE__),
      filename.gsub(%r{[/:\\\?\*\"\>\<\|]}, '_')
    )
  end
  
  # Specifies the IP address of the target z/OS.
  def ipaddress=(val)
    @@ipaddress = val
  end

  # Specifies the userID that is required to log on to the target z/OS.
  def userid=(val)
    @@userid = val ? val.upcase : val
  end

  # Returns the userID that is required to log on to the target z/OS.
  def userid
    @@userid
  end

  # Specifies the password for the userID.
  def password=(val)
    @@password = val ? val.upcase : val
  end

  # Specifies a TCP port number to use to contact a z/OS FTP server
  def ftp_port=(val)
    @@ftp_port = val
  end

  # Specifies a TCP port number to use to contact a z/OS OpenSSH server
  def ssh_port=(val)
    @@ssh_port = val
  end

  # Specifies a private key to use to contact a z/OS OpenSSH server
  def ssh_key=(val)
    @@ssh_key = val
  end

  # Returns a private key to use to contact a z/OS OpenSSH server
  def ssh_key
    @@ssh_key
  end

  # Specifies the name of file that includes a JOB statement.
  def job_statements_jcl_filename=(val)
    @@job_statements_jcl_filename = val
  end

  def syscmd_jcl_erb_filename=(val)
    @@syscmd_jcl_erb_filename = val
  end

  def syscmd_ulog_jcl_erb_filename=(val)
    @@syscmd_ulog_jcl_erb_filename = val
  end

  def syscmd_rexx_erb_filename=(val)
    @@syscmd_rexx_erb_filename = val
  end

  def submit_store_jcl_filename=(val)
    @@submit_store_jcl_filename = val
  end

  # Specifies the console name used when a command is executed
  # by ULOG. The default value is @SMART@.
  def console_name=(val)
    @@console_name = val
  end

  def connection_type=(val)
    @@connection_type = val if %w[FTP SSH].include?(val)
  end

  # Create a log file.
  def log_initialize
    @@log = Logger.new(add_path('log.txt'), 1, 10 * 1024 * 1024)
    @@log.info "VERSION #{File.read(absolute_path('VERSION')).strip}"
  end

  # Records an informational message to the log file.
  def log_info(message)
    @@log.info p message
  end

  # Records an error message in the log file.
  def log_error(message)
    @@log.error p message
  end

  # Downloads the content of a dataset whose name is dataset and returns
  # whether the download is successfully done, or not.
  def download(dataset_name)
    if @@connection_type == 'FTP'
      ftp_download_common(dataset_name) do |ftp|
        ftp.get("\'" + dataset_name + "\'", add_path(dataset_name))
      end
    else
      ssh_download_common(dataset_name) do |ssh|
        ssh.exec!(%(rm -f .tmpfile ; cp "//'#{dataset_name}'" .tmpfile))
        ssh.scp.download!('.tmpfile', add_path(dataset_name))
      end
    end
  end

  # Downloads a list of the partitioned dataset members
  def download_list(dataset_name)
    if @@connection_type == 'FTP'
      ftp_download_common(dataset_name) do |ftp|
        File.write(add_path(dataset_name),
                   ftp.ls("\'" + dataset_name + "(*)\'").join("\n"))
      end
    else
      ssh_download_common(dataset_name) do |ssh|
        File.write(add_path(dataset_name),
                   ssh.exec!(
                     %(tsocmd listds "'#{dataset_name}'" members | tail +7)
                   ).scan(/^  ([\w\@\#\$]{1,8})/).join("\n"))
      end
    end
  end

  # Provide a common FTP socket
  def ftp_socket
    if @@sockets[ZOS_function.directory_path]
      @@sockets[ZOS_function.directory_path]
    else
      begin
        ftp = Net::FTP.new
        ftp.connect(@@ipaddress, @@ftp_port)
        ftp.login(@@userid, @@password)
        ftp.passive = false
        ftp.binary = false
        @@sockets[ZOS_function.directory_path] = ftp
      rescue StandardError => e
        @@log.warn p "Connetion error: ipaddress = #{@@ipaddress}"
        @@log.error p e.message
        @@log.error p e.backtrace
        nil
      end
    end
  end

  def ftp_download_common(dataset_name)
    ftp = ftp_socket
    return false unless ftp

    begin
      ftp.site('filetype=seq')
      yield(ftp)
      @@log.info p "download #{dataset_name}"
    rescue Errno::EPIPE
      ftp.quit
      @@ockets[ZOS_function.directory_path] = nil
      retry
    rescue
      @@log.info p "not found #{dataset_name}"
      File.write(add_path('!' + dataset_name), '')
      File.delete(add_path(dataset_name)) \
        if File.exist?(add_path(dataset_name))
    end

    File.exist?(add_path(dataset_name))
  end

  # Provide a common SSH socket
  def ssh_socket
    if @@sockets[ZOS_function.directory_path]
      @@sockets[ZOS_function.directory_path]
    else
      begin
        @@sockets[ZOS_function.directory_path] =
          if @@ssh_key
            Net::SSH.start(@@ipaddress,
                           @@userid,
                           password: @@password,
                           port: @@ssh_port,
                           keys: @@ssh_key,
                           keepalive: true,
                           verify_host_key: false)
          else
            Net::SSH.start(@@ipaddress,
                           @@userid,
                           password: @@password,
                           port: @@ssh_port,
                           keepalive: true,
                           verify_host_key: false)
          end
      rescue StandardError => e
        @@log.warn p "Connetion error: ipaddress = #{@@ipaddress}"
        @@log.error p e.message
        @@log.error p e.backtrace
        nil
      end
    end
  end

  def ssh_download_common(dataset_name)
    require 'net/ssh'
    require 'net/scp'

    ssh = ssh_socket
    return false unless ssh

    begin
      yield(ssh)
      @@log.info p "download #{dataset_name}"
    rescue
      @@log.info p "not found #{dataset_name}"
      File.write(add_path('!' + dataset_name), '')
      File.delete(add_path(dataset_name)) \
        if File.exist?(add_path(dataset_name))
    end

    File.exist?(add_path(dataset_name))
  end

  # Provide FTP common function to log in to the remote FTP server,
  # submit a JCL, get the job log and return the result.
  # If a block is given, it is executed for the obtained job log.
  def ftp_common(filename, output_filename, options = {})
    @userid = @@userid
    @password = @@password
    @console_name = @@console_name
    erb =
      ERB.new(File.read(absolute_path(@@job_statements_jcl_filename)).chomp \
        + "\n" + File.read(absolute_path(filename)), nil, '-')
    File.write(add_path(@@temporary_jcl_filename), erb.result(binding))

    begin
      ftp = ftp_socket
      return false unless ftp

      ftp.site('filetype=jes')
      ftp.put(add_path(@@temporary_jcl_filename))
      return true if options[:no_joblog]

      retry_count = 5
      begin
        sleep 1
        ftp.get(
          ftp.last_response.scan(/JOB\d+/)[0],
          add_path(@@temporary_joblog_filename)
        )
      rescue StandardError => e
        retry_count -= 1
        retry if retry_count > 0
        @@log.warn p "Submit error: jobid = #{ftp.last_response.scan(/JOB\d+/)[0]}, filename = #{filename}"
        @@log.error p e.message
        @@log.error p e.backtrace
        return false
      end

      yield if block_given?
    rescue Errno::EPIPE => e
      ftp.quit
      @@sockets[ZOS_function.directory_path] = nil
      retry
    rescue StandardError => e
      ftp.quit
      @@sockets[ZOS_function.directory_path] = nil
      @@log.warn p "Submit error: filename = #{filename}"
      @@log.error p e.message
      @@log.error p e.backtrace
    end
    File.exist?(add_path(output_filename))
  end

  # Provide SSH common function to log in to the remote z/OS SSHD,
  # execute a Rexx, get the job log and return the result.
  # If a block is given, it is executed for the obtained job log.
  def ssh_common(filename, output_filename, options = {})
    require 'net/ssh'
    require 'net/scp'

    erb = ERB.new(File.read(absolute_path(filename)), nil, '-')
    File.write(add_path(@@temporary_jcl_filename), erb.result(binding))

    ssh = ssh_socket
    return false unless ssh

    begin
      ssh.scp.upload!(add_path(@@temporary_jcl_filename), '.syscmd.rex')
      File.write(add_path(@@temporary_joblog_filename),
                 ssh.exec!(
                   'tr -d "\r" < .syscmd.rex > .syscmd1.rex ; ' \
                   'chmod +x .syscmd1.rex ; ./.syscmd1.rex'
                 ))

      yield if block_given?
    rescue StandardError => e
      @@log.warn p "Execute error: filename = #{filename}"
      @@log.error p e.message
      @@log.error p e.backtrace
      ssh.close
      @@sockets[ZOS_function.directory_path] = nil
    end

    File.exist?(add_path(output_filename))
  end

  # Provide a common function for FTP and SSH
  def execute_and_download_common(output_filename, options, &block)
    if @@connection_type == 'FTP'
      ftp_common(@@syscmd_jcl_erb_filename, output_filename, options, &block)
    else
      ssh_common(@@syscmd_rexx_erb_filename, output_filename, options, &block)
    end
  end

  # Using an ERB file that is specified by syscmd_jcl_erb_filename,
  # submits an MVS system command, saves the job log as `command_line`
  # in directory specified by zos_function.directory_path, and returns
  # downloading the output is successfully done, or not.
  def execute_and_download(command_line, options)
    @command_line = command_line
    execute_and_download_common(command_line, options) do
      @@log.info p "execute_and_download #{command_line}"
      File.open(add_path(@@temporary_joblog_filename),
                invalid: :replace) do |input|
        File.open(add_path(command_line), 'w') do |output|
          output.puts input.read.scrub.scan(/^.CMDOUT = (.*)/).join("\n")
        end
      end
      raise 'File size is zero' if File.zero?(add_path(command_line))
    end
  end

  # Using an ERB file that is specified by syscmd_ulog_jcl_erb_filename,
  # submits an MVS system command, saves the job log as `command_line`
  # in directory specified by zos_function.directory_path, and returns
  # downloading the output is successfully done, or not.
  def execute_and_download_ulog(command_line)
    @command_line = command_line
    ftp_common(@@syscmd_ulog_jcl_erb_filename, command_line) do
      @@log.info p "execute_and_download #{command_line}"
      File.open(add_path(@@temporary_joblog_filename),
                invalid: :replace) do |input|
        File.open(add_path(command_line), 'w') do |output|
          found = false
          input.read.scrub.each_line do |line|
            break if found && line.include?('BOTTOM OF DATA')
            output.puts line[43..-1] if found && line[43..-1]
            found = true if line.include?('-' + command_line)
          end
        end
      end
      raise 'File size is zero' if File.zero?(add_path(command_line))
    end
  end

  # Using an ERB file that is specified by `jcl_erb_filename`, submits a JCL
  # and downloads the output. It returns the portion of the content after
  # `command_line` matches if `eye_catcher` of options is nil. Otherwise it
  # returns the one after `eye_catcher` as well as the match line. The one is
  # saved as `command_line` in directory specified by zos_function.directory_path.
  def submit_and_download(jcl_erb_filename, command_line, options)
    if @@connection_type == 'FTP'
      ftp_submit_and_download(jcl_erb_filename, command_line, options)
    else
      ssh_submit_and_download(jcl_erb_filename, command_line, options)
    end
  end

  def ftp_submit_and_download(jcl_erb_filename, command_line, options)
    @command_line = command_line
    eye_catcher = options[:eye_catcher]
    ftp_common(jcl_erb_filename, command_line, options) do
      @@log.info p "submit_and_download #{command_line}"
      File.open(add_path(@@temporary_joblog_filename),
                invalid: :replace) do |input|
        File.open(add_path(command_line), 'w') do |output|
          found = false
          input.read.scrub.each_line do |line|
            found = true if eye_catcher && line.match(/#{eye_catcher}/)
            output.puts line if found
            found = true if eye_catcher.nil? && line.include?(command_line)
          end
        end
      end
    end
  end

  def ssh_submit_and_download(jcl_erb_filename, command_line, options)
    require 'net/ssh'
    require 'net/scp'

    @command_line = command_line
    @userid = @@userid
    @password = @@password
    @console_name = @@console_name
    eye_catcher = options[:eye_catcher]
    erb =
      ERB.new(File.read(absolute_path(@@job_statements_jcl_filename)).chomp \
        + "\n" + File.read(absolute_path(jcl_erb_filename)), nil, '-')
    File.write(add_path(@@temporary_jcl_filename), erb.result(binding))

    ssh = ssh_socket
    return false unless ssh

    begin
      ssh.scp.upload!(add_path(@@temporary_jcl_filename), '.temporary.jcl')
      ssh.scp.upload!(absolute_path(@@submit_rexx_filename), '.submit.rex')
      File.write(add_path(@@temporary_joblog_filename),
                 ssh.exec!(
                   'tr -d "\r" < .temporary.jcl > .temporary1.jcl ; ' \
                   'tr -d "\r" < .submit.rex > .submit1.rex ; ' \
                   'chmod +x .submit1.rex ; ' \
                   './.submit1.rex'
                 ))

      @@log.info p "submit_and_download #{command_line}"
      File.open(add_path(@@temporary_joblog_filename),
                invalid: :replace) do |input|
        File.open(add_path(command_line), 'w') do |output|
          found = false
          input.read.scrub.each_line do |line|
            found = true if eye_catcher && line.match(/#{eye_catcher}/)
            output.puts line if found
            found = true if eye_catcher.nil? && line.include?(command_line)
          end
        end
      end
    rescue StandardError => e
      @@log.warn p "Execute error: filename = #{filename}"
      @@log.error p e.message
      @@log.error p e.backtrace
      ssh.close
      @@sockets[ZOS_function.directory_path] = nil
    end
  end

  def submit_and_store(jcl_dataset, joblog_dataset)
    @jcl_dataset = jcl_dataset
    @joblog_dataset = joblog_dataset
    ftp_common(@@submit_store_jcl_filename, joblog_dataset) do
      @@log.info p "submit_and_store #{jcl_dataset}"
      File.rename(
        add_path(@@temporary_joblog_filename),
        add_path(joblog_dataset)
      )
    end
  end
end
