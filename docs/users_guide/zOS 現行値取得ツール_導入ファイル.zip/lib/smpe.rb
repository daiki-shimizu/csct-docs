# Provide information on SMPE.
class SMPE
  def self.smptlib_prefix(globalcsi = smp_global_csi_dataset_name)
    if globalcsi
      submit_jcl('listdddef.jcl.erb', 'SMPCSI DD DISP=SHR,DSN=' + globalcsi) \
        .scan(/DSPREFIX        = (\w+)/)
    else
      undefined_message
    end
  end

  def self.smptlib_vol(globalcsi = smp_global_csi_dataset_name)
    if globalcsi
      submit_jcl('listdddef.jcl.erb', 'SMPCSI DD DISP=SHR,DSN=' + globalcsi) \
        .scan(/VOLUME          = (\w+)/)
    else
      undefined_message
    end
  end
end
