# Provide information on PAGELOCAL.
class PAGELOCAL
  def self.datasets
    NamesFactory.create(
      syscmd_ulog('D ASM').to_s.scan(/^LOCAL.+ (#{dataset_regexp})$/).flatten
    )
  end

  def self.volumes
    NamesFactory.create(
      datasets.collect do |item|
        submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{item}\') ALL") \
          .scan_volser_hyphen
      end
    )
  end

  def self.size
    NamesFactory.create(
      datasets.collect { |dsname| SYSTEM_DATASET.dataset_size_vsam(dsname) }
    )
  end
end
