# Provide information on MSTJCLxx.
class MSTJCLxx
  def self.content
    ParmlibContentFactory.collect(ParmlibSuffix.mstjcl)
  end

  def self.iefpdsi_datasets
    target_datasets(content, 'IEFPDSI')
  end
end
