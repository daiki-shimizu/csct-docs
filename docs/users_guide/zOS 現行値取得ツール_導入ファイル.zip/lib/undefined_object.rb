# UndefinedObject
class UndefinedObject < String
  def initialize
    super(undefined_message)
  end

  def scan(*)
    nil
  end

  def scan_array(*)
    []
  end

  def scan_suffix(*)
    SuffixFactory.create(nil)
  end

  def get_suffix_list(parameter_name)
    SuffixFactory.create(nil).add_prefix(
      parameter_to_prefix_hash.fetch(parameter_name.to_sym, '')
    )
  end

  def scan_command_prefix(*)
    self
  end

  def scan_dataset(*)
    self
  end

  def |(other)
    other
  end

  def defined?
    false
  end
end
