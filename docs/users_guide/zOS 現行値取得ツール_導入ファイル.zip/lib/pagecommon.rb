# Provide information on PAGECOMMON.
class PAGECOMMON
  def self.datasets
    syscmd_ulog('D ASM').scan(/COMMON.+ (#{dataset_regexp})/)
  end

  def self.volumes
    submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{datasets}\') ALL") \
      .scan_volser_hyphen
  end

  def self.size
    if special_value?(datasets)
      undefined_message
    else
      SYSTEM_DATASET.dataset_size_vsam(datasets)
    end
  end
end
