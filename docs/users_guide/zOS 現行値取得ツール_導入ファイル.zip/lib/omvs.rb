# Provide information on OMVS.
class OMVS
  def self.root_entries_name
    root_filesystem_name
  end

  def self.root_filesystem_name
    filesystem_name =
      syscmd_ulog('D OMVS,F').scan(/ 1 ACTIVE .+?NAME=(#{dataset_regexp})/m)
    if special_value?(filesystem_name)
      BPXPRMxx.content.scan(/ROOT\s+?FILESYSTEM\('(#{dataset_regexp})'\)/m)
    else
      filesystem_name
    end
  end

  def self.superuser
    syscmd_ulog('D OMVS,OPTIONS').scan(/SUPERUSER       = ([\(\)\w\,]+)/)
  end

  def self.root_filesystem_type
    BPXPRMxx.content.scan(/ROOT.+?TYPE\((\w{1,8})\)/m)
  end

  def self.root_filesystem_volumes
    submit_jcl(
      'listcat.jcl.erb',
      "LISTC ENT(\'#{root_filesystem_name}\') ALL"
    ).scan_volser_hyphen
  end

  def self.root_filesystem_size
    SYSTEM_DATASET.dataset_size_vsam(root_filesystem_name)
  end
end
