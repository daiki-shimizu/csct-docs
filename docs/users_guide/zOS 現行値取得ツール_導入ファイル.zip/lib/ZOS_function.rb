#! ruby -Ku
require 'json'
require_relative 'defined_object'
require_relative 'undefined_object'

# ZOS_function module is a collection of utilities for developers.
module ZOS_function
  @@directory_path = nil
  @@force_read = false
  @@syslog_dataset_name = nil
  @@smp_global_csi_dataset_name = nil
  @@syscmd_method = nil
  @@local_mode = false
  @@accessed_files = []
  @@vtoclist_jcl_filename = nil

  module_function

  extend ZOS_FTP

  def directory_path=(val)
    self.syslog_dataset_name = 'SYSLOG'
    self.smp_global_csi_dataset_name = nil
    ZOS_FTP.ipaddress = nil
    ZOS_FTP.userid = nil
    ZOS_FTP.password = nil
    ZOS_FTP.ftp_port = 21
    ZOS_FTP.ssh_port = 22
    ZOS_FTP.ssh_key = nil
    ZOS_FTP.job_statements_jcl_filename = 'job_statements_jcl.erb'
    ZOS_FTP.syscmd_jcl_erb_filename = 'syscmd.jcl.erb'
    ZOS_FTP.syscmd_ulog_jcl_erb_filename = 'syscmd.ulog.jcl.erb'
    ZOS_FTP.syscmd_rexx_erb_filename = 'syscmd.rexx.erb'
    ZOS_FTP.submit_store_jcl_filename = 'submit_store.jcl.erb'
    ZOS_FTP.console_name = '@SMART@'
    ZOS_FTP.connection_type = 'FTP'
    ZOS_function.syscmd_method = nil
    @@accessed_files = []
    ZOS_function.vtoclist_jcl_filename = 'vtoclist.jcl.erb'

    @@directory_path = val
    environment_variables_hash[val].to_a.each do |array|
      eval(array)
    end
    Dir.mkdir(add_path('')) unless File.exist?(add_path(''))
    log_initialize
  end

  def environment_variables_hash
    File.open(ZOS_FTP.absolute_path('ZOS_env.json'), 'r:BOM|UTF-8') do |file|
      JSON.parse(file.read)
    end
  end

  def directory_path
    @@directory_path
  end

  def syslog_dataset_name=(val)
    @@syslog_dataset_name = val
  end

  def syslog_dataset_name
    @@syslog_dataset_name
  end

  def smp_global_csi_dataset_name=(val)
    @@smp_global_csi_dataset_name = val
  end

  def smp_global_csi_dataset_name
    @@smp_global_csi_dataset_name
  end

  def force_read=(flag)
    @@force_read = flag
  end

  def local_mode=(flag)
    @@local_mode = flag
  end

  def local_mode
    @@local_mode
  end

  def accessed_files
    @@accessed_files
  end

  def accessed_files_output
    accessed_files.uniq.sort.select do |file|
      file[0] != '!' || !accessed_files.include?(file[1..-1])
    end
  end

  def syscmd_method=(val)
    if %w(ULOG GETMSG ISFEXEC).include?(val)
      @@syscmd_method = val
      if val == 'GETMSG'
        ZOS_FTP.syscmd_jcl_erb_filename = 'syscmd.jcl.erb'
      else
        ZOS_FTP.syscmd_jcl_erb_filename = 'syscmd.isfexec.jcl.erb'
      end
    end
  end

  def syscmd_method
    @@syscmd_method
  end

  def vtoclist_jcl_filename=(filename)
    @@vtoclist_jcl_filename = filename
  end

  def vtoclist_jcl_filename
    @@vtoclist_jcl_filename
  end

  def downloaded?(filename)
    File.exist?(add_path(filename)) && !File.zero?(add_path(filename)) \
      && !@@force_read
  end

  def not_exist?(filename)
    @@accessed_files << '!' + filename
    File.exist?(add_path('!' + filename))
  end

  def readout(filename)
    @@accessed_files << filename
    if File.exist?(add_path(filename))
      File.read(add_path(filename), textmode: true).scrub
    else
      ''
    end
  end

  def success?(filename)
    downloaded?(filename) && readout(filename).include?('Successfully')
  end

  # Returns the content of a dataset whose name is the specified dataset_name.
  # When "on demand loading" is enabled and the content has already been
  # downloaded, the content of the downloaded file comes immediately. The
  # content is saved as `dataset_name` in directory designated by
  # zos_function.directory_path.
  def dataset(dataset_name)
    download(dataset_name) unless downloaded?(dataset_name)
    readout(dataset_name)
  end

  # Returns the content of SYSLOG at z/OS IPL.  If "on demand loading" is
  # enabled and the content has already been downloaded, the content of
  # the downloaded file comes immediately.  The content is saved as the
  # dataset name in directory designated by zos_function.directory_path.
  def syslog
    if syslog_dataset_name
      download(syslog_dataset_name) unless downloaded?(syslog_dataset_name)
      JobLogFactory.create(syslog_dataset_name)
    else
      EmptyJobLog.new
    end
  end

  # Calling execute_and_download() in ZOS_FTP library, execute an MVS command
  # by SYSCMD/GETSMG command and returns the output. `command_line` is an MVS
  # command that should be executed. If "on demand loading" is enabled and the
  # output has already been downloaded, the content of the downloaded file
  # comes immediately. The output is saved as `command_line` in directory
  # designated by zos_function.directory_path.
  def syscmd(command_line, options={})
    unless downloaded?(command_line)
      if syscmd_method.nil? || syscmd_method == 'ULOG'
        execute_and_download_ulog(command_line)
      else
        execute_and_download(command_line, options)
      end
    end
    JobLogFactory.create(command_line)
  end

  alias_method :syscmd_ulog, :syscmd

  # Calling submit_and_download() in ZOS_FTP library, submit a JCL and return
  # the job log. ` jcl_erb_filename` is an ERB file name that is submitted.
  # This replaces @commnad_line with `command_line`. It returns the portion of
  # the content after `command_line` matches if `eye_catcher` of options is nil.
  # Otherwise, it returns the one after `eye_catcher` as well as the match
  # line. The one is saved as `command_line` in directory designated by
  # zos_function.directory_path.
  def submit_jcl(jcl_erb_filename, command_line, options={})
    return EmptyJobLog.new if not_exist?(command_line)

    unless downloaded?(command_line)
      submit_and_download(jcl_erb_filename, command_line, options)
    end
    JobLogFactory.create(command_line)
  end

  def submit_jcl_store_joblog(jcl_dataset, joblog_dataset)
    unless success?(joblog_dataset)
      submit_and_store(jcl_dataset, joblog_dataset)
    end
    success?(joblog_dataset)
  end

  def datasets_member_name(datasets, member_name)
    datasets_member_names(datasets, [member_name])
  end

  # Returns an array of the names of a dataset containing a dataset member.
  # This trys to find `member_name` in concatenated `datasets` and returns
  # the dataset name if it finds the member in a dataset. If "on demand
  # loading" is enabled and the content has already been downloaded, the
  # content of the downloaded file comes immediately. The content is saved
  # as "datasets(dataset_name)" in directory designated by
  # zos_function.directory_path.
  def datasets_member_names(datasets, member_names)
    member_names = [member_names] if member_names.is_a?(String)
    dataset_member_array = []
    member_names.each do |member_name|
      datasets.each do |dataset_name|
        concat_dataset_name = dataset_name + '(' + member_name + ')'
        if @@local_mode
          dataset_member_array << concat_dataset_name
          break
        end
        next if not_exist?(concat_dataset_name)
        if downloaded?(concat_dataset_name) || download(concat_dataset_name)
          dataset_member_array << concat_dataset_name
          break
        end
      end
    end
    NamesFactory.create(dataset_member_array)
  end

  def parmlib_member_names(prefix, suffix)
    datasets_member_names(
      PARMLIB.datasets,
      suffix.add_prefix(prefix).attach_prefix
    )
  end

  def iplparm_member_names(prefix, suffix)
    datasets_member_names(
      ['SYS1.IPLPARM'],
      suffix.add_prefix(prefix).attach_prefix
    )
  end

  # Returns the content of a dataset member in concatenated datasets. This
  # automatically trys to find `member_name` in concatenated `datasets` and
  # returns the content if it finds the member in a dataset. If "on demand
  # loading" is enabled and the content has already been downloaded, the
  # content of the downloaded file comes immediately. The content is saved
  # "datasets(dataset_name)" in directory designated by
  # zos_function.directory_path.
  def datasets_member(datasets, member_name)
    concat_dataset_name = datasets_member_name(datasets, member_name).first
    concat_dataset_name ? readout(concat_dataset_name) : nil
  end

  # Returns an array of the concatenated dataset names that are corresponding
  # to the `ddname`. `content` is the content of a JCL that has `ddname`.
  def target_datasets(content, ddname)
    dsnames = []
    found = false
    content.to_s.each_line do |line|
      break if found && !line.start_with?('// ')
      found = true if line.start_with?('//' + ddname + ' ')
      dsname = line.scan(/DSN=(#{dataset_member_regexp})/)
      if found
        dsnames << dsname.first.first unless dsname.empty?
      end
    end
    NamesFactory.create(dsnames)
  end

  def command_prefix(owner)
    syscmd_ulog('D O').scan_command_prefix(/^ (\S+)\s+#{owner}/)
  end

  def undefined_message
    '定義なし'
  end

  def required_message
    '入力をお願いします'
  end

  def not_active_message
    '稼動していません'
  end

  def default_value_message
    '省略時値'
  end

  def not_found_message
    '取得できませんでした'
  end

  def non_supported_message
    '‐'
  end

  def special_value?(value)
    case value
    when undefined_message, required_message, not_active_message, \
      not_found_message, non_supported_message
      true
    else
      false
    end
  end

  def volser_regexp
    '[\w\@\#\$]{1,6}'
  end

  def dataset_regexp
    '[a-zA-Z\@\#\$][\w\@\#\$\.]{1,43}'
  end

  def hlq_regexp
    '[\w\@\#\$]{1,8}'
  end

  def dataset_member_regexp
    '[\w\@\#\$\.\(\)&]{1,54}'
  end

  def member_regexp
    '[\w\@\#\$]{1,8}'
  end

  def tod_regexp
    '\d+\/\d+\/\d+ \d+:\d+:\d+'
  end

  def device_regexp
    '\h{,5}'
  end

  def suffix_regexp
    '\(?([\w\@\#\$\*]+(?:,[\w\@\#\$\*]+)*)\)?'
  end

  def two_digit_suffix_regexp
    '[\w\@\#\$]{2}'
  end

  def jcl_name_field_regexp
    '^\/\/[\w\$\#\@\s]{1,8}'
  end

  def substitution_text_regexp
    %q!\(.{0,255}?\)|'.{0,255}?'|[\w\$\#\@\(\)\.]{0,255}!
  end

  def console_name_regexp
    '[\w\@\#\$]{2,8}'
  end

  def sysname_regexp
    '[\w\@\#\$]{1,8}'
  end

  def sysplex_name_regexp
    '[\w\@\#\$]{1,8}'
  end

  def parameter_to_prefix_hash
    { ALLOC: 'ALLOC',
      APF: 'IEAAPF',
      APPC: 'APPCPM',
      ASCH: 'ASCHPM',
      AUTOR: 'AUTOR',
      AXR: 'AXR',
      CATALOG: 'IGGCAT',
      CEA: 'CEAPRM',
      CEE: 'CEEPRM',
      CLOCK: 'CLOCK',
      CMD: 'COMMND',
      CON: 'CONSOL',
      COUPLE: 'COUPLE',
      CNGRP: 'CNGRP',
      CNIDTR: 'CNIDTR',
      DAE: 'ADYSET',
      DEVSUP: 'DEVSUP',
      DIAG: 'DIAG',
      DLF: 'COFDLF',
      EXIT: 'EXIT',
      EXS: 'EXSPAT',
      FIX: 'IEAFIX',
      GRSCNF: 'GRSCNF',
      GRSRNL: 'GRSRNL',
      HZS: 'HZSPRM',
      HZSPROC: 'HZSPRM',
      ICEPRM: 'ICEPRM',
      ICS: 'IEAICS',
      IDAVDT: 'IDAVDT',
      IOS: 'IECIOS',
      IKJTSO: 'IKJTSO',
      IPS: 'IEAIPS',
      IXGCNF: 'IXGCNF',
      LLA: 'CSVLLA',
      LNK: 'LNKLST',
      LPA: 'LPALST',
      MLPA: 'IEALPA',
      MMS: 'MMSLST',
      MPF: 'MPFLST',
      MSGFLD: 'MSGFLD',
      MSTRJCL: 'MSTJCL',
      OMVS: 'BPXPRM',
      OPT: 'IEAOPT',
      PAK: 'IEAPAK',
      PFK: 'PFKTAB',
      PROG: 'PROG',
      RTLS: 'CSVRTL',
      SCH: 'SCHED',
      SLIP: 'IEASLP',
      SMF: 'SMFPRM',
      SMS: 'IGDSMS',
      SSN: 'IEFSSN',
      SVC: 'IEASVC',
      UNI: 'CUNUNI',
      VAL: 'VATLST',
      VLF: 'COFVLF' }
  end

  def add_path(filename)
    if defined?(Rails)
      File.join(
        Rails.root.instance_values['path'],
        'app/zos_standard_library',
        ZOS_function.directory_path,
        filename.gsub(/[\\\/\?:\*\"\>\<\|]/, '_')
      )
    else
      File.join(
        File.expand_path('../..', __FILE__),
        ZOS_function.directory_path,
        filename.gsub(/[\\\/\?:\*\"\>\<\|]/, '_')
      )
    end
  end
end
