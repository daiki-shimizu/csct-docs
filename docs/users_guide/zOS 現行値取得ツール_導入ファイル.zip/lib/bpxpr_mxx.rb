# Provides information on BPXPRMxx.
class BPXPRMxx
  def self.content
    ParmlibContentFactory.collect(ParmlibSuffix.bpxprm)
  end
end
