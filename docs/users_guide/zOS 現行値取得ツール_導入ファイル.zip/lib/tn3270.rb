# Provide information on TN3270.
class TN3270
  MESSAGE_ID = 'EZAOP60I'.freeze

  def self.display_telnet
    syscmd_ulog("D TCPIP,TELNET")
  end
  
  def self.procnames
    if display_telnet.scan(/#{MESSAGE_ID}/)
      NamesFactory.create(
        display_telnet.to_s.scan(/^(#{member_regexp})\s+CS V\dR\d+ /).flatten
      )
    elsif datasets_member_names(JES2.proc00_datasets, 'TN3270').empty?
      NamesFactory.create([])
    else
      NamesFactory.create(['TN3270'])
    end
  end

  def self.dataset_names
    datasets_member_names(JES2.proc00_datasets, procnames)
  end

  def self.profile_names
    NamesFactory.create(
      dataset_names.collect do |name|
        target_datasets(
          StartedProcedureFactory.create(dataset(name)),
          'PROFILE'
        ).first
      end
    )
  end

  def self.tcpdata_name
    TCPIP.tcpdata_names.first
  end

  def self.portno
    NamesFactory.create(
      profile_names.collect do |profile|
        ProfileContentFactory.create(dataset(profile)).scan(/TelnetParms.+?Port\s+(\d+).+EndTelnetParms/m)
      end
    )
  end
end
