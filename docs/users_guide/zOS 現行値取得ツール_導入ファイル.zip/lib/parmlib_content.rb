# ParmlibContent
require_relative 'system_symbols'

class ParmlibContent < DefinedObject
  include SystemSymbols

  def initialize(contents)
    contents = [contents] if contents.is_a?(String)

    super(
      contents.collect do |content|
        use_system_symbols(remove_comments(remove_sequence_numbers(content)))
      end.compact.join
    )
  end

  def scan_content(regexp)
    DatasetFactory.create(scan(regexp))
  end

  private

  def remove_comments(content)
    content.gsub(/\/\*.+?\*\//m, '').gsub(/^\*.*$/, '').gsub(/^\s*$/, '')
  end

  def remove_sequence_numbers(content)
    content.lines.inject('') do |lines, line|
      lines + line[0..71].strip + "\n"
    end
  end
end
