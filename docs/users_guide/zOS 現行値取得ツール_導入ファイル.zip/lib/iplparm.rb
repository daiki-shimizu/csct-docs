# Provides information on IPLPARM.
class IPLPARM
  def self.content
    syscmd_ulog('D IPLINFO')
  end

  def self.member_name
    content.scan(/USED (LOAD#{two_digit_suffix_regexp})/)
  end

  def self.dataset_name
    content
      .scan(/USED LOAD#{two_digit_suffix_regexp} IN (#{dataset_regexp})/)
  end

  def self.release
    content.scan(%r{(?:z/OS|OS/390) [\d\.]+})
  end
end
