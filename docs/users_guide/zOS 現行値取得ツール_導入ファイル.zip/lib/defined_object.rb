# DefinedObject is an string whose content is not empty.
class DefinedObject < String
  def initialize(content)
    super(content)
  end

  def scan(regexp)
    to_s.scan(regexp).flatten.first
  end

  def scan_array(regexp)
    to_s.scan(regexp).flatten
  end

  def scan_suffix(regexp)
    SuffixFactory.create(scan(regexp))
  end

  def get_suffix_list(parameter_name)
    list =
      to_s.scan(/#{parameter_name}\s*[=:]\s*#{suffix_regexp}/).flatten.first
    SuffixFactory \
      .create(list) \
      .add_prefix(parameter_to_prefix_hash.fetch(parameter_name.to_sym, ''))
  end

  def scan_command_prefix(regexp)
    CommandPrefixFactory.create(scan(regexp))
  end

  def scan_dataset(regexp)
    DatasetFactory.create(scan(regexp))
  end

  def |(*)
    self
  end

  def defined?
    true
  end
end
