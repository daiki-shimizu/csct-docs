# Provide information on SYSTEM Dataset.
class SYSTEM_DATASET
  def self.dataset_size(dsname, volume)
    return undefined_message if special_value?(dsname) || special_value?(volume)

    vtoc_list =
      submit_jcl(
        ZOS_function.vtoclist_jcl_filename,
        volume,
        eye_catcher: '^DSN ',
        volume: volume
      )
    vtoc_array =
      vtoc_list.scan_array(
        /#{dsname}.+(CYL|TRK|BLK)\s+(\d+)\s+(\d+)(?:\s+\d+|\s+\?){3}(.{6})/
      )

    if vtoc_array.empty?
      not_found_message
    else
      vtoc_array.first.to_s + \
        "(#{vtoc_array[1]},#{vtoc_array[2]},#{vtoc_array[3].strip})" \
        .gsub(',)', ')')
    end
  end

  def self.ikjtso_send
    syscmd_ulog('D IKJTSO,SEND')
  end

  def self.dataset_size_vsam(dsname)
    return undefined_message if special_value?(dsname)

    cat_list = submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{dsname}\') ALL")
    cat_array =
      cat_list.scan_array(/(?:SPACE-TYPE|SPACE-PRI|SPACE-SEC)\-+(\w+)/)

    if cat_array.empty?
      not_found_message
    else
      cat_array[0..2].join(',') \
                     .gsub(/CYLINDER\,/, 'CYL(') \
                     .gsub(/TRACK\,/, 'TRK(') + ')'
    end
  end
end
