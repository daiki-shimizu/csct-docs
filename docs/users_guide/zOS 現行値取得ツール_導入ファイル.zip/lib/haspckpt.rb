# Provides information on HASPCKPT.
class HASPCKPT
  def self.datasets
    syscmd_ulog('$DCKPTDEF').scan(/CKPT1=\(DSNAME=(#{dataset_regexp})/)
  end

  def self.volumes
    syscmd_ulog('$DCKPTDEF') \
      .scan(/CKPT1=\(DSNAME=#{dataset_regexp},VOLSER=(#{volser_regexp})/)
  end

  def self.size
    if special_value?(datasets) || special_value?(volumes)
      undefined_message
    else
      SYSTEM_DATASET.dataset_size(datasets, volumes)
    end
  end
end
