# Provides the datasets, volumes and size of DUMP.
require_relative 'system_symbols'

class DUMP
  extend SystemSymbols

  def self.datasets
    dsnames = []
    case syscmd_ulog('D DUMP,S').scan(/AUTOMATIC ALLOCATION IS: (\w+)/)
    when 'INACTIVE' then
      dsnames =
        syscmd_ulog('D DUMP,S').to_s.scan(
          /SYS1.DUMP (?:AVAILABLE|FULL) [\s\w]*(?:\:)* ([\d\-\,]+)/
        ).join(',').split(',')
      dsnames.collect do |item|
        (item.split(/-/).first..item.split(/-/).last).collect do |num|
          num
        end
      end.flatten.sort
    when 'ACTIVE' then
      dsnames.push(
        use_system_symbols(
          syscmd_ulog('D DUMP,S').scan(/NAME=([\w\@\#\$\&\.]+)/)
        )
      )
    else
      dsnames.fill(undefined_message, 0..2)
    end
  end

  def self.volumes
    volumes = []
    case syscmd_ulog('D DUMP,S').scan(/AUTOMATIC ALLOCATION IS: (\w+)/)
    when 'INACTIVE' then
      volumes = DUMP.datasets.collect do |item|
        ('SYS1.DUMP' + item).delete("'")
      end
      volumes.collect do |item|
        submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{item}\') ALL") \
          .scan_volser_hyphen
      end
    when 'ACTIVE' then
      if syscmd_ulog('D DUMP,S').to_s.scan(/NO DASD VOLUMES DEFINED/).first.nil?
        volumes.push(syscmd_ulog('D DUMP,S') \
          .scan(/AVAILABLE DASD VOLUMES: ([\w\@\#\$\,]+)/))
      else
        volumes.push(undefined_message)
      end
    else
      volumes.fill(undefined_message, 0..2)
    end
  end

  def self.size
    sizes = []
    case syscmd_ulog('D DUMP,S').scan(/AUTOMATIC ALLOCATION IS: (\w+)/)
    when 'INACTIVE' then
      dump_dsname_array_temp = DUMP.datasets.collect do |item|
        ('SYS1.DUMP' + item).delete("'")
      end
      dump_volume_array_temp = DUMP.volumes
      sizes = dump_dsname_array_temp.zip(dump_volume_array_temp)
      sizes.collect do |dsname, volume|
        SYSTEM_DATASET.dataset_size(dsname, volume)
      end
    when 'ACTIVE' then
      sizes.push(undefined_message)
    else
      sizes.fill(undefined_message, 0..2)
    end
  end
end
