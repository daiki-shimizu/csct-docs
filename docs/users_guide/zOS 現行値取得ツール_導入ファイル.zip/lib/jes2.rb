# Provides information on JES2.
class JES2
  def self.procname
    'JES2'
  end

  def self.content
    StartedProcedureFactory \
      .create(datasets_member(MSTJCLxx.iefpdsi_datasets, procname), procname)
  end

  def self.dataset_name
    datasets_member_name(MSTJCLxx.iefpdsi_datasets, procname)
  end

  def self.parm_ddname(content)
    content.scan(
      /^COM='(?:S|START) #{procname}.+,HASPPARM=(#{member_regexp})/
    ) || 'HASPPARM'
  end

  def self.proc00_datasets
    target_datasets(content, 'PROC00')
  end

  def self.haspparm_datasets
    target_datasets(content, parm_ddname(COMMNDxx.content))
  end

  def self.ownname
    syscmd_ulog('$DNJEDEF').scan(/OWNNAME=(\w+)/)
  end

  def self.ownnode
    syscmd_ulog('$DNJEDEF').scan(/OWNNODE=(\d+)/)
  end

  def self.mode
    syscmd_ulog('$DACTIVATE') \
      .scan(/\$HASP895 JES2 CHECKPOINT MODE IS CURRENTLY ([\w\.+]+)/) \
      ||'NO'
  end

  def self.exit5
    if syscmd_ulog('$DEXIT(5)').scan(/STATUS=([\w\.+]+)/) == 'DISABLED'
      'NO'
    else
      'YES'
    end
  end
end
