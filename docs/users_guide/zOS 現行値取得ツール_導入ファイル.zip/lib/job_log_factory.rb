# JobLogFactory
class JobLogFactory
  def self.create(filename)
    File.exist?(add_path(filename)) ? JobLog.new(readout(filename)) : EmptyJobLog.new
  end
end
