# Provide information on SYSLOG.
class SYSLOG
  def self.parmlib_suffix_iee252i(member)
    SuffixFactory \
      .create(syslog.to_s.scan(/IEE252I MEMBER #{member}(\w+)/).uniq.join(','))
  end

  def self.parmlib_search_iee252i(member)
    syslog.to_s.scan(/IEE252I MEMBER #{member}/).first ? 'YES' : 'NO'
  end

  def self.parmlib_search_startcmd(member)
    syslog.to_s.scan(/(?:S|START) #{member}/).first ? 'YES' : 'NO'
  end
end
