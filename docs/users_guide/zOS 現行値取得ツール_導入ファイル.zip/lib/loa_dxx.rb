# Provide infomation on LOADxx.
class LOADxx
  def self.content
    ParmlibContentFactory.create_loadxx(
      dataset(IPLPARM.dataset_name + '(' + IPLPARM.member_name + ')')
    )
  end

  def self.sysplex_name
    content.scan(/SYSPLEX  (#{sysplex_name_regexp})/)
  end

  def self.syscat_dsn
    content.scan(/^SYSCAT.{13}(#{dataset_regexp})/)
  end

  def self.syscat_volume
    content.scan(/^SYSCAT.{3}(#{volser_regexp})/)
  end

  def self.mcat_size
    SYSTEM_DATASET.dataset_size_vsam(syscat_dsn)
  end
end
