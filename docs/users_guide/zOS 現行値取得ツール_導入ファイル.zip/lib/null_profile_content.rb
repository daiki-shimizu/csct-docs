# NullProfileContent
class NullProfileContent < UndefinedObject
  def to_s
    ''
  end
end
