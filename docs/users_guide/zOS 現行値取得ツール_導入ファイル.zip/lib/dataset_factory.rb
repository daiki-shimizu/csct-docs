# DatasetFactory
class DatasetFactory
  def self.create(name)
    name ? Dataset.new(name) : NullDataset.new
  end
end
