# UndefinedCommandPrefix
class UndefinedCommandPrefix < UndefinedObject
end
