require_relative 'started_procedure'
require_relative 'null_started_procedure'

# Factory method for StartedProcedure / NullStartedProcedure.
class StartedProcedureFactory
  def self.create(content, procname='')
    if content && !content.empty?
      StartedProcedure.new(content, procname)
    else
      NullStartedProcedure.new
    end
  end
end
