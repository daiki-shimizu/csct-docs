# Provide information on UADS.
class UADS
  def self.datasets
    target_datasets(MSTJCLxx.content, 'SYSUADS').first || 'SYS1.UADS'
  end

  def self.volumes
    submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{datasets}\') ALL") \
      .scan_volser_hyphen
  end

  def self.size
    if special_value?(datasets) || special_value?(volumes)
      undefined_message
    else
      SYSTEM_DATASET.dataset_size(datasets, volumes)
    end
  end
end
