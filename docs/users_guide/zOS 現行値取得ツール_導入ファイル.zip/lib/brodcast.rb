# Provides the datasets, volumes and size for BRODCAST dataset.
class BRODCAST
  def self.datasets
    SYSTEM_DATASET.ikjtso_send.scan(/BROADCAST\(DATASET\(([\w\@\#\$\.]+)/)
  end

  def self.volumes
    SYSTEM_DATASET.ikjtso_send.scan(/VOLUME\((#{volser_regexp})/)
  end

  def self.size
    SYSTEM_DATASET.dataset_size(datasets, volumes)
  end
end
