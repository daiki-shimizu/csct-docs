# Suffix
class Suffix < DefinedObject
  include ZOS_function
  attr_reader :prefix, :negative_keywords

  def initialize(list)
    @prefix ||= ''
    @negative_keywords ||= []
    super(list.scan(/#{suffix_regexp}/).flatten.first)
  end

  def set_default_suffix
    self
  end

  def set_rmf3_default_suffix
    self
  end

  def add_suffix(suffix)
    initialize((split(',') | suffix.split(',')).join(','))
  end

  def add_default_suffix
    add_suffix('00')
  end

  def split_suffix
    split(',').select { |s| s.length == 2 } \
      - @negative_keywords
  end

  def add_prefix(prefix)
    @prefix = prefix
    self
  end

  def attach_prefix
    NamesFactory.create(split_suffix.collect { |s| @prefix + s })
  end

  def add_negative_keywords(keywords)
    keywords = [keywords] if keywords.is_a?(String)
    @negative_keywords = keywords
    self
  end

  def parmlib_names
    NamesFactory.create(
      datasets_member_names(PARMLIB.datasets, attach_prefix)
    )
  end

  def sys1_parmlib_names
    NamesFactory.create(
      datasets_member_names(['SYS1.PARMLIB'], attach_prefix)
    )
  end

  def iplparm_names
    NamesFactory.create(
      datasets_member_names([IPLPARM.dataset_name], attach_prefix)
    )
  end
end
