# Provide information on SMF.
class SMF
  def self.smf_datasets
    (syscmd_ulog('D SMF').to_s.scan(/[PS]\-(#{dataset_regexp})/) \
      << [undefined_message] * 3).flatten[0..2]
  end

  def self.volumes
    (syscmd_ulog('D SMF').to_s \
      .scan(/[PS]\-#{dataset_regexp}\s+(#{volser_regexp})/) \
      << [undefined_message] * 3).flatten[0..2]
  end

  def self.size
    smf_datasets.collect do |dsname|
      if dsname == undefined_message
        undefined_message
      else
        SYSTEM_DATASET.dataset_size_vsam(dsname)
      end
    end
  end
end
