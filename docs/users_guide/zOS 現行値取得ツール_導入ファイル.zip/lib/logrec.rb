# Provide information on LOGREC.
module LOGREC
  module_function

  extend ZOS_function

  def datasets
    if syscmd_ulog('D LOGREC,ALL').scan(/CURRENT MEDIUM = (\w+)/) == 'IGNORE'
      undefined_message
    elsif syscmd_ulog('D LOGREC,ALL').scan(/DATASET MEDIUM = NOT DEFINED/)
      'SYS1.LOGREC'
    else
      syscmd_ulog('D LOGREC,ALL') \
        .scan(/DATASET MEDIUM = (#{dataset_regexp})/) || undefined_message
    end
  end

  def volumes
    if special_value?(datasets)
      undefined_message
    else
      submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{datasets}\') ALL") \
        .scan_volser_hyphen
    end
  end

  def size
    if special_value?(datasets) || special_value?(volumes)
      undefined_message
    else
      SYSTEM_DATASET.dataset_size(datasets, volumes)
    end
  end
end
