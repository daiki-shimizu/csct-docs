# Provide information on TCPIP.
class TCPIP
  def self.procnames
    NamesFactory.create(
      syscmd_ulog('D TCPIP').to_s.scan(/^\s+\d+\s+(\w+)\s/).flatten
    )
  end

  def self.content(procname)
    StartedProcedureFactory.create(
      datasets_member(JES2.proc00_datasets, procname)
    )
  end

  def self.dataset_names
    NamesFactory.create(
      procnames.collect do |procname|
        datasets_member_name(JES2.proc00_datasets, procname)
      end.flatten
    )
  end

  def self.profile_names
    NamesFactory.create(
      procnames.collect do |procname|
        target_datasets(content(procname), 'PROFILE')
      end.flatten
    )
  end

  def self.tcpdata_names
    NamesFactory.create(procnames.collect do |procname|
      content(procname).resolver_config ||
        target_datasets(content(procname), 'SYSTCPD').first
    end)
  end
end
