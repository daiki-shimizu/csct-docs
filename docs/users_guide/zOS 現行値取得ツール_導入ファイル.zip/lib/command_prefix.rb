# CommandPrefix
class CommandPrefix < DefinedObject
end
