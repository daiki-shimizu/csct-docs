require_relative 'defined_names'
require_relative 'undefined_names'

# Factory method for DefinedNames and UndefinedNames classes.
class NamesFactory
  def self.create(content)
    if content && !content.compact.empty?
      DefinedNames.new(content.compact)
    else
      UndefinedNames.new
    end
  end
end
