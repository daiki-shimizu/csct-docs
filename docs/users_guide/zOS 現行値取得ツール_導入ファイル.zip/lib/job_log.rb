# JobLog
class JobLog < DefinedObject
  def scan_volser_colon
    to_s.scan(/VOLSER:\s+(#{volser_regexp})/) \
        .push([undefined_message] * 3).flatten[0..2]
  end

  def scan_dataset_colon
    to_s.scan(/DSN:\s+(#{dataset_regexp})/) \
        .push([undefined_message] * 3).flatten[0..2]
  end

  def scan_volser_hyphen
    to_s.scan(/VOLSER\-+(#{volser_regexp})/).flatten.first \
      || undefined_message
  end
end
