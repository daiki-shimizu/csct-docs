# UndefinedSuffix
class UndefinedSuffix < UndefinedObject
  attr_reader :prefix

  def initialize
    @prefix ||= ''
    @negative_keywords ||= []
    super
  end

  def set_default_suffix
    add_suffix('00')
  end

  def set_rmf3_default_suffix
    add_suffix('04')
  end

  def add_suffix(suffix)
    SuffixFactory.create(suffix.to_s).add_prefix(@prefix) \
      .add_negative_keywords(@negative_keywords)
  end

  def add_default_suffix
    set_default_suffix
  end

  def split_suffix
    []
  end

  def add_prefix(prefix)
    @prefix = prefix
    self
  end

  def attach_prefix
    NamesFactory.create([])
  end

  def add_negative_keywords(keywords)
    keywords = [keywords] if keywords.is_a?(String)
    @negative_keywords = keywords
    self
  end

  def negative_keywords
    @negative_keywords
  end

  def parmlib_names
    NamesFactory.create([])
  end

  def sys1_parmlib_names
    NamesFactory.create([])
  end

  def iplparm_names
    NamesFactory.create([])
  end
end
