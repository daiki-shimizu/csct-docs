require_relative 'parmlib_content'

# IeasysxxContent
class IeasysxxContent < ParmlibContent
  def remove_comments(content)
    lines = ''
    content.each_line do |line|
      next if line[0] == '*'
      parameter = line.scan(/^\s*(\S+)/).flatten.first
      lines += parameter + "\n"
      break unless parameter[/,$/]
    end
    lines
  end
end
