# Provides information on LE.
class LE
  def self.ceeprm_dataset
    ParmlibSuffix.ceeprm.parmlib_names.join
  end
end
