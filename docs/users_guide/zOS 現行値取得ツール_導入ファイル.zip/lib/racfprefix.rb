# Provide information on RACFPREFIX.
class RACFPREFIX
  def self.name
    command_prefix('RACF') | \
      IEFSSNxx.content.scan_command_prefix(
        /RACF.+?INITPARM\('(.+?)(?:,.+?)*'\)/m
      ) | CommandPrefixFactory.create('RACF ')
  end
end
