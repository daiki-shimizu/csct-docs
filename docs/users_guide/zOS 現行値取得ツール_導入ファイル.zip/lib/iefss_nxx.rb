# Provides information on IEFSSNxx.
class IEFSSNxx
  def self.content
    ParmlibContentFactory.collect(ParmlibSuffix.iefssn)
  end

  def self.subnames
    content.split(/^SUBSYS /).collect do |item|
      item.scan(/SUBNAME\((#{subname_regexp})\)/)
    end.compact
  end

  def self.params(subname)
    content.split(/^SUBSYS /).each do |item|
      return build_params(item) if item =~ /SUBNAME\(#{subname}\)/
    end

    build_params(NullParmlibContent.new)
  end

  def self.subname_regexp
    '[\w\@\#\$]{1,4}'
  end

  def self.initrtn_regexp
    'INITRTN\((.*?)\)'
  end

  def self.initparm_regexp
    'INITPARM\((.*?)\)'
  end

  private_class_method

  def self.build_params(item)
    {
      CONSNAME: item.scan_content(/CONSNAME\((.*?)\)/),
      INITRTN: item.scan_content(/#{initrtn_regexp}/),
      INITPARM: item.scan_content(/#{initparm_regexp}/),
      PRIMARY: item.scan_content(/PRIMARY\((.*?)\)/),
      START: item.scan_content(/START\((.*?)\)/)
    }
  end
end
