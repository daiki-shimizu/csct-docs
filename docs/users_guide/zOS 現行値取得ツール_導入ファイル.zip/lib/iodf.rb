# Provides information on IODF.
class IODF
  def self.dataset_name
    ios_config.scan(/ACTIVE IODF DATA SET = (#{dataset_regexp})/)
  end

  def self.address
    IPLPARM.content.scan(/IODF DEVICE (#{device_regexp})/) ||
      IPLPARM.content.scan(/IODF DEVICE.*CURRENT\((#{device_regexp})\)/)[-4, 4]
  end

  def self.volume
    device_status.scan(/#{address}.+ (#{volser_regexp}) /)
  end

  def self.size
    SYSTEM_DATASET.dataset_size_vsam(dataset_name)
  end

  def self.configid
    ios_config.scan(/CONFIGURATION ID = (#{config_id_regexp})/)
  end

  def self.edtid
    ios_config.scan(/EDT ID = (#{edt_id_regexp})/)
  end

  def self.ios_config
    syscmd_ulog('D IOS,CONFIG')
  end

  def self.device_status
    syscmd_ulog("D U,,,#{address},1")
  end

  def self.config_id_regexp
    '[\w\@\#\$]{1,8}'
  end

  def self.edt_id_regexp
    '\h\h'
  end
end
