# Provides information on IEASYSxx.
class IEASYSxx
  def self.content
    ParmlibContentFactory
      .collect_ieasysxx(ParmlibSuffix.ieasys.add_default_suffix)
  end

  def self.system_name
    syscmd_ulog('D SYMBOLS').scan(/&SYSNAME.\s+= "(#{sysname_regexp})"/)
  end

  def self.parmlib_suffix(parameter, member = parameter)
    content.get_suffix_list(parameter) | SYSLOG.parmlib_suffix_iee252i(member)
  end

  def self.parmlib_suffix_dataset_name(parameter, member = parameter)
    if (suffix_list = parmlib_suffix(parameter, member)) == undefined_message
      undefined_message
    else
      NamesFactory.create(
        suffix_list.scan(/\w\w/).inject([]) do |new_list, suffix|
          new_list << datasets_member_name(PARMLIB.datasets, member + suffix)
        end.compact
      ).join
    end
  end
end
