# ParmlibContentFactory
class ParmlibContentFactory
  def self.create(content)
    if content && !content.empty?
      ParmlibContent.new(content)
    else
      NullParmlibContent.new
    end
  end

  def self.create_loadxx(content)
    if content && !content.empty?
      LoadxxContent.new(content)
    else
      NullParmlibContent.new
    end
  end

  def self.collect(member_names)
    if member_names.respond_to?(:attach_prefix)
      member_names = member_names.attach_prefix
    end

    concat_content =
      member_names.collect do |member_name|
        datasets_member(PARMLIB.datasets, member_name)
      end

    create(concat_content.compact.join("\n"))
  end

  def self.collect_ieasysxx(member_names)
    if member_names.respond_to?(:attach_prefix)
      member_names = member_names.attach_prefix
    end

    IeasysxxContent.new(
      member_names.collect do |member_name|
        datasets_member(PARMLIB.datasets, member_name)
      end
    )
  end

  def self.collect_commndxx(member_names)
    if member_names.respond_to?(:attach_prefix)
      member_names = member_names.attach_prefix
    end

    concat_content =
      (member_names | %w(IEACMD00)).collect do |member_name|
        datasets_member(PARMLIB.datasets, member_name)
      end

    CommndxxContent.new(concat_content.compact.join("\n"))
  end
end
