# Provide information on PARMLIB members.
class ParmlibSuffix
  def self.antmin00
    Suffix.new('00').add_prefix('ANTMIN')
  end

  def self.antxin00
    Suffix.new('00').add_prefix('ANTXIN')
  end

  def self.ephwp00
    Suffix.new('00').add_prefix('EPHWP')
  end

  def self.ieaabd00
    Suffix.new('00').add_prefix('IEAABD')
  end

  def self.ieaapp00
    Suffix.new('00').add_prefix('IEAAPP')
  end

  def self.ieacmd00
    Suffix.new('00').add_prefix('IEACMD')
  end

  def self.ieadmp00
    Suffix.new('00').add_prefix('IEADMP')
  end

  def self.ieadmr00
    Suffix.new('00').add_prefix('IEADMR')
  end

  def self.ivtprm00
    Suffix.new('00').add_prefix('IVTPRM')
  end

  def self.nuclst
    LOADxx.content.scan_suffix(/^NUCLST   (#{two_digit_suffix_regexp})/)
          .add_prefix('NUCLST')
  end

  def self.tsokey00_ddname
    target_datasets(
      StartedProcedureFactory.create( \
        datasets_member(JES2.proc00_datasets, 'TSO')
      ), 'PARMLIB'
    ).first
  end

  def self.tsokey00
    if tsokey00_ddname && tsokey00_ddname.include?('(')
      Suffix.new(
        tsokey00_ddname.scan(/\(TSOKEY(#{two_digit_suffix_regexp})\)/)
        .flatten.first
      ).add_prefix('TSOKEY')
    else
      Suffix.new('00').add_prefix('TSOKEY')
    end
  end

  # consolxx
  def self.consol_suffix(keyword, default_option = nil)
    (setcmd(keyword) |
      CONSOLxx.content.scan_suffix(/#{keyword}\((#{suffix_regexp})\)/) |
      SuffixFactory.create(default_option)
    ).add_prefix(parameter_to_prefix_hash.fetch(keyword.to_sym, ''))
  end

  def self.cngrp
    consol_suffix('CNGRP', 'NO').add_negative_keywords('NO')
  end

  def self.mmslst
    consol_suffix('MMS', 'NO').add_negative_keywords('NO')
  end

  def self.mpflst
    consol_suffix('MPF', 'NO').add_negative_keywords('NO')
  end

  def self.msgfld
    setcmd('MSGFLD') |
      consol_suffix('MSGFLD', 'NONE').add_negative_keywords('ON')
  end

  def self.pfktab
    consol_suffix('PFK', 'NONE')
  end

  # commndxx
  def self.setcmd(member_name)
    COMMNDxx.content.scan_suffix(/SET #{member_name}=#{suffix_regexp}/)
            .add_prefix(parameter_to_prefix_hash.fetch(member_name.to_sym, ''))
  end

  def self.startcmd(member_name, keyword, default_option = nil)
    suffix = nil

    if COMMNDxx.content.scan(/(?:S|START) #{member_name}/)
      suffix =
        COMMNDxx.content.scan(
          /(?:S|START) #{member_name}.+#{keyword}=#{suffix_regexp}/
        ) || default_option
    end

    SuffixFactory.create(suffix).add_prefix(
      parameter_to_prefix_hash.fetch(member_name.to_sym, '')
    )
  end

  def self.modifycmd(member_name, keyword = member_name)
    suffix = nil

    if COMMNDxx.content.scan(/(?:F|MODIFY) #{member_name}/)
      suffix = COMMNDxx.content.scan(
        /(?:F|MODIFY) #{member_name}.+#{keyword}=#{suffix_regexp}/
      )
    end

    SuffixFactory.create(suffix).add_prefix(
      parameter_to_prefix_hash.fetch(member_name.to_sym, '')
    )
  end

  # Returns two alphanumeric characters indicating the ADYSETxx member of
  # the logical parmlib.
  def self.adyset
    setcmd('DAE')
  end

  # Returns two alphanumeric characters indicating the APPCPMxx member of
  # the logical parmlib.
  # '00' comes if a parmlib member is not specified with the START command.
  def self.appcpm
    setcmd('APPC') | startcmd('APPC', 'APPCPM', '00')
  end

  # Returns two alphanumeric characters indicating the ASCHPMxx member of
  # the logical parmlib.
  # '00' comes if a parmlib member is not specified with the START command.
  def self.aschpm
    setcmd('ASCH') | startcmd('ASCH', 'ASCHPM', '00')
  end

  # Returns two alphanumeric characters indicating the COFDLFxx member of
  # the logical parmlib.
  # '00' comes if a parmlib member is not specified with the START command.
  def self.cofdlf
    modifycmd('DLF', 'NN') | startcmd('DLF', 'NN', '00')
  end

  # Returns two alphanumeric characters indicating the COFVLFxx member of
  # the logical parmlib.
  # '00' comes if a parmlib member is not specified with the START command.
  def self.cofvlf
    startcmd('VLF', 'NN', '00')
  end

  # Returns two alphanumeric characters indicating the CSVLLAxx member of
  # the logical parmlib.
  # 'NONE' comes if a parmlib member is not specified with the START command.
  def self.csvlla
    modifycmd('LLA', 'UPDATE') | startcmd('LLA', 'LLA', 'NONE')
  end

  # Returns two alphanumeric characters indicating the HZSPRMxx member of
  # the logical parmlib.
  # 'PREV' comes if a parmlib member is not specified with the START command.
  def self.hzsprm
    suffix = (modifycmd('HZSPROC', 'REPLACE PARMLIB') |
      startcmd('HZSPROC', 'HZSPRM')
    )

    if suffix.is_a?(UndefinedSuffix) || suffix == 'PREV' || suffix == 'SYSPARM'
      suffix = IEASYSxx.content.get_suffix_list('HZS')
    end

    suffix.add_suffix(modifycmd('HZSPROC', 'ADD PARMLIB'))
  end

  # Returns two alphanumeric characters indicating the IEADMCxx member of
  # the logical parmlib.
  def self.ieadmc
    COMMNDxx.content.scan_suffix(/DUMP.+PARMLIB=#{suffix_regexp}/)
            .add_prefix('IEADMC')
  end

  def self.ipcsprnn
    COMMNDxx.content.scan_suffix(/IPCS PARM\(#{suffix_regexp}/)
            .add_prefix('IPCSPR')
  end

  # Returns two alphanumeric characters indicating the XCFPOLxx member of
  # the logical parmlib.
  def self.xcfpol
    if syscmd_ulog('D XCF,PRSMPOLICY').scan(/POLICY IS NOT ACTIVE/)
      SuffixFactory.create(nil)
    else
      syscmd_ulog('D XCF,PRSMPOLICY').scan_suffix(/POLICY IS XCFPOL#{suffix_regexp}/)
    end.add_prefix('XCFPOL')
  end

  def self.alloc
    IEASYSxx.content.get_suffix_list('ALLOC')
  end

  def self.autor
    setcmd('AUTOR') |
      IEASYSxx.content.get_suffix_list('AUTOR').set_default_suffix
  end

  def self.axr
    IEASYSxx.content.get_suffix_list('AXR').set_default_suffix
  end

  def self.bpxprm
    setcmd('OMVS') |
      modifycmd('OMVS', 'RESTART,OMVS') |
      IEASYSxx.content.get_suffix_list('OMVS')
  end

  def self.ceaprm
    modifycmd('CEA', 'CEA') |
      IEASYSxx.content.get_suffix_list('CEA').set_default_suffix
  end

  def self.ceeprm
    setcmd('CEE') |
      IEASYSxx.content.get_suffix_list('CEE')
  end

  def self.clock
    IEASYSxx.content.get_suffix_list('CLOCK').set_default_suffix
  end

  def self.config
    suffixes = []
    PARMLIB.datasets.each do |dataset|
      next if not_exist?(dataset)
      download_list(dataset) unless File.exist?(add_path(dataset))
      suffixes |= readout(dataset).scan(/^CONFIG(\w\w)/).flatten.sort
    end

    SuffixFactory.create(suffixes.join(',')).add_prefix('CONFIG')
  end

  def self.cnidtr
    setcmd('CNIDTR')
  end

  def self.commnd
    IEASYSxx.content.get_suffix_list('CMD').set_default_suffix
  end

  def self.consol
    setcmd('CON') | IEASYSxx.content.get_suffix_list('CON')
  end

  def self.couple
    IEASYSxx.content.get_suffix_list('COUPLE').set_default_suffix
  end

  def self.csvrtl
    setcmd('RTLS') | IEASYSxx.content.get_suffix_list('RTLS')
  end

  def self.cununi
    setcmd('UNI') | IEASYSxx.content.get_suffix_list('UNI')
  end

  def self.devsup
    setcmd('DEVSUP') |
      IEASYSxx.content.get_suffix_list('DEVSUP')
  end

  def self.dfhssi
    if IEFSSNxx.subnames.include?('CICS')
      IEFSSNxx.params('CICS')[:INITPARM]
              .scan_suffix(/DFHSSI(#{two_digit_suffix_regexp})/)
              .set_default_suffix
              .add_prefix('DFHSSI')
    else
      SuffixFactory.create(nil).add_prefix('DFHSSI')
    end
  end

  def self.diag
    setcmd('DIAG') |
      IEASYSxx.content.get_suffix_list('DIAG').set_default_suffix
  end

  def self.exspat
    setcmd('EXS')
  end

  def self.exit
    IEASYSxx.content.get_suffix_list('EXIT')
  end

  def self.grscnf
    IEASYSxx.content.get_suffix_list('GRSCNF').set_default_suffix
  end

  def self.grsrnl
    setcmd('GRSRNL') |
      IEASYSxx.content.get_suffix_list('GRSRNL')
  end

  def self.idavdt
    modifycmd('IDAVDT', 'READIN') | startcmd('IDAVDT', '', '00')
  end

  def self.ieaapf
    IEASYSxx.content.get_suffix_list('APF').set_default_suffix
  end

  def self.ieafix
    IEASYSxx.content.get_suffix_list('FIX')
  end

  def self.ieaics
    setcmd('ICS') |
      IEASYSxx.content.get_suffix_list('ICS')
  end

  def self.ieaips
    setcmd('IPS') |
      IEASYSxx.content.get_suffix_list('IPS').set_default_suffix
  end

  def self.iealpa
    IEASYSxx.content.get_suffix_list('MLPA')
  end

  def self.ieaopt
    setcmd('OPT') |
      IEASYSxx.content.get_suffix_list('OPT')
  end

  def self.ieapak
    IEASYSxx.content.get_suffix_list('PAK').set_default_suffix
  end

  def self.ieaslp
    COMMNDxx.content.scan_suffix(/SET SLIP=#{suffix_regexp}/)
            .add_prefix('IEASLP')
  end

  def self.ieasvc
    IEASYSxx.content.get_suffix_list('SVC')
  end

  def self.ieasys
    IPLPARM.content.get_suffix_list('IEASYS LIST').add_prefix('IEASYS')
  end

  def self.ieasym
    IPLPARM.content.get_suffix_list('IEASYM LIST').add_prefix('IEASYM')
  end

  def self.sms_id
    initparm = IEFSSNxx.params('SMS')[:INITPARM]
    id = initparm.scan(/ID=(#{two_digit_suffix_regexp})/)
    SuffixFactory.create(id).add_prefix('IGDSMS')
  end

  def self.igdsms
    setcmd('SMS') |
      sms_id |
      IEASYSxx.content.get_suffix_list('SMS').set_default_suffix
  end

  def self.ikjtso
    setcmd('IKJTSO') |
      IEASYSxx.content.get_suffix_list('IKJTSO').set_default_suffix
  end

  def self.ixgcnf
    setcmd('IXGCNF') | IEASYSxx.content.get_suffix_list('IXGCNF')
  end

  def self.load
    IPLPARM.content.scan_suffix(/USED LOAD(#{two_digit_suffix_regexp})/)
           .add_prefix('LOAD')
  end

  def self.iecios
    setcmd('IOS') |
      IEASYSxx.content.get_suffix_list('IOS')
  end

  def self.iefssn
    IEASYSxx.content.get_suffix_list('SSN').set_default_suffix
  end

  def self.iggcat
    IEASYSxx.content.get_suffix_list('CATALOG').set_default_suffix
  end

  def self.ioeprm
    SuffixFactory.create(BPXPRMxx.content.scan(/'PRM=#{suffix_regexp}'/))
                 .add_prefix('IOEPRM')
  end

  def self.lnklst
    IEASYSxx.content.get_suffix_list('LNK').set_default_suffix
  end

  def self.lpalst
    IEASYSxx.content.get_suffix_list('LPA')
  end

  def self.mstjcl
    IEASYSxx.content.get_suffix_list('MSTRJCL').set_default_suffix
  end

  def self.prog
    setcmd('PROG') |
      IEASYSxx.content.get_suffix_list('PROG')
  end

  def self.sched
    setcmd('SCH') |
      IEASYSxx.content.get_suffix_list('SCH')
  end

  def self.smfprm
    setcmd('SMF') |
      IEASYSxx.content.get_suffix_list('SMF').set_default_suffix
  end

  def self.vatlst
    IEASYSxx.content.get_suffix_list('VAL').set_default_suffix
  end
end
