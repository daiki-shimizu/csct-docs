# Provides information on COMMNDxx.
class COMMNDxx
  # Returns the content of current COMMNDxx members of the logical parmlib and
  # IEACMD00 member.
  def self.content
    ParmlibContentFactory.collect_commndxx(ParmlibSuffix.commnd)
  end

  # Returns an array containing the start procedure names described in the
  # current COMMNDxx.
  def self.procnames
    NamesFactory.create(content.to_s.scan(/(?:S|START) (\w+)/).flatten)
  end
end
