# ProfileContent
require_relative 'system_symbols'

class ProfileContent < DefinedObject
  include SystemSymbols

  def initialize(content)
    super(
      use_system_symbols(remove_comments(remove_sequence_numbers(content)))
    )
  end

  private

  def remove_comments(content)
    content.gsub(/^;.+$/, '').gsub(/ ;.+$/, '')
  end

  def remove_sequence_numbers(content)
    content.lines.inject('') do |lines, line|
      lines + line[0..71].strip + "\n"
    end
  end
end
