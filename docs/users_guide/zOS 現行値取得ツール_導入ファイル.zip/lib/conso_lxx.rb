# Provides the content and suffixes for CONSOLxx members.
class CONSOLxx
  def self.content
    ParmlibContentFactory.collect(ParmlibSuffix.consol)
  end

  def self.mmslstxx_content
    ParmlibContentFactory.collect(ParmlibSuffix.mmslst.attach_prefix)
  end

  def self.cnlcccxx_member_names
    NamesFactory.create(
      mmslstxx_content.to_s.scan(/CONFIG\((#{member_regexp})\)/).flatten
    )
  end

  def self.master_addr
    NamesFactory.create(
      scan_devnum_name_auth.collect do |item|
        item[0] if item[2] == 'MASTER'
      end
    )
  end

  def self.master_name
    NamesFactory.create(
      scan_devnum_name_auth.collect do |item|
        item[1] if item[2] == 'MASTER'
      end
    )
  end

  def self.sub_addr
    NamesFactory.create(
      scan_devnum_name_auth.collect do |item|
        item[0] unless item[2] == 'MASTER'
      end
    )
  end

  def self.sub_name
    NamesFactory.create(
      scan_devnum_name_auth.collect do |item|
        item[1] unless item[2] == 'MASTER'
      end
    )
  end

  def self.scan_devnum_name_auth
    devnum = nil
    name = nil
    auth = 'INFO'
    cons_array = content.to_s.scan(
      /(DEVNUM\(\w+\))|(NAME\(#{console_name_regexp}\))|(AUTH\([\w,]+\))/m
    ).flatten.compact.each_with_object([]) do |item, array|
      case item
      when /DEVNUM\(/
        array << [devnum, name, auth] if devnum
        devnum = item[/DEVNUM\((\h+)\)/, 1]
        name = nil
        auth = 'INFO'
      when /NAME\(/
        name = item[/NAME\((#{console_name_regexp})\)/, 1]
      when /AUTH\(/
        auth = item[/AUTH\(([\w,]+)\)/, 1]
      end
    end
    devnum ? cons_array << [devnum, name, auth] : cons_array
  end
end
