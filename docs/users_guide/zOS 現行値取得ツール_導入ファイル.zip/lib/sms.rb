# Provide information on SMS.
class SMS
  def self.root_filesystem_name
    OMVS.root_filesystem_name
  end

  def self.enabled(filename)
    if submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{filename}\') ALL") \
       .scan('SMSDATA')
      'YES'
    else
      'NO'
    end
  end

  def self.hlq(filename)
    filename[/(#{hlq_regexp})/]
  end

  def self.vol(filename)
    submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{filename}\') ALL") \
      .scan_volser_hyphen
  end

  def self.sc(filename)
    submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{filename}\') ALL") \
      .scan(/STORAGECLASS -----(\w+)/) || '(NON-SMS)'
  end

  def self.sg(filename)
    volume =
      submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{filename}\') ALL") \
      .scan_volser_hyphen
    syscmd_ulog("D SMS,VOLUME(#{volume})").scan(/#{volume}\s+\w{4}.+?(\w+)/) \
      || '(ERROR)'
  end

  def self.logr(stream)
    syscmd_ulog('D LOGGER,L').scan(stream) ? 'YES' : 'NO'
  end

  def self.structure(stream)
    if logr(stream) == 'NO'
      'NO'
    elsif syscmd_ulog('D LOGGER,L').scan(/#{stream}.*? \*DASDONLY\*/)
      'YES (DASDONLY)'
    else
      'YES (CF STRUCTURE)'
    end
  end

  def self.logr_hlq(stream)
    if logr(stream) == 'NO'
      undefined_message
    else
      submit_jcl('listlogr.jcl.erb', 'DATA TYPE(LOGR)') \
        .scan(/LOGSTREAM NAME\(#{SMS.logstream(stream)}\).*? HLQ\((\w*)\)/m)
    end
  end

  def self.logr_enabled(stream)
    logr(stream) == 'NO' ? undefined_message : enabled(stream_name(stream))
  end

  def self.logr_vol(stream)
    logr(stream) == 'NO' ? undefined_message : vol(stream_name(stream))
  end

  def self.logr_sc(stream)
    logr(stream) == 'NO' ? undefined_message : sc(stream_name(stream))
  end

  def self.logr_sg(stream)
    logr(stream) == 'NO' ? undefined_message : sg(stream_name(stream))
  end

  def self.stream_name(stream)
    if logr_hlq(stream) == ''
      logr_lvl_1st(logstream(stream))
    else
      logr_lvl_1st(logr_hlq(stream) + '.' + logstream(stream))
    end
  end

  def self.logr_lvl_1st(lvl)
    submit_jcl('listcat.jcl.erb', "LISTC LVL(\'#{lvl}\')") \
      .scan(/CLUSTER ------- ([\w\.]+)/)
  end

  def self.logstream(stream)
    syscmd_ulog('D LOGGER,L').scan(/^\s*([\w\.]*#{stream}[\w\.]*)/)
  end

  def self.smsscds_datasets
    syscmd_ulog('D SMS').scan(/SCDS\s=\s([\w\.]+)\n/)
  end

  def self.smsscds_volumes
    submit_jcl(
      'listcat.jcl.erb',
      "LISTC ENT(\'#{smsscds_datasets}\') ALL"
    ).scan_volser_hyphen
  end

  def self.smsscds_size
    SYSTEM_DATASET.dataset_size_vsam(smsscds_datasets)
  end

  def self.smsacds_datasets
    syscmd_ulog('D SMS').scan(/ACDS\s=\s([\w\.]+)\n/)
  end

  def self.smsacds_volumes
    submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{smsacds_datasets}\') ALL") \
      .scan_volser_hyphen
  end

  def self.smsacds_size
    SYSTEM_DATASET.dataset_size_vsam(smsacds_datasets)
  end

  def self.smscommds_datasets
    syscmd_ulog('D SMS').scan(/COMMDS\s=\s([\w\.]+)\n/)
  end

  def self.smscommds_volumes
    submit_jcl(
      'listcat.jcl.erb',
      "LISTC ENT(\'#{smscommds_datasets}\') ALL"
    ).scan_volser_hyphen
  end

  def self.smscommds_size
    SYSTEM_DATASET.dataset_size_vsam(smscommds_datasets)
  end
end
