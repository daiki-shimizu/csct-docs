# CommandPrefixFactory
class CommandPrefixFactory
  def self.create(prefix)
    prefix ? CommandPrefix.new(prefix) : UndefinedCommandPrefix.new
  end
end
