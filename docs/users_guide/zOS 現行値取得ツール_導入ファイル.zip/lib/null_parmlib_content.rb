# NullParmlibContent
class NullParmlibContent < UndefinedObject
  def to_s
    ''
  end

  def scan_content(*)
    DatasetFactory.create(nil)
  end
end
