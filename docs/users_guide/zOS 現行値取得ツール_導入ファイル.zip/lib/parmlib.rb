# Provide information on PARMLIB.
class PARMLIB
  def self.display_parmlib
    syscmd_ulog('D PARMLIB')
  end

  def self.datasets
    NamesFactory.create(display_parmlib \
      .scan_array(/\d\s+\w\s+#{volser_regexp}\s+(#{dataset_regexp})/))
  end

  def self.dataset_first
    datasets.first
  end

  def self.dataset_second
    datasets[1] || undefined_message
  end

  def self.dataset_others
    if datasets[2..-1] && !datasets[2..-1].empty?
      datasets[2..-1].join
    else
      undefined_message
    end
  end
end
