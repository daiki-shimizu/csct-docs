# Provide information on VTAM.
class VTAM
  def self.procname
    syscmd_ulog('D NET,ID=VTAM')
      .scan(/IST271I JOBNAME = (#{member_regexp})/) || 'VTAM'
  end

  def self.content
    StartedProcedureFactory.create(
      datasets_member(JES2.proc00_datasets, procname)
    )
  end

  def self.vtamopts_list
    syscmd_ulog('D NET,VTAMOPTS,OPTION=LIST') \
      .scan_suffix(/LIST\s+= (#{suffix_regexp})/)
  end

  def self.vtamopts_config
    syscmd_ulog('D NET,VTAMOPTS,OPTION=CONFIG') \
      .scan_suffix(/CONFIG\s+= (#{suffix_regexp})/)
  end

  def self.vtamlst_datasets
    target_datasets(content, 'VTAMLST')
  end

  def self.vtamlib_datasets
    target_datasets(content, 'VTAMLIB')
  end

  def self.atcconxx_content
    datasets_member(vtamlst_datasets, 'ATCCON' + vtamopts_config.to_s)
  end

  def self.majnodes
    atcconxx_content.scan(/^(\w+)[\s,]/).flatten.first
  end

  def self.first_majnode_content
    datasets_member(vtamlst, atcconxx_content.scan(/^(\w+)[\s,]/).flatten.first)
  end

  def self.dataset_name
    datasets_member_name(JES2.proc00_datasets, procname)
  end

  def self.atcstrxx_vtamlst_dataset
    datasets_member_name(vtamlst_datasets, 'ATCSTR' + vtamopts_list.to_s)
  end

  def self.atcconxx_vtamlst_dataset
    datasets_member_name(vtamlst_datasets, 'ATCCON' + vtamopts_config.to_s)
  end

  def self.vtamlst_dataset_concatenate
    vtamlst_datasets.join
  end

  def self.vtamlib_dataset_concatenate
    vtamlib_datasets.join
  end

  def self.vtamlib_volser_concatenate
    NamesFactory.create(
      vtamlib_datasets.collect do |dataset|
        submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{dataset}\') ALL") \
          .scan(/VOLSER(?:[-]*)(#{volser_regexp})/)
      end
    ).join
  end

  def self.vtamlib_volser
    submit_jcl(
      'listcat.jcl.erb',
      "LISTC ENT(\'#{vtamlib_datasets[0]}\') ALL"
    ).scan(/VOLSER(?:[-]*)(#{volser_regexp})/)
  end
end
