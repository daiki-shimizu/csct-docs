# NotActiveNames
class NotActiveNames < Array
  include ZOS_function

  def initialize
    super([])
  end

  def inspect
    join
  end

  def join(*)
    not_active_message
  end

  def parmlib_names
    UndefinedNames.new
  end

  def range_expression
    ''
  end

  def multiple_address_expression
    ''
  end
end