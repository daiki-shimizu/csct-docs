# ProfileContentFactory
class ProfileContentFactory
  def self.create(content)
    if content && !content.empty?
      ProfileContent.new(content)
    else
      NullProfileContent.new
    end
  end
end

