# Provide information on RMF.
class RMF
  def self.procname(member_name)
    if member_name == 'RMFGAT'
      msgid = 'ERB105I'.freeze
    else
      msgid = 'ERB100I'.freeze
    end

    current_member_name =
      submit_jcl('find_member_name.jcl.erb', msgid, eye_catcher: 'IEF695I')
        .scan(/IEF695I START\s+(#{member_regexp})/)
    if current_member_name
      current_member_name
    else
      if File.exist?(add_path(msgid))
        File.rename(add_path(msgid), add_path('!' + msgid))
      end
      member_name
    end
  end

  def self.dataset_name(member_name = 'RMF')
    datasets_member_name(JES2.proc00_datasets, procname(member_name))
  end

  def self.rmf1_suffix
    syscmd_ulog('F RMF,D ZZ').scan_suffix(/MEMBER\((\w\w)\)/) \
    .set_default_suffix.add_prefix('ERBRMF')
  end

  def self.rmf1_parm_dataset
    return NotActiveNames.new if syscmd_ulog('F RMF,D ZZ').scan(/NOT ACTIVE/)
    datasets_member_names(PARMLIB.datasets, RMF.rmf1_suffix.attach_prefix)
  end

  def self.rmf3_suffix
    syscmd_ulog('F RMF,D III').scan_suffix(/MEMBER\((\w\w)\)/) \
      .set_rmf3_default_suffix.add_prefix('ERBRMF')
  end

  def self.rmf3_parm_dataset
    return NotActiveNames.new if syscmd_ulog('F RMF,D III').scan(/NOT ACTIVE/)
    datasets_member_names(PARMLIB.datasets, RMF.rmf3_suffix.attach_prefix)
  end
end
