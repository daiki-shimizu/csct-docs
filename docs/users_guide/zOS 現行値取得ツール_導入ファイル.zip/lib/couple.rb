# Provide information on sysplex
class COUPLE
  def self.sysplexcds_datasets
    syscmd_ulog('D XCF,COUPLE,TYPE=SYSPLEX').scan_dataset_colon
  end

  def self.sysplexcds_volumes
    syscmd_ulog('D XCF,COUPLE,TYPE=SYSPLEX').scan_volser_colon
  end

  def self.sysplexcds_itemname
    max_system =
      syscmd_ulog('D XCF,COUPLE,TYPE=SYSPLEX').scan(/#{tod_regexp}\s+(\d+)/)
    max_group =
      syscmd_ulog('D XCF,COUPLE,TYPE=SYSPLEX') \
      .scan(/#{tod_regexp}\s+\d+\s+(\d+)/)
    max_group_peak =
      syscmd_ulog('D XCF,COUPLE,TYPE=SYSPLEX') \
      .scan(/#{tod_regexp}\s+\d+\s+\d+\s+\((\d+)\)/)
    max_member =
      syscmd_ulog('D XCF,COUPLE,TYPE=SYSPLEX') \
      .scan(/#{tod_regexp}\s+\d+\s+\d+\s+\(\d+\)\s+(\d+)/)
    max_member_peak =
      syscmd_ulog('D XCF,COUPLE,TYPE=SYSPLEX') \
      .scan(/#{tod_regexp}\s+\d+\s+\d+\s+\(\d+\)\s+\d+\s+\((\d+)\)/)
    grs_star =
      if syscmd_ulog('D XCF,COUPLE,TYPE=SYSPLEX') \
         .scan(/GRS STAR MODE IS SUPPORTED/) == undefined_message
        undefined_message
      else
        '1'
      end

    [max_system, max_group, max_group_peak, max_member, max_member_peak,
     grs_star]
  end

  def self.loggercds_datasets
    syscmd_ulog('D XCF,COUPLE,TYPE=LOGR').scan_dataset_colon
  end

  def self.loggercds_volumes
    syscmd_ulog('D XCF,COUPLE,TYPE=LOGR').scan_volser_colon
  end

  def self.loggercds_itemname
    max_system =
      syscmd_ulog('D XCF,COUPLE,TYPE=LOGR') \
      .scan(/#{tod_regexp}+\s+(\d+)$/)
    lsr = syscmd_ulog('D XCF,COUPLE,TYPE=LOGR').scan(/LSR\((\d+)\)/)
    lstrr = syscmd_ulog('D XCF,COUPLE,TYPE=LOGR').scan(/LSTRR\((\d+)\)/)
    dsextent = syscmd_ulog('D XCF,COUPLE,TYPE=LOGR').scan(/DSEXTENT\((\d+)\)/)
    [max_system, lsr, lstrr, dsextent]
  end

  def self.wlmcds_datasets
    syscmd_ulog('D XCF,COUPLE,TYPE=WLM').scan_dataset_colon
  end

  def self.wlmcds_volumes
    syscmd_ulog('D XCF,COUPLE,TYPE=WLM').scan_volser_colon
  end

  def self.wlmcds_itemname
    max_system =
      syscmd_ulog('D XCF,COUPLE,TYPE=WLM') \
      .scan(/#{tod_regexp}\s+(\d+)$/)
    [max_system].push([undefined_message] * 9).flatten
  end
end
