# Provide information on RACF.
class RACF
  def self.racfprim_datasets
    syscmd_ulog("#{RACFPREFIX.name}RVARY LIST") \
      .scan(/PRIM\s+\d+\s+#{volser_regexp}\s+(#{dataset_regexp})/)
  end

  def self.racfprim_volumes
    syscmd_ulog("#{RACFPREFIX.name}RVARY LIST") \
      .scan(/PRIM\s+\d+\s+(#{volser_regexp})/)
  end

  def self.racfprim_size
    SYSTEM_DATASET.dataset_size(racfprim_datasets, racfprim_volumes)
  end

  def self.racfback_datasets
    syscmd_ulog("#{RACFPREFIX.name}RVARY LIST") \
      .scan(/BACK\s+\d+\s+#{volser_regexp}\s+(#{dataset_regexp})/)
  end

  def self.racfback_volumes
    syscmd_ulog("#{RACFPREFIX.name}RVARY LIST") \
      .scan(/BACK\s+\d+\s+(#{volser_regexp})/)
  end

  def self.racfback_size
    SYSTEM_DATASET.dataset_size(racfback_datasets, racfback_volumes)
  end
end
