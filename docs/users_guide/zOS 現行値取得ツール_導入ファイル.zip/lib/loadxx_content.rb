# LoadxxContent
class LoadxxContent < ParmlibContent
  def remove_comments(content)
    content.split("\n").reject do |line|
      line[0] == '*' || line.empty?
    end.join("\n")
  end
end
