# EmptyJobLog
class EmptyJobLog < UndefinedObject
  def to_s
    not_found_message
  end

  def scan_volser_colon
    ([undefined_message] * 3).flatten[0..2]
  end

  def scan_dataset_colon
    ([undefined_message] * 3).flatten[0..2]
  end

  def scan_volser_hyphen
    undefined_message
  end
end
