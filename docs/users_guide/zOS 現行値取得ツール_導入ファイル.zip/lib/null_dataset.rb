# NullDataset
class NullDataset < UndefinedObject
end
