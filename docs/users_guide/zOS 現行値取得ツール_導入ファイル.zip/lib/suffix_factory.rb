require_relative 'suffix'
require_relative 'undefined_suffix'

# Factory method for Suffix and UndefinedSuffix classes.
class SuffixFactory
  def self.create(suffix)
    if suffix && suffix.scan(/#{suffix_regexp}/).flatten.first
      Suffix.new(suffix)
    else
      UndefinedSuffix.new
    end
  end
end
