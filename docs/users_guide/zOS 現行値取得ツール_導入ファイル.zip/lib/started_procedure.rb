require_relative 'system_symbols'

# StartedProcedure
class StartedProcedure < DefinedObject
  include ZOS_function
  include SystemSymbols

  def initialize(content, procname)
    super(
      use_jcl_symbols(use_system_symbols(remove_comments(content)), procname)
    )
  end

  def resolver_config
    to_s.scan(%r{ENVAR\("RESOLVER_CONFIG=//''(.+?)''"\)}).flatten.first
  end

  private

  def remove_comments(content)
    content.gsub(%r{^//\*.*\n}, '').gsub(/, .+$/,',')
  end

  def jcl_symbol_definitions(content, command)
    content.to_s
           .scan(%r{#{jcl_name_field_regexp}\s+#{command}\s+(.+?)^//\S}m)
           .flatten.collect do |statement|
      statement.gsub(%r{\n//\s+}, '').strip
    end
  end

  def exec_positional_and_keyword_parameter?(symbol_name)
    %w[PGM PROC ACCT ADDRSPC CCSID COND DYNAMNBR MEMLIMIT PARM PERFORM
       RD REGION REGION TIME] \
      .include?(symbol_name[/[^\.]+/])
  end

  def delete_apostrophes(string)
    string.gsub(/^'|'$/, '').gsub(/''/, "'")
  end

  def start_symbols(procname)
    return [] if procname.empty?

    keywords = COMMNDxx.content.scan(/(?:S|START) #{procname},(.+)/)
    return [] unless keywords

    keywords.scan(/(\w+)=(#{substitution_text_regexp})/).flatten
  end

  def use_jcl_symbols(content, procname)
    symbol_names_and_values = {}
    start_symbol_and_values =
      if start_symbols(procname).empty?
        {}
      else
        Hash[*start_symbols(procname)]
      end

    %w[PROC SET EXEC].each do |command|
      hash = {}
      # Step 1. Retrieve JCL symbol definitions, like
      #   PROC: "PARMS" => "'CTRACE(CTIEZB00),IDS=00'"
      #   EXEC: "PGM" => "EZBTCPIP", "REGION" => "0M", "TIME" => "1440"
      #   SET : "PARM1" => "TCPIP.TCPPARMS(TCPDATA)", "LOC" => "'O''''HARE'"
      jcl_symbol_definitions(content, command).each do |statement|
        pair = statement.scan(/(\w+)=(#{substitution_text_regexp})/).flatten
        hash.merge!(Hash[*pair])
      end

      # Step 2. Skip EXEC positional and keyword parameters, such as PGM,
      # REGION, TIME, and so on.
      #   EXEC: {}
      if command == 'EXEC' && !hash.empty?
        hash.delete_if do |symbol_name, _symbol_value|
          exec_positional_and_keyword_parameter?(symbol_name)
        end
      end

      # Step 3. Skip if no JCL symbol is defined.
      next if hash.empty?

      # Step 4. Delete enclosing apostrophes and replace two consecutive
      # apostrophes with a single apostroph
      #   PROC: "PARMS" => "CTRACE(CTIEZB00),IDS=00"
      #   SET : "PARM1" => "TCPIP.TCPPARMS(TCPDATA)", "LOC" => "O''HARE"
      hash.each do |symbol_name, symbol_value|
        hash[symbol_name] = delete_apostrophes(symbol_value)
      end

      # Step 5. Override the value if it is specified in START command.
      if !procname.empty? && COMMNDxx.procnames.include?(procname)
        hash.merge!(start_symbol_and_values)
      end

      # Step 6. Create JCL symbols from JCL symbol names by
      #   1. Appending an ampersand at the beginning of all the symbol names
      #   2. Creating four types of JCL symbols in the follwing order.
      #      - &&PARM1.
      #      - &&PARM1
      #      - &PARM1.
      #      - &PARM1
      symbol_names_and_values.merge!(
        hash.inject({}) do |h, array|
          h.merge(
            '&&' + array[0] + '.' => array[1],
            '&&' + array[0] => array[1],
            '&'  + array[0] + '.' => array[1],
            '&'  + array[0] => array[1]
          )
        end
      )
    end

    # Step 6. Replace JCL symbols with the value of JCL symbols.
    content.gsub(/&{1,2}\w+\.?/, symbol_names_and_values)
  end
end
