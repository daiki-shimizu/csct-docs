# Provides information on FTPD.
class FTPD
  def self.procnames
    syscmd_ulog('D OMVS,A=ALL')
      .scan_array(/^.{8} (#{member_regexp})\d.+?\n.+?CMD=FTPD/)
  end

  def self.dataset_names
    NamesFactory.create(
      procnames.collect do |procname|
        datasets_member_name(JES2.proc00_datasets, procname)
      end.flatten
    )
  end

  def self.tcpdata_names
    TCPIP.tcpdata_names
  end

  def self.portnos
    NamesFactory.create(
      procnames.collect do |procname|
        ftpd_portno = TCPIP.procnames.collect do |tcpip_procname|
          syscmd_ulog("D TCPIP,#{tcpip_procname},N,CONN,SERVER")
            .scan(/#{procname}\d?\s+\h+ (?:\d+\.){4}\.(\d+)/)
        end.uniq.first
        (ftpd_portno.to_i - 1).to_s + ',' + ftpd_portno if ftpd_portno
      end
    )
  end

  def self.ftpsdata_names
    NamesFactory.create(
      procnames.collect do |procname|
        target_datasets(
          datasets_member(JES2.proc00_datasets, procname), 'SYSFTPD'
        )
      end.flatten
    )
  end
end
