# System Symbols
module SystemSymbols
  def use_system_symbols(content)
    content.gsub(/&\w+\.?(?:\(\d+:\d+\))?/) do |matched|
      use_substring_symbols(
        Hash[syscmd_ulog('D SYMBOLS').to_s.scan(/(&\w+\.)\s+= "(.+?)"/)] \
        .each_with_object({}) do |(key, value), new_hash|
          new_hash[key] = value
        end[matched[/&\w+/] + '.'] || matched, matched
      )
    end
  end

  def use_substring_symbols(str, matched)
    if str == matched
      str
    elsif matched[/\(.+?\)/]
      if matched[/\(\d+:\d+\)/]
        str[
          matched[/\((\d+):\d+\)/, 1].to_i - 1,
          matched[/\(\d+:(\d+)\)/, 1].to_i
        ]
      else
        str[matched[/\((\d+)\)/, 1].to_i - 1, 1]
      end
    else
      str
    end
  end
end