# Provide the image for CUNUNIxx members.
class CUNUNIxx
  def self.image
    if ParmlibContentFactory.collect(ParmlibSuffix.cununi).scan(/IMAGE=(\w)/)
      'NO'
    else
      'YES'
    end
  end
end
