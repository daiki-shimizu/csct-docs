# Provides information on HASPACE.
class HASPACE
  def self.datasets
    syscmd_ulog('$DSPOOLDEF').scan(/DSNAME=(#{dataset_regexp})/)
  end

  def self.volumes
    submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{datasets}\') ALL") \
      .scan_volser_hyphen
  end

  def self.size
    if special_value?(datasets) || special_value?(volumes)
      undefined_message
    else
      SYSTEM_DATASET.dataset_size(datasets, volumes)
    end
  end
end
