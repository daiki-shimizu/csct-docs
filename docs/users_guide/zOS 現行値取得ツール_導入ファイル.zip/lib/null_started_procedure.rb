# Provides NullStartedProcedure.
class NullStartedProcedure < UndefinedObject
  def resolver_config
    nil
  end
end
