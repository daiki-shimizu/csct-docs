# Provide information on UCAT.
class UCAT
  def self.list
    submit_jcl('listcat.jcl.erb', 'LISTC UCAT NAME') \
      .scan_array(/USERCATALOG \-+ (#{dataset_regexp})/)
  end

  def self.svolumes(num)
    submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{list[num]}\') ALL") \
      .scan_volser_hyphen
  end

  def self.size(num)
    SYSTEM_DATASET.dataset_size_vsam(list[num])
  end

  def self.alias(num)
    alias_list =
      NamesFactory.create(
        submit_jcl('listcat.jcl.erb', "LISTC ENT(\'#{list[num]}\') ALL") \
        .scan_array(/ALIAS\-+(#{dataset_regexp})/)
      )
    alias_list.empty? ? undefined_message : alias_list.join
  end
end
