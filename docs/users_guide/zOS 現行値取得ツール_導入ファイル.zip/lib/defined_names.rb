# DefinedNames has methods to format the output string.
class DefinedNames < Array
  def initialize(content)
    super(content)
  end

  def inspect
    join
  end

  def join(separator = "\n")
    super(separator)
  end

  def parmlib_names
    NamesFactory.create(
      datasets_member_names(PARMLIB.datasets, self)
    )
  end

  # Convert ["00","02"] to "00-02"
  def range_expression
    first == last ? first : first + '-' + last
  end

  # Convert ["00","01","02"] to "00-02"
  def multiple_address_expression
    start_addr = end_addr = nil
    (each_with_object([]) do |address, new_array| \
      if start_addr
        unless address.hex == end_addr.hex + 1
          new_array << [start_addr, end_addr].range_expression
          start_addr = address
        end
      else
        start_addr = address
      end
      end_addr = address
    end << DefinedNames.new([start_addr, end_addr]).range_expression).join(',')
  end

  # Convert ("00", "02") to "00,3"
  def range_expression_with_count(start_addr, end_addr)
    start_addr + ',' + (end_addr.hex - start_addr.hex + 1).to_s
  end

  # Convert ["00", "01", "02", "10", "11", "12" ] to ["00,3", "10,3"]
  def multiple_address_with_count
    start_addr = end_addr = nil
    NamesFactory.create(each_with_object([]) do |address, new_array| \
      if start_addr
        unless address.hex == end_addr.hex + 1
          new_array << range_expression_with_count(start_addr, end_addr)
          start_addr = address
        end
      else
        start_addr = address
      end
      end_addr = address
    end << range_expression_with_count(start_addr, end_addr))
  end
end
