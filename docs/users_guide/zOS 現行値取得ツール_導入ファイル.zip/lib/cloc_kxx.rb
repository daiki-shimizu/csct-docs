# Provides the content, timezone and stpmode for CLOCKxx members.
class CLOCKxx
  def self.content
    ParmlibContentFactory.collect(ParmlibSuffix.clock)
  end

  def self.timezone
    content.scan(/TIMEZONE *(\w+.\w+.\w+.\w+)/)
  end

  def self.stpmode
    content.scan(/STPMODE *(\w+)/) || undefined_message
  end
end
