# Dataset
class Dataset < DefinedObject
end
