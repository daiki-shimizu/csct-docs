#! ruby -Ku
require 'rubyXL'
require_relative 'lib/zos_ftp'
require_relative 'lib/zos_function'
Dir[File.expand_path('..', __FILE__) << '/lib/*.rb'].each do |library|
  require library
end
include ZOS_FTP, ZOS_function

ZOS_function.directory_path = ARGV.empty? ? 'SAMPLE' : ARGV[0]
template_filename = 'zOS_pf(full).xlsx'
output_filename = 'new_form.xlsx'
ZOS_FTP.log_initialize

begin
  puts "#{template_filename}ファイルを開いています。"
  workbook = RubyXL::Parser.parse(ZOS_FTP.absolute_path(template_filename))
  puts '1.導入 ワークシートに記入しています。'
  worksheet = workbook['1.導入']
  column = 33
  column_max_length = 25
  row = 10

  write_cell = proc do |value|
    worksheet[row][column].change_contents(value)
    print '.'

    if value == non_supported_message
      worksheet[row][column + 1].change_contents(required_message)
    else
      worksheet[row][column + 1].change_contents(value)
    end

    if value.split.collect(&:size).max > column_max_length
      puts column_max_length = value.split.collect(&:size).max
      worksheet.change_column_width(column, column_max_length * 30 / 28)
      worksheet.change_column_width(column + 1, column_max_length * 34 / 28)
    end

    if value.include?("\n")
      worksheet.change_row_height(row, value.count("\n") * 14 + 15)
    end
  end

  writer = proc do |*values|
    values.each do |value|
      write_cell.call(value)
      row += 1
    end
  end

  writer2 = proc do |*values|
    values.each do |value|
      write_cell.call(value)
      row += 2
    end
  end

  # 1-1-1 DASD configuration
  writer.call(*[non_supported_message] * 52)

  # 1-1-2 Console confguration
  row = 67
  writer.call(
    CONSOLxx.master_addr.join,
    CONSOLxx.master_name.join,
    CONSOLxx.sub_addr.join,
    CONSOLxx.sub_name.join,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 1-1-3 Basic system configuration
  row = 80
  writer.call(
    IEASYSxx.system_name,
    SMFPRMxx.sid,
    LOADxx.sysplex_name,
    CLOCKxx.timezone,
    CLOCKxx.stpmode
  )

  # 1-1-4 Catalog configuration
  row = 90
  writer.call(
    LOADxx.syscat_dsn,
    LOADxx.syscat_volume,
    LOADxx.mcat_size,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 1-1-5 System dataset configuration
  # 1 UADS
  row = 110
  writer.call(
    UADS.datasets,
    UADS.volumes,
    UADS.size
  )

  # 2 BRODCAST
  writer.call(
    BRODCAST.datasets,
    BRODCAST.volumes,
    BRODCAST.size
  )

  # 3-5 SYS1.DUMPxx
  writer.call(
    DUMP.datasets[0],
    DUMP.volumes[0],
    DUMP.size[0] || undefined_message,
    DUMP.datasets[1] || undefined_message,
    DUMP.volumes[1] || undefined_message,
    DUMP.size[1] || undefined_message,
    DUMP.datasets[2] || undefined_message,
    DUMP.volumes[2] || undefined_message,
    DUMP.size[2] || undefined_message
  )

  # 6-8 SYS1.MANx
  writer.call(
    SMF.smf_datasets[0],
    SMF.volumes[0],
    SMF.size[0],
    SMF.smf_datasets[1],
    SMF.volumes[1],
    SMF.size[1],
    SMF.smf_datasets[2],
    SMF.volumes[2],
    SMF.size[2]
  )

  # 9 LOGREC
  writer.call(
    LOGREC.datasets,
    LOGREC.volumes,
    LOGREC.size
  )

  # 10 STGINDEX
  writer.call(
    non_supported_message,
    STGINDEX.datasets,
    STGINDEX.volumes,
    STGINDEX.size
  )

  # 11 HASPACE
  writer.call(
    HASPACE.datasets,
    HASPACE.volumes,
    HASPACE.size
  )

  # 12 HASPCKPT
  writer.call(
    HASPCKPT.datasets,
    HASPCKPT.volumes,
    HASPCKPT.size
  )

  # 13 HASPCKP2
  writer.call(
    HASPCKP2.datasets,
    HASPCKP2.volumes,
    HASPCKP2.size
  )

  # 14 PAGEPLPA
  writer.call(
    PAGEPLPA.datasets,
    PAGEPLPA.volumes,
    PAGEPLPA.size
  )

  # 15 PAGECOMMON
  writer.call(
    PAGECOMMON.datasets,
    PAGECOMMON.volumes,
    PAGECOMMON.size
  )

  # 16 PAGELOCAL 1
  writer.call(
    PAGELOCAL.datasets.join,
    PAGELOCAL.volumes.join,
    PAGELOCAL.size.join
  )

  # 17 IODF
  writer.call(
    IODF.dataset_name,
    IODF.volume,
    IODF.size
  )

  # 18 SYSPLEX COUPLE
  writer.call(
    COUPLE.sysplexcds_datasets[0],
    COUPLE.sysplexcds_volumes[0],
    COUPLE.sysplexcds_datasets[1],
    COUPLE.sysplexcds_volumes[1],
    COUPLE.sysplexcds_datasets[2],
    COUPLE.sysplexcds_volumes[2],
    COUPLE.sysplexcds_itemname[0],
    COUPLE.sysplexcds_itemname[1],
    COUPLE.sysplexcds_itemname[3],
    COUPLE.sysplexcds_itemname[5]
  )

  # 19 LOGGER COUPLE
  writer.call(
    COUPLE.loggercds_datasets[0],
    COUPLE.loggercds_volumes[0],
    COUPLE.loggercds_datasets[1],
    COUPLE.loggercds_volumes[1],
    COUPLE.loggercds_datasets[2],
    COUPLE.loggercds_volumes[2],
    COUPLE.loggercds_itemname[0],
    COUPLE.loggercds_itemname[1],
    COUPLE.loggercds_itemname[2],
    COUPLE.loggercds_itemname[3]
  )

  # 20 WLM COUPLE
  writer.call(
    COUPLE.wlmcds_datasets[0],
    COUPLE.wlmcds_volumes[0],
    COUPLE.wlmcds_datasets[1],
    COUPLE.wlmcds_volumes[1],
    COUPLE.wlmcds_datasets[2],
    COUPLE.wlmcds_volumes[2],
    COUPLE.wlmcds_itemname[0],
    COUPLE.wlmcds_itemname[1],
    COUPLE.wlmcds_itemname[2],
    COUPLE.wlmcds_itemname[3],
    COUPLE.wlmcds_itemname[4],
    COUPLE.wlmcds_itemname[5],
    COUPLE.wlmcds_itemname[6],
    COUPLE.wlmcds_itemname[7],
    COUPLE.wlmcds_itemname[8],
    COUPLE.wlmcds_itemname[9]
  )

  # 21-23 SMS SCDS/ACDS/COMMDS
  writer.call(
    SMS.smsscds_datasets,
    SMS.smsscds_volumes,
    SMS.smsscds_size,
    SMS.smsacds_datasets,
    SMS.smsacds_volumes,
    SMS.smsacds_size,
    SMS.smscommds_datasets,
    SMS.smscommds_volumes,
    SMS.smscommds_size
  )

  # 24 SMS ACS ROUTINE
  writer.call(
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 25-26 RACF PRIMARY/BACKUP
  writer.call(
    RACF.racfprim_datasets,
    RACF.racfprim_volumes,
    RACF.racfprim_size,
    RACF.racfback_datasets,
    RACF.racfback_volumes,
    RACF.racfback_size
  )

  # 27 File System
  writer.call(
    OMVS.root_filesystem_type,
    OMVS.root_filesystem_name,
    OMVS.root_filesystem_volumes,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 28 SMP/E GLOBAL
  writer.call(
    non_supported_message,
    non_supported_message
  )

  # 29 SMP/E TARGET
  writer.call(
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 30 SMP/E DLIB
  writer.call(
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 1-2 IODF installation parameter
  row = 238
  writer.call(
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    IODF.configid,
    IODF.edtid
  )

  # 1-3 SMS installation parameter
  row = 252
  # 1-3-1 File System
  writer.call(
    SMS.enabled(SMS.root_filesystem_name),
    SMS.hlq(SMS.root_filesystem_name),
    SMS.vol(SMS.root_filesystem_name),
    SMS.sc(SMS.root_filesystem_name),
    SMS.sg(SMS.root_filesystem_name)
  )

  # 1-3-2 OPERLOG
  writer.call(
    SMS.structure('OPERLOG'),
    SMS.logr_enabled('OPERLOG'),
    SMS.logr_hlq('OPERLOG'),
    SMS.logr_vol('OPERLOG'),
    SMS.logr_sc('OPERLOG'),
    SMS.logr_sg('OPERLOG')
  )

  # 1-3-3 LOGREC
  writer.call(
    SMS.structure('LOGREC'),
    SMS.logr_enabled('LOGREC'),
    SMS.logr_hlq('LOGREC'),
    SMS.logr_vol('LOGREC'),
    SMS.logr_sc('LOGREC'),
    SMS.logr_sg('LOGREC')
  )

  # 1-4 RACF installation parameters
  row = 275
  writer.call(
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 1-5 UNIX installation parameters
  row = 284
  writer.call(
    OMVS.superuser,
    non_supported_message
  )

  # 1-6 JES2 installation parameters
  row = 292
  writer.call(
    non_supported_message,
    non_supported_message,
    non_supported_message,
    JES2.mode,
    JES2.exit5
  )

  # 1-7 SMP/E installation parameters
  row = 302
  writer.call(
    SMPE.smptlib_prefix,
    SMPE.smptlib_vol
  )

  # 1-8 Stand Alone installation parameters
  # 1-8-1 Stand Alone DUMP
  row = 313
  writer.call(
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 1-8-2 Stand Alone UTILITY
  row = 325
  writer.call(
    non_supported_message,
    non_supported_message
  )

  # 1-9 PARMLIB installation parameters
  # 1-9-1 SYSn.IPLPARM
  row = 333
  writer.call(
    non_supported_message,
    IPLPARM.dataset_name
  )

  # 1-9-2 PARMLIB concatenated datasets
  writer.call(
    PARMLIB.dataset_first,
    PARMLIB.dataset_second,
    PARMLIB.dataset_others
  )

  # 1-9-3 PARMLIB
  writer.call(
    ParmlibSuffix.load,
    ParmlibSuffix.ieasys
  )

  puts
  puts '2.カスタマイズ ワークシートに記入しています。'
  worksheet = workbook['2.カスタマイズ']
  column_max_length = 25

  # 2-1-1 Current basic system configuration and migration target
  row = 10
  writer.call(
    IPLPARM.release,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 2-2 PARMLIB customized parameters
  # 2-2-1 Current PARMLIB member configuration and new parameters
  row = 25
  writer2.call(
    ParmlibSuffix.adyset.parmlib_names.join,
    ParmlibSuffix.alloc.parmlib_names.join,
    ParmlibSuffix.antmin00.parmlib_names.join,
    ParmlibSuffix.antxin00.parmlib_names.join,
    ParmlibSuffix.appcpm.parmlib_names.join,
    ParmlibSuffix.aschpm.parmlib_names.join,
    ParmlibSuffix.autor.parmlib_names.join,
    ParmlibSuffix.axr.parmlib_names.join
  )

  # No.9 Not applicable for migration
  row = 43
  writer2.call(
    datasets_member_names(PARMLIB.datasets, 'BLSCUSER').join,
    ParmlibSuffix.bpxprm.parmlib_names.join,
    ParmlibSuffix.ceaprm.parmlib_names.join,
    ParmlibSuffix.ceeprm.parmlib_names.join,
    ParmlibSuffix.clock.parmlib_names.join,
    ParmlibSuffix.cngrp.parmlib_names.join,
    ParmlibSuffix.cnidtr.parmlib_names.join,
    CONSOLxx.cnlcccxx_member_names.parmlib_names.join,
    ParmlibSuffix.cofdlf.parmlib_names.join,
    ParmlibSuffix.cofvlf.parmlib_names.join,
    ParmlibSuffix.commnd.parmlib_names.join,
    ParmlibSuffix.config.parmlib_names.join,
    ParmlibSuffix.consol.parmlib_names.join,
    ParmlibSuffix.couple.parmlib_names.join,
    ParmlibSuffix.csvlla.parmlib_names.join,
    ParmlibSuffix.csvrtl.parmlib_names.join
  )

  # No.26 Not applicable for migration
  row = 77
  writer2.call(
    ParmlibSuffix.cununi.parmlib_names.join,
    CUNUNIxx.image,
    ParmlibSuffix.devsup.parmlib_names.join,
    ParmlibSuffix.dfhssi.parmlib_names.join,
    ParmlibSuffix.diag.parmlib_names.join,
    ParmlibSuffix.ephwp00.parmlib_names.join,
    ParmlibSuffix.exit.parmlib_names.join,
    ParmlibSuffix.exspat.parmlib_names.join,
    ParmlibSuffix.grscnf.parmlib_names.join,
    ParmlibSuffix.grsrnl.parmlib_names.join
  )

  # No.37 Not applicable for migration
  row = 99
  writer2.call(
    ParmlibSuffix.hzsprm.parmlib_names.join,
    ParmlibSuffix.idavdt.parmlib_names.join,
    ParmlibSuffix.ieaabd00.parmlib_names.join,
    ParmlibSuffix.ieaapf.parmlib_names.join,
    ParmlibSuffix.ieaapp00.parmlib_names.join,
    ParmlibSuffix.ieacmd00.parmlib_names.join,
    ParmlibSuffix.ieadmc.sys1_parmlib_names.join,
    ParmlibSuffix.ieadmp00.parmlib_names.join,
    ParmlibSuffix.ieadmr00.parmlib_names.join,
    ParmlibSuffix.ieafix.parmlib_names.join,
    ParmlibSuffix.ieaics.parmlib_names.join,
    ParmlibSuffix.ieaips.parmlib_names.join,
    ParmlibSuffix.iealpa.parmlib_names.join,
    ParmlibSuffix.ieaopt.parmlib_names.join,
    ParmlibSuffix.ieapak.parmlib_names.join,
    ParmlibSuffix.ieaslp.parmlib_names.join,
    ParmlibSuffix.ieasvc.parmlib_names.join,
    ParmlibSuffix.ieasym.parmlib_names.join,
    ParmlibSuffix.ieasys.parmlib_names.join,
    ParmlibSuffix.iecios.parmlib_names.join,
    ParmlibSuffix.iefssn.parmlib_names.join
  )

  # No.59 Not applicable for migration
  row = 143
  writer2.call(
    datasets_member_names(PARMLIB.datasets, 'IFGPSEDI').join,
    datasets_member_names(PARMLIB.datasets, 'IGDDFPKG').join,
    ParmlibSuffix.igdsms.parmlib_names.join,
    ParmlibSuffix.iggcat.parmlib_names.join
  )

  # No.64 Not applicable for migration
  row = 153
  writer2.call(
    ParmlibSuffix.ikjtso.parmlib_names.join,
    ParmlibSuffix.ioeprm.parmlib_names.join,
    ParmlibSuffix.ipcsprnn.parmlib_names.join,
    ParmlibSuffix.ivtprm00.parmlib_names.join,
    ParmlibSuffix.ixgcnf.parmlib_names.join,
    ParmlibSuffix.lnklst.parmlib_names.join,
    ParmlibSuffix.load.iplparm_names.join,
    ParmlibSuffix.lpalst.parmlib_names.join,
    ParmlibSuffix.mmslst.parmlib_names.join,
    ParmlibSuffix.mpflst.parmlib_names.join,
    ParmlibSuffix.msgfld.parmlib_names.join,
    ParmlibSuffix.mstjcl.parmlib_names.join,
    ParmlibSuffix.nuclst.iplparm_names.join,
    ParmlibSuffix.pfktab.parmlib_names.join,
    ParmlibSuffix.prog.parmlib_names.join,
    ParmlibSuffix.sched.parmlib_names.join,
    ParmlibSuffix.smfprm.parmlib_names.join,
    ParmlibSuffix.tsokey00.parmlib_names.join,
    ParmlibSuffix.vatlst.parmlib_names.join,
    ParmlibSuffix.xcfpol.parmlib_names.join
  )

  # 2-3 JES2 customized parameters
  # 1 JES2
  row = 201
  writer.call(
    JES2.dataset_name.join,
    JES2.haspparm_datasets.join,
    JES2.ownnode,
    JES2.ownname
  )

  # 2-4.VTAM customized parameters
  # 1 VTAM & 2 VTAMLST
  row = 214
  writer.call(
    VTAM.dataset_name.join,
    non_supported_message,
    VTAM.vtamlst_dataset_concatenate,
    VTAM.atcstrxx_vtamlst_dataset.join,
    VTAM.atcconxx_vtamlst_dataset.join
  )

  # 3 VTAMLIB USS tables
  writer.call(
    non_supported_message,
    VTAM.vtamlib_dataset_concatenate,
    VTAM.vtamlib_volser_concatenate,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 4 VTAMLIB Logon mode tables
  writer.call(
    non_supported_message,
    VTAM.vtamlib_dataset_concatenate,
    VTAM.vtamlib_volser_concatenate,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 5 VTAMLIB COS table
  writer.call(
    non_supported_message,
    VTAM.vtamlib_dataset_concatenate,
    VTAM.vtamlib_volser_concatenate,
    non_supported_message
  )

  # 2-5 RACF customized parameters
  # 1 RACF DATABASE, 2 ICHRIN03 (STC TABLE) and 3 RACF SPECIAL USER
  row = 252
  writer.call(
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 2-6 TSO customized parameters
  # 1 UADS
  row = 267
  writer.call(
    non_supported_message
  )

  # 2-7 SMS customized parameters
  row = 277
  writer.call(
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 2-8 UNIX customized parameters
  row = 291
  writer.call(
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    OMVS.superuser,
    non_supported_message,
    non_supported_message
  )

  # 2-9 TCP/IP customized parameters
  row = 312

  # 1
  writer.call(
    non_supported_message,
    TCPIP.dataset_names.join,
    TCPIP.profile_names.join,
    TCPIP.tcpdata_names.join
  )

  # 2
  writer.call(
    non_supported_message,
    TN3270.portno.join,
    TN3270.dataset_names.join,
    TN3270.profile_names.join,
    TN3270.tcpdata_name,
    non_supported_message
  )

  # 3
  writer.call(
    non_supported_message,
    FTPD.portnos.join,
    FTPD.dataset_names.join,
    FTPD.ftpsdata_names.join,
    FTPD.tcpdata_names.join,
    non_supported_message,
    non_supported_message
  )

  # 4-7
  writer.call(
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 2-10 SDSF customized parameters
  row = 351
  writer.call(
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    SDSF.dataset_name.join,
    SDSF.isfprmxx_dataset_name.join
  )

  # 2-11 RMF customized parameters
  row = 366

  # 1 for RMF MONITOR I
  writer.call(
    non_supported_message,
    RMF.dataset_name.join,
    RMF.rmf1_parm_dataset.join
  )

  # 2 for RMF MONITOR II
  writer.call(
    non_supported_message,
    non_supported_message
  )

  # 3 for RMF MONITOR III
  writer.call(
    non_supported_message,
    RMF.dataset_name('RMFGAT').join,
    RMF.rmf3_parm_dataset.join
  )

  # 2-12 DFSORT customized parameters
  row = 383

  # 1 Using USERMOD
  writer.call(
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

  # 2 Using PARMLIB ICEPRMxx
  writer.call(
    non_supported_message,
    DFSORT.dataset_name.join,
    DFSORT.iceprm_dataset.join
  )

  # 2-13 Language environment customized parameters
  row = 402

  writer.call(
    # 1 ASSEMBLER ASSEMBLE OPT SOURCE
    non_supported_message,
    non_supported_message,

    # 2 COBOL for MVS COMPILE OPT SOURCE
    non_supported_message,
    non_supported_message,

    # 3 ENT COBOL COMPILE OPT SOURCE
    non_supported_message,
    non_supported_message,

    # 4 PL/I for MVS COMPILE OPT SOURCE
    non_supported_message,
    non_supported_message,

    # 5 ENT PL/I COMPILE OPT SOURCE
    non_supported_message,
    non_supported_message,

    # 6 LE OS RUNTIME OPT SOURCE
    non_supported_message,
    non_supported_message,
    non_supported_message,

    # 6 LE CICS RUNTIME OPT SOURCE
    non_supported_message,

    # 7 CEEPRMxx
    non_supported_message,
    LE.ceeprm_dataset
  )

  # 2-14 WLM customized parameters
  row = 427
  writer.call(
    # 1 WLM POLICY SAVE
    non_supported_message,
    non_supported_message,
    non_supported_message
  )

rescue => exception
  puts
  ZOS_FTP.log_error exception.message
  ZOS_FTP.log_error exception.backtrace

ensure
  puts
  begin
    if workbook
      puts "#{output_filename}ファイルに保存しています。"
      workbook.write(add_path(output_filename))
      puts "#{output_filename}ファイルに保存しました。"
    end
  rescue
    if output_filename == 'new_form.xlsx'
      new_output_filename = 'new_form_1.xlsx'
    else
      new_output_filename = 'new_form_' + (output_filename[/_(\d+)\./, 1].to_i + 1).to_s + '.xlsx'
    end
    puts "#{output_filename}はほかのプロセスが使用しています。別のファイル名で保存します。"
    output_filename = new_output_filename
    retry
  end
end
