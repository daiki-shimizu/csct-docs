2017-07-19  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add submit.rexx, syscmd.rexx.erb and find_memer_name.jcl.erb to create_release_build.rb

2017-07-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add paranoid: false option of Net:SSH.start to accept SSH forwarding

2017-07-17  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add multiple_address_with_count method to defined_names.rb

2017-07-17  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: execute_and_download in zos_ftp.rb to remove the unnecessary blanks after a .CMDOUT eyecatcher when SSH connection type is specified

2017-07-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: syscmd_test.rb to allow users to comfirm the syscmd method is working as expected

2017-07-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ZOS_FTP.ftp_port to allow users to customize a TCP port number to use to contact a z/OS FTP server

2017-07-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: .gitignore to include SAMPLE directory

2017-07-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: refresh the content of SAMPLE directory

2017-06-27  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: sgtarted_procedure.rb to skip EXEC positional and keyword parameters if jcl_symbol_and_values is nil

2017-05-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: HASPCKP2.datasets and HASPCKP2.volumes so that they return undefined_message when the CKPT2 dataset does not exist

2017-05-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: the next condition so that no method error should occur when jcl_symbol_and_values is nil

2017-05-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: RMF.procname so that it returns the default member name, RMF or RMFGAT instead of nil, when the RMF or RMFGAT task is not running

2017-05-05  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: submit.rexx to support JCL Submit via SSH

2017-05-04  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: ssh_download_common in zos_ftp.rb

2017-05-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: ZOS_FTP.connection_type

2017-05-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: syscmd.rexx.erb to support SSH connection, which requires net-ssh and net-scp ruby gems

2017-05-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ftpd.rb so that it can retrieve the member names of FTPD from the output of D OMVS,A=ALL

2017-05-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: use procname instead of proc_name

2017-05-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: sdsf_who.jcl.erb to check ISFPARMS settings

2017-05-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: rmf.rb to use find_member_name.jcl.erb. Add DFSORT.dataset_name instead of RMF.dataset_name('IOEOPT')

2017-05-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: find_member_name.jcl.erb in order to get member names of started tasks via ISFEXEC ST

2017-04-30  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: vtam.rb to retrieve a VTAM member name from D NET,ID=VTAM

2017-04-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: CHANGELOG.md updated

2017-04-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: execute_and_download in zos_ftp.rb so that it refers to the class variable @@syscmd_jcl_erb_filename instead of a local variable syscmd_jcl_erb_filename

2017-04-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: create_release_build.rb so that it includes Excel_write_Pfm.rb in the release build

2017-04-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: SAMPLE/new_form.xlsx updated

2017-04-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: CHANGELOG.md updated

2017-04-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pfm.rb so that it shows on-going status

2017-04-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pfm.rb so that it can perform error handling as well as Excel_write_Pf.rb. It writes the unfinished output to an xlsx file even after an error occurs and save it as another filename if the original file is used.

2017-04-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: RMF.rmf1_parm_dataset and rmf3_parm_dataset so that they return NotActiveNames object instead of not_active_message String if RMF is not acitve

2017-04-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add join method to RMF dataset method in Excel_write_Pf.rb as well as Excel_write_Pfm.rb

2017-04-11  Nobuko Matsuba  <nobuko@jp.ibm.com>

  * Merge branch 'rmf3' into 'master'

2017-04-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: RMF.rmf3 to join dataset members

2017-04-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: DFSORT.iceprm_dataset to use parmlib_names method

2017-04-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add join method to DFSORT.iceprm_dataset in Excel_write_Pfm.rb

2017-04-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: the order of SMS.logr_hlq and SMS.logr_enabled in Excel_write_Pfm.rb

2017-04-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: dump.rb not to add an apostrophe at the beginning of suffix

2017-04-10  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * New: Excel_write_Pfm.rb, which provides the same functions as existing Excel_write_Pf.rb on multiple platforms, such as Windows, Linux, and Mac OS

2017-04-10  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: SMS.hlq to retrieve the first element of the root dataset name as String

2017-03-09  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ParmlibSuffix.idavdt to support MODIFY IDAVDT,READIN=xx

2017-03-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: all files to be speficied with an absolute path to support ocra

2017-03-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ParmlibSuffix.smfprm to support SET SMF command

2017-03-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: IEFSSNxx.params to return a NullDataset object when no INITPARM is found

2017-03-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ParmlibSuffix.hzsprm to retrieve HZS from IEASYSxx when PREV or SYSPARM is specified

2017-03-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ParmlibSuffix.hzsprm to retrieve suffixes correctly when MODIFY ADD,PARMLIB is specified after MODIFY REPLACE,PARMLIB

2017-02-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ceeprm_dataset to use ParmlibSuffix.ceeprm instead of cee

2017-02-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ParmlibSuffix.sms_id to use IEFSSNxx.params method instead of initparm

2017-02-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add set_rmf3_default_suffix method in Suffix class as well as UndefinedSuffix class

2017-02-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ParmlibSuffix.dfhssi in case CICS is defined without an INITPARM

2017-02-12  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ParmlibSuffix.ikjtso

2017-02-12  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ParmlibSuffix.ixgcnf

2017-02-12  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ParmlibSuffix.lnklst

2017-02-12  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: parmlib_suffix.rb to support SET CON=xx

2017-02-12  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: parmlib_suffix.rb to support SET UNI=xx

2017-02-12  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: parmlib_suffix.rb to support SET RTLS=xx

2017-02-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ParmlibSuffix.lpalst

2017-02-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ParmlibSuffix.iggcat

2017-02-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Chagne: ParmlibSuffix.cee to ParmlibSuffix.ceeprm

2017-02-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Chagne: ParmlibSuffix.cea to ParmlibSuffix.ceaprm

2017-02-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: parmlib_suffix.rb to support MODIFY DLF,NN=xx

2017-02-08  Nobuko Matsuba  <nobuko@jp.ibm.com>

  * Change: undefined_suffix.rb to get default ERBRMF04 member for RMF III'

2017-01-26  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: refresh SAMPLE directory

2017-01-26  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: the syslog dataset name of ZOS_env.json.sample to the same name as that of 9.188.252.69

2017-01-26  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to write new_form.xls in the directory_path directory

2017-01-25  Nobuko Matsuba  <nobuko@jp.ibm.com>

  * Change: Excel_write_Pf.rb

2017-01-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: zos_function.readout to return an empty string if the soecified file does not exist

2017-01-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb not to override ZOS_function.syslog_dataset_name

2017-01-24  Nobuko Matsuba  <nobuko@jp.ibm.com>

  * Change: add vtoclist_jcl_filename

2017-01-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ZOS_function.vtoclist_jcl_filename

2017-01-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: vtoclist.jcl.erb to avoid device cancel

2017-01-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: method names in TN3270 to dataset_names and profile_names

2017-01-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: StartedProcedure.jcl_symbol_definitions to get symbols correctly by passing the content

2017-01-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: JES2.procname not to search syslog for JES2 member name

2017-01-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: tn3270.rb to support multiple TN3270 servers. Add profile_content class

2017-01-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add system_symbols.rb to enable StartedProcedure class to interpret system symbols

2017-01-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ParmlibContentFactory.collect_ieasysxx to concatenate the content after removing the comments from the content

2017-01-20  Nobuko Matsuba  <nobuko@jp.ibm.com>

  * Chenage: ieasysxx_content.rb

2017-01-19  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: the indent of OMVS.root_filesystem_name

2017-01-19  Nobuko Matsuba  <nobuko@jp.ibm.com>

  * Change: OMVS.root_filesystem_name

2017-01-19  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ParmlibSuffix.idavdt

2017-01-19  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: download_common to catch FTPPermError that is generated by ftp.ls in case there is an empty PARMLIB dataset

2017-01-19  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: include Excel_write_Pf.rb and syscmd_test.rb in the release instead of *.sample

2017-01-19  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: change unless to if to make the condition clearly understandable

2017-01-19  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: downloaded? to File.exist? in job_log_factory.rb in case force_read is true

2017-01-19  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: syscmd_test.rb. Change it to require the directory_path

2017-01-19  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: rename the file name with size zero to non-exist file name (!). Delete Excel_write_Pf.rb.sample and syscmd_test.rb.sample

2017-01-19  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: update the files in SAMPLE directory

2017-01-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: remove ZOS_env.json from the index of git

2017-01-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: iplparm_names to use IPLPARM.dataset_name instead of obsolete LOADxx.dataset_name. Change local_mode to use the first dataset simply, bypassing the logic to check the local files

2017-01-17  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ParmlibSuffix.dfhssi. Add defined? method to DefinedObject / UndefinedObject class

2017-01-17  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: IODF class. Change method names, from datasets to dataset_name, and from volumes to volume

2017-01-17  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: use %r instead of an escape character to scan the OS type

2017-01-17  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: fix the row position where FTPD parameters are written in Excel_write_Pf.rb

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ParmlibSuffix.grsrnl

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ParmlibSuffix.diag

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ParmlibSuffix.dfhssi

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ParmlibSuffix.devsup

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add config method in ParmlibSuffix class, and add download_list method in ZOS_FTP to enable the tool to get a list of partitioned dataset members

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add cea and cee in ParmlibSuffix class

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add autor in ParmlibSuffix class

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ieasys, ieasym and load in ParmlibSuffix class

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: ieaics, ieaips, ieaopt, iecios, prog and sched to use setcmd in ParmlibSuffix class

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ioeprm to ParmlibSuffix class

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: BPMPRMxx.content to use ParmlibContentFactory.collect

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: CLOCKxx.content to use ParmlibContentFactory.collect

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add CommndxxContent class to remove comments from the LOADxx content

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: use ParmlibContentFactory.collect instead of ParmlibContentFactory.obtain

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: IEASYSxx.content to use ParmlibContentFactory.collect_ieasysxx

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: COMMNDxx.content to use ParmlibContentFactory.collect_commndxx

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add cnidtr, exspat and msgfld in ParmlibSuffix class

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: move all suffix methods in COMMNDxx to ParmlibSuffix class

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: cngrp, mmslst, mpflst and pfktab methods to ParmlibSuffix class

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: CONSOLExx.cnlcccxx_member_names

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: LOADxx. Separate display_ipl_info, member_name and dataset_name methods from content method. Define regexp that is used in LOADxx, in ZOS_function

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: move parmlib_names, sys1_parmlib_names and iplparm_parmlib_names methods to Suffix class

2017-01-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: move all methods to get a suffix in IEASYSxx class to a new ParmlibSuffix class. Add nuclst in ParmlibSuffix

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add prog_suffix, sched_suffix and vatlst_suffix in PARMLIB class

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ieaslp_suffix, iecios_suffix and iefssn_suffix in PARMLIB class

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ieaopt_suffix, ieapak_suffix and ieasvc_suffix in PARMLIB class

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ieaics_suffix, ieaips_suffix in PARMLIB to check if SET command is specified in COMMNDxx.content

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ieaics_suffix, ieaips_suffix and iealpa_suffix in PARMLIB class

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ieaapf_suffix and ieafix_suffix in PARMLIB class

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add exit_suffix and grscnf_suffix in PARMLIB class

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add csvrtl_suffix and cununi_suffix in PARMLIB class

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add couple_suffix in PARMLIB class

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add axr_suffix in PARMLIB class

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add alloc_suffix in PARMLIB class

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: IEASYSxx.system_name to get the system name from &SYSNAME.

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: remove the argument to specify a prefix from ParmlibContentFactory.obtain_ieasysxx

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add antxin00_suffix in PARMLIB class

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add antmin00_suffix in PARMLIB class

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add tsokey00_suffix in PARMLIB class. Remove tsokey00.rb

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ivtprm00_suffix in PARMLIB class

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ieadmr00_suffix in PARMLIB class

2017-01-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ieadmp00_suffix in PARMLIB class

2017-01-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ieacmd00_suffix in PARMLIB class

2017-01-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ieaapp00_suffix in PARMLIB class

2017-01-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ieaabd00_suffix in PARMLIB class

2017-01-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: remove ephwp00 method in PARMLIB class and create a new ephwp00_suffix method that makes use of Suffix class

2017-01-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: PARMLIB class. Create a new method display_parmlib to isolate syscmd_ulog method

2017-01-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: parmlib_names and sys1_parmlib_names to use methods with the same name in DefinedNames class

2017-01-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: CONSOLExx to use add_negative_keywords method for cngrpxx/mmslstxx/mpflstxx methods that return a confusing default value

2017-01-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add_negative_keywords method to Suffix/UndefinedSuffix classes to process confusing default values like NO or ON

2017-01-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: remove parmlib_member_contents method from zos_function.rb and create ParmlibContentFactory.collect method instead

2017-01-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: datasets_member_names to return DefinedNames / UndefinedNames objects

2017-01-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: change all modules except ZOS_FTP, ZOS_function to classes to avoid including several modules

2017-01-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: rename accessed_files method to access_files_output

2017-01-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: procname in vtam.rb and ftpd.rb to set the default procname in case the procedure name can not be found in syslog. And create new class files from ZOS_function.rb.

2017-01-10  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: lib/*.rb to be improved by using rubocop 4.2

2017-01-09  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: move the methods defined for Array in lib/array.rb to DefinedNames / UndefinedNames classes

2017-01-09  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: rename libraries directory to lib directory

2017-01-09  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * New: RDoc documentations

2017-01-09  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: removed the API documentations and developer's guide from README.md

2017-01-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: conso_lxx.rb to use console_suffix common method

2017-01-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: the defaule values of MMSLST, MPFLST and PFKTAB to be NO, NO and NONE respectively

2017-01-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: COMMNDxx.content to insert a new line among the contents of COMMNDxx members and IEACMD00 member

2017-01-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: remove not referenced variables from sub_addr and sub_name in conso_lxx.rb

2017-01-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: ZOS_function.local_mode method for unit tests. If local_mode is true, FTP access is disabled. If the needed file can not be found in the local filesystem, an empty string is returned

2017-01-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: COMMNDxx to add prefix automatically by common methods like parmlib_suffix_setcmd, parmlib_suffix_startcmd and parmlib_suffix_modifycmd

2017-01-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: adyset_suffix in COMMNDxx

2017-01-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: get_suffix_list method to add a prefix automatically and to be moved to DefinedObject class

2017-01-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: cngrp, mmslst, mpflst and pfktab suffix methods in CONSOLExx to set a prefix by using add_prefix method

2017-01-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: CommndxxContent class, which overrides remove_comments method and retrieves the command enclosed in single quotation marks to simplify regular expressions

2017-01-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: COMMNDxx to implement APPCPM,ASCHPM,COFDLF,COFVLF,CSVLLA,HZSPRM,IEADMC and XCFPOL methods separately to return appropriate default values

2017-01-04  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: parmlib_names and sys1_parmlib_names methods to DefinedNames/UndefinedNames classes

2017-01-04  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to call join method after CONSOLxx.master_xxxx and sub_xxxx methods

2017-01-04  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: cnlcccxx_member_names in conso_lxx.rb to return a DefinedNames object instead of Array

2017-01-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: scan_devnum_name_auth in conso_lxx.rb to collect a sub console whose AUTH includes commas like SYS,IO,CONS. Change master_xxxx and sub_xxxx methods to return a DefinedNames object instead of String.

2017-01-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: download method in zos_ftp.rb to log the dataset name when a connection error occurs

2017-01-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: pfktabxx_suffix method in CONSOLxx to check COMMNDxx. Change cngrpxx_suffix to return a Suffix object for the default value NO instead of String

2017-01-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: cngrpxx_suffix method in CONSOLxx to check COMMNDxx and to return the default value NO if no CNGRP is specified

2017-01-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: replace find method in DefinedObject and UndefinedObject with scan method

2017-01-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: DefinedObject class to reuse the same scan method

2017-01-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: DefinedObjectMethods and UndefinedObjectMethods replaced with DefinedObject and UndefinedObject classes that inherit from String

2017-01-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: cnlsssxx_member_names to return an empty array immediately if no MMSLSTxx suffix exists

2017-01-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to omit an argument of the join method because TCPIP methods return DefinedNames or UndefinedNames objects.

2017-01-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: tcpip.rb to return DefinedNames or UndefinedNames objects instead of Array objects

2017-01-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: accessed_files to count up if not_exist? method is called.

2017-01-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: accessed_files method in zos_function.rb to show the list of accessed files for debug purpose

2017-01-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: JobLogFactory to use downloaded? and readout methods

2017-01-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: TCPIP.dataset_names to return a flatten array

2017-01-01  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: defined_names and undefined_names classes. Change: tcpip.rb to use the new classes

2016-12-31  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: substitution_text_regexp to remove a reluctant quantifier from the pattern with no brackets or apostrophes

2016-12-31  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: zos_function.rb. Separate Suffix and UndefinedSuffix classes from it

2016-12-31  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: attach_prefix method added to Suffix class. Fix ioeprmxx_suffix to return Suffix instance. Fix TCPIP.tcpdata to define a procedure local variable again

2016-12-31  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: datasets_member_names method added to allow multiple member names to be specified

2016-12-26  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to recognize the secondary argument as syslog dataset name

2016-12-26  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: cnlcccxx_member_names to return an empty array instead of undefined_message to avoid searching parmlib datasets with a member name that is undefined_message. Add join_array(array) to return an undefined_message when the array is empty

2016-12-26  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: substitution_text_regexp to include reluctant quantifiers in order to retrieve a substitution text within matched parentheses correctly

2016-12-26  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: start_procedure to started_procedure

2016-12-26  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: zos_function.rb. Separate StartProcedure and NullStartProcedure classes from it for rspec to work properly

2016-12-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: zos_function.rb. Separate DefinedObjectMethods and UndefinedObjectMethods modules from it

2016-12-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ZOS_function::use_jcl_symbols to get a substitution text correctly by using a common method for PROC, EXEC and SET

2016-12-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to search only SYS1.PARMLIB for CNLcccxx instead of PARMLIB datasets

2016-12-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to specify only prefix when searching syslog for IEAABD00, IEAAPP00, IEACMD00, IEADMP00, IEADMR00, IVTPRM00, and TSOKEY00

2016-12-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: cnlcccxx_suffix to cnlcccxx_member_names to return config parameters as an array

2016-12-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: directory_path method to avoid an undefined method error when ZOS_env.json has no entry for specified directory_path

2016-12-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ftpd.rb and tn3270.rb to support multiple TCPIP stacks, and changed the layout of 2-2 PARMLIB customized parameters to show actually indicated dataset names instead of specified suffixes

2016-12-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: support multiple TCPIP stacks

2016-12-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to write information on all PAGE LOCAL datasets in Excel by connecting with a slash

2016-12-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: bpxpr_mxx.rb to use suffix_regexp to retrieve IOEPRMxx suffix from the content of BPXPRMxx

2016-12-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: smf_datasets to use syscmd_ulog method instead of syscmd method

2016-12-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: commn_dxx.rb to retrieve suffix only when the line is not commented out

2016-12-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: commn_dxx.rb to use suffix_regexp to retrieve suffix from the content of COMMNDxx

2016-12-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to turn off SheetChange event before saving the file to avoid Excel hang issue

2016-12-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Suffix class to use suffix_regexp to retrieve suffix from a given suffix string

2016-12-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to put non_supported_message in blank cells in UNIX, TCPIP and SDSF configuration sections

2016-12-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: zOS_pf(full).xls to format all cells as Text

2016-12-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: scan_required_message method removed from ZOS_function.rb, haspace.rb, haspckp2.rb, haspckpt.rb, logrec.rb and omvs.rb

2016-12-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: scan_required_volser_hyphen method removed from ZOS_function.rb, dump.rb, haspace.rb, logrec.rb, omvs.rb, pagecommon.rb, pagelocal.rb, pageplpa.rb, sms.rb, stgindex.rb and ucat.rb

2016-12-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: haspace.rb haspckp2.rb haspckpt.rb pagecommon.rb pageplpa.rb from required_message to undefined_message

2016-12-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: uads.rb to return undefined_messages instead of required_message

2016-12-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: dump.rb from required_message to undefined_message

2016-12-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Chagne: Excel_write_Pf.rb to copy all the current values to columns of specified values. If the current value is non_supported_message, required_messages is written in the specified value column

2016-12-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: special_value? in zos_function to return true if non_supported_message is specified

2016-12-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add a non_supported_message method, which is used in case the tool does not support the specified value

2016-12-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to adjust the row height automatically to show all of the current values

2016-12-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: zOS_pf(full).xls to add a column for current values

2016-12-05  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Merge branch 'master' of github.rtp.raleigh.ibm.com:DSHIMIZU-jp/zOS_common_library

2016-12-05  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: use_jcl_symbols in StartProcedure class to support a pair of parentheses

2016-12-05  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: use_jcl_symbols in StartProcedure to accept an empty value and support an optional period at the end of JCL symbols

2016-12-05  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: conso_lxx.rb to retrieve MMS and MPF suffixes from COMMNDxx besides CONSOLxx

2016-12-05  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to fill in SDSF parameters in the excel

2016-12-05  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: sdsf.rb to retrieve SDSF parameters

2016-12-05  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: jes2.rb to override JCL symbols

2016-12-05  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: StartProcedure class to override JCL symbols

2016-12-04  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: omvs.rb to retrive the root filesystem name from BPXPRMxx if D OMVS,F can not be executed

2016-12-04  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to save new_form.xls as a new file name when the file is in use by another process like Excel

2016-12-04  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: OMVS.root_entries_name and SMS.root_filesystem_name to call the same method, OMVS.root_filesystem_name

2016-12-04  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb and omvs.rb to retrieve OMVS filesystem type/dsn/volser

2016-12-04  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to retrive master catalog information

2016-11-29  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: TN3270.portno to return not_found_message when no TCPIP procname is written in syslog

2016-11-29  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: TN3270.portno to return not_found_message with no TCPIP procname is written in syslog

2016-11-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: syscmd.jcl.erb to shorten waiting time for GETMSG

2016-11-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: syscmd_test to make use of force_read

2016-11-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add ZOS_function.syscmd_method method so that users can select syscmd or syscmd_ulog method

2016-11-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add syscmd_test.rb for users to test syscmd and syscmd_ulog methods in advance

2016-11-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: File.open().read to File.read() to explicitly close files

2016-11-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ulog_console_name to console_name

2016-11-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: vtam.rb to retrieve suffixes separated by commas

2016-11-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add suffix_regexp regular expression to retrieve a suffix from logs or datasets

2016-11-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: syscmd method in zos_ftp.rb so that it can retrieve lines that start with a non-blank

2016-11-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb so that it can get ZOS_function.directory_path from ARGV

2016-11-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: syscmd method to make use of Rexx GETMSG so that it can retrieve console messages that are not displayed at the terminal during a console session

2016-11-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: syscmd() to use JobLogFactory.create() instead of readout()

2016-11-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: CREDITS_cp932.txt

2016-11-21  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: remove white space from the end of line in CHANGELOG.md

2016-11-21  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: create_release_build.rb to update CHANGELOG.md

2016-11-21  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: conso_lxx.rb to convert mmslstxx_suffix to string

2016-11-21  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: dump.rb to replace .volser_hyphen_scan with .scan_required_volser_hyphen

2016-11-21  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: CHANGELOG.md to be updated

2016-11-21  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: replace add_path public method with add_path private method in zos_ftp.rb not to reopen Ruby String class

2016-11-21  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: .gitignore to ignore backup files and directories

2016-11-21  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: create_release_build.rb to include syscmd.ulog.jcl.erb and vtoclist.jcl.erb

2016-11-21  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: delete BOM from LICENSE.txt

2016-11-21  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb not to execute workbook.SaveAs if an error occurs before workbook is initialized

2016-11-21  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to maximize the excel window

2016-11-20  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: create_release_build.rb to create a release build

2016-11-20  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: Excel_write_Pf.rb.sample for a release build

2016-11-20  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: SAMPLE directory

2016-11-20  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: ZOS_env.json.sample

2016-11-20  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: LICENSE.txt

2016-11-20  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: tsokey00 to get tsokey from parmlib besides syslog

2016-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: support ZOS_env.json with Byte Order Mark

2016-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: dataset_member_regexp created to match dataset member names including a symbol that starts with &

2016-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * New: ulog console name can be specified in ZOS_env.json

2016-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ftp_ipaddress, ftp_userid and ftp_password methods in ZOS_function removed because the same methods are defined in ZOS_FTP

2016-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: reset SYSLOG dataset name and SMP/E Global CSI dataset name when directory_path is changed

2016-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: scan_suffix in UndefinedObjectMethods to return UnfinedSuffix

2016-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: inspect method in UndefinedObjectMethods

2016-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: inspect method in DefinedObjectMethods

2016-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add an inspect method to DefinedObjectMethods to get puts methods obtain the content of objects

2016-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: return EmptyJoblog if syslog_dataset_name is not specified

2016-11-04  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: ieasy_sxx.rb to get sysname from syslog when no sysname is defined in IEASYSxx

2016-11-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: vtoclist.jcl.erb to avoid 'unable to allocate' error

2016-11-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: ucat.rb to return correct messages when a job fails

2016-11-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: system_dataset.rb when a job failed

2016-11-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: define add_path as a private method in zos_function

2016-11-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: add_absolute_path removed from String class

2016-11-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * New: undefined class to simplify error handling

2016-10-17  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: Excel_write_Pf.rb to support new libraries

2016-10-17  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: split PARMLIB modules into each module in README.md

2016-10-17  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * New: Rails support. Split ZOS_PARMLIB to each module.

2016-10-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: some directories under test

2016-07-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: IEFSSNxx.content to support multiple suffixes

2016-07-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: sysplexcds_itemname when D XCF,COUPLE,TYPE=SYSPLEX is nil

2016-07-15  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: the default message of COUPLE class from required_message to undefined_message

2016-07-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: sysplexcds_itemname to return undefined_message when Sysplex CDS is not defined and to cut unnecessary apostrophes

2016-07-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: wlmcds_itemname to cut unnecessary apostrophes

2016-07-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: loggercds_itemname to return undefined_message when LOGR is not defined

2016-07-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: LOADxx to return undefined_message when sysplex_name is not defined

2016-07-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: use_symbols when dynamic symbols are used

2016-07-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * New: support substrings of system symbols

2016-07-04  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: multiple suffixes and add set_default_suffix/split_suffix

2016-07-04  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: IEASYMxx, MSTJCLxx, COMMNDxx, SMFPRMxx, CLOCKxx to support multiple suffixes

2016-07-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Improve: exclude_suffix argument of get_suffix_list

2016-07-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: IEASYS methods to support multiple suffixes

2016-07-03  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: support multiple IEASYS suffixes

2016-06-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: delete BOM from CHANGELOG.md

2016-06-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: CHANGELOG.md

2016-06-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: ftp.passive = false to support Ruby 2.3

2016-04-12  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: CONSOLxx.master_addr and master_name to retrieve NAME and AUTH correctly when they are in reverse order or when AUTH is omitted

2016-04-11  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: CONSOLxx.master_addr and master_name to retrieve hexadecimal digits correctly

2016-02-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: HASP* to return required message when HASP dataset is not found

2016-02-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: JES2.procname to return default procname when HASP426 is not found

2016-02-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: HASPACE/HASPCKPT/HASPCKP2 to return undefined message when HASP dataset does not exist

2016-02-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: ieasys/ieasym_suffix to retrieve correct suffix when it is enclosed in parentheses

2016-02-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: SMPE methods to return undefined_message when SMP/E Global CSI is not defined

2016-02-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: force to use syscmd_ulog instead of syscmd to prevent failure to capture the output of system commands

2016-02-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: ftp.get to retry retrieving the job log until it is generated

2015-12-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: logging function to write log to both log.txt and standard output

2015-12-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: add_absolute_path for ocra to access files in the current directory

2015-12-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: volser regexp in SMF class

2015-12-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: volser regular expression

2015-12-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: customized job statements for various environments

2015-12-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: RACFPREFIX.name to get RACF prefix from IEFSSNxx when D O returns no RACF prefix

2015-11-30  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: parmlib_suffix_dataset_name to compact nil when no adequate dataset exists

2015-11-29  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Merge branch 'master' of github.rtp.raleigh.ibm.com:DSHIMIZU-jp/zOS_common_library

2015-11-28  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: get PARMLIB dataset name with the suffix described in IEASYSxx

2015-11-28  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: add_path to replace forbidden filename characters with a underline

2015-11-28  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: add_path to replace forbidden filename characters with a underline

2015-11-28  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: get_resolver_config to get correct TCPIP.DATA

2015-11-28  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: test case numbers for minitest

2015-11-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: UCAT methods

2015-11-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: change multiple_address_expression to a method for Array class

2015-11-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: multiple_address_expression

2015-11-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Change: RACF PREFIX to use command_prefix method

2015-11-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: system_name and sid in case they include non-alphanumeric characters

2015-11-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: LOGREC method when no DD definition exists

2015-11-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: UADS method when no DD definition exists

2015-11-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: readout to scrub in case invalid characters are included

2015-11-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: use_symbols to support symbols omitting the period

2015-11-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: logic to check status in submit_jcl_store_joblog

2015-11-09  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: json file for environment variables

2015-11-09  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: minitest to handle multiple test cases, and ZOS_http to generate html file from stored test data

2015-11-08  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: TCPIP class to retrieve the content of arrays

2015-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: CONSOLxx.stpmode when STPMODE is not defined

2015-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: clock_suffix when clockxx is not defined

2015-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: .gitignore to ignore temporary files

2015-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: CONSOLxx.sub_* to return undefined_message when no sub console is defined

2015-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: TCPIP, TN3270 and FTPD classes

2015-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: OMVS.superuser

2015-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: methods to return console name and addr in CONSOLExx

2015-11-07  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: index.erb to display correct section name

2015-11-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: provide index.erb to convert Excel writer program to html

2015-10-28  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: CLAB test cases

2015-10-28  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: remove class variables for minitest to support multiple environments

2015-10-27  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: SMS.logstream to obtain stream names correctly

2015-10-27  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: stream_name when logr_hlq is empty

2015-10-27  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: remove iodf_address display logic

2015-10-27  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: adjust minitest.rb.erb

2015-10-27  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: minitest case generator and dcs3 environment

2015-10-27  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: change the color of minitest output

2015-10-27  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: PAGELOCAL.volumes error when it is called first

2015-10-26  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: change SYSLOG.dataset to allow read access

2015-10-26  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: JES2.mode when JES2 checkpoint level is z/OS 1.2

2015-10-26  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: SMS.logr_* methods to simply arguments

2015-10-26  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: RACK.racfback_* when the primary volume is not shared

2015-10-26  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: IODF.volumes to support z/OS V1R10 format of IODF DEVICE

2015-10-26  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: STGINDEX when ILR026I does not exist in SYSLOG

2015-10-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: SMS.logstream when neither begining nor end of logstream name matches OPERLOG/LOGREC

2015-10-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: change SMF.size not to use double byte string

2015-10-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: test cases for IPLPARM and SMF

2015-10-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: record non-existent datasets after having '!' as a prefix

2015-10-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: rename exit methods to exists

2015-10-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: adjust indents and remove unneeded comments

2015-10-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: decapitalize all method names in ZOS_PARMLIB

2015-10-21  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: change SMS.sms to SMS.enabled

2015-10-21  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: replace JES2_procname with JES2.procname in JES2_HASPPARM, and change default_value_messages to undefined_messages

2015-10-21  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: scan correct STRUCTURE names for LOGSTREAM when DASDONLY

2015-10-19  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: icetool.jcl.erb

2015-10-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: replace \t in ZOS_login.rb with two spaces

2015-10-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: adjust indents

2015-10-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: replace \t with two spaces

2015-10-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: SMF.volumes to retrieve only three values from SMF volume array

2015-10-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: FTP routines in ZOS_FTP into ftp_common method

2015-10-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: success? method when the JOB LOG does not exist

2015-10-18  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: submit_and_store method to submit a JCL and store the JOG LOG to a dataset

2015-10-17  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: store local files in different directories

2015-10-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: decapitalize VTAM methods

2015-10-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: change STRUCTURE to STRUCTNAME

2015-10-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: decapitalize SMS methods

2015-10-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: HASPCKP2 equal logic

2015-10-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: dataset methods

2015-10-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: LE class

2015-10-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: DFSORT class

2015-10-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: PAGEPLPA/PAGECOMMON/PAGELOCAL classes

2015-10-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: HASPACE/HASPCKPT/HASPCKP2 classes

2015-10-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: SRGINDEX class

2015-10-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: Merge SMS2 class into SMS class

2015-10-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: decapitalize RACF method names

2015-10-16  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Refactor: Merge SMF2 class into SMF class

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: RACF class

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: RACFPREFIX class

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: COUPLE class

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: IODF class

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: LOGREC class

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: DUMP class

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: BROADCAST class

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: SMF2 and UADS classes

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: IPLPARM.RELEASE

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: listdddef.jcl.erb

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: listlogr.jcl.erb

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: SMPE class

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: SMS class

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: JES2 mode/exit5 methods

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: undefined method use_symbols when all BPXPRMxx are empty for a suffix

2015-10-14  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: bypass searching members if the suffix is undefined

2015-10-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Modify: PARMLIB/CONSOL_suffix in IEASYSxx class to use the ternary operator

2015-10-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: default value message

2015-10-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Remove: LOAD/IEASYS_suffix_string in IPLPARM class

2015-10-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: dataset_name related methods in VTAM class

2015-10-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: dataset_name method in JES2 class

2015-10-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: CONSOLxx/CUNUNIxx/IEFSSNxx/BPXPRMxx/IOEPRMxx/LOADxx classes

2015-10-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: PARMLIB_suffix_*/IEADMCxx/IPCSPRnn/XCFPOLxx in COMMNDxx

2015-10-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: PARMLIB/CONSOLxx method in IEASYSxx

2015-10-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: EPHWP00/IDAVDTxx

2015-10-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: PARMLIB datasets methods

2015-10-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: find LOAD/IEASYS suffix

2015-10-13  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: search syslog function

2015-10-09  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: command_prefix

2015-10-09  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: support symbols in SMFPRMxx and CLOCKxx

2015-10-09  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: RMF I/III

2015-10-09  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: support symbols in MSTJCLxx and COMMNDxx

2015-10-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: use_symbols

2015-10-06  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: dataset_size_vsam

2015-10-05  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: support basic configuration

2015-10-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: set console name

2015-10-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: cut 43 column and after of joblog in syscmd_ulog

2015-10-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * New: parse parameters included in URL

2015-10-02  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: change ISFOUT to DD DUMMY

2015-10-01  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: required message

2015-10-01  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add: undefined message

2015-10-01  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: %SP = ? not working

2015-10-01  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Update: change default value from DCS1 to DCS3 in ZOS_login

2015-10-01  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Update: change dataset_size to dataset_list and implement new dataset_size in SYSTEM_DATASET

2015-10-01  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Add : RMF and OMVS class

2015-10-01  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Update : SET DELAY for ULOG

2015-10-01  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Update : add </pre> tag only if the content has multiple lines

2015-09-30  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * New: ZOS_http to provide REST API for ZOS_PARMLIB

2015-09-30  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix: change ULOG output dataset from ISFOUT to OUTLOG to retrive D OMVS,F correctly

2015-09-30  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Update : convert charactor encoding from Shift-JIS to UTF-8

2015-09-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * New : syscmd_ulog in ZOS_function

2015-09-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Update: datasets_member_name in ZOS_function in README.md

2015-09-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * New: datasets_member_name in ZOS_function

2015-09-25  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix : @content to content in JES2.PROC00_dataset

2015-09-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Update: New lines in README.md

2015-09-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Update: ZOS_function and ZOS_FTP in README.md

2015-09-24  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Update: ZOS_function and ZOS_FTP in README.md

2015-09-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Update: SYSTEM_DATASET in README.md

2015-09-23  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * New: SYSTEM_DATASET dataset_size method

2015-09-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix : change the SMF.datasets method to SMF.smf_datasets in README.md

2015-09-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * Fix : password and syslog labels in ZOS_login

2015-09-22  Daiki Shimizu  <dshimizu@jp.ibm.com>

  * first commit
