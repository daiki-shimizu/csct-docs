require_relative 'lib/zos_ftp'
require_relative 'lib/zos_function'
Dir[File.expand_path('..', __FILE__) << '/lib/*.rb'].each do |library|
  require library
end
include ZOS_FTP, ZOS_function

ZOS_function.directory_path = ARGV.empty? ? 'SAMPLE' : ARGV[0]
ZOS_function.force_read = true

jobname =
  if userid.length < 8
    userid + '1'
  else
    userid
  end

command = "$PJOBQ,JOBMASK=#{jobname}"

puts "Purging all the jobs whose job name matches #{jobname}"
syscmd(command, no_joblog: true)
File.delete(add_path(command)) if File.exist?(add_path(command))
