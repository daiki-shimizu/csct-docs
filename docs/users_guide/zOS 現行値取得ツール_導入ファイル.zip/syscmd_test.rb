#! ruby -Ku
require_relative 'lib/zos_ftp'
require_relative 'lib/zos_function'
Dir[File.expand_path('..', __FILE__) << '/lib/*.rb'].each do |library|
  require library
end
include ZOS_FTP, ZOS_function

if ARGV.empty?
  puts 'Please specify the directory name'
  exit
end

ZOS_function.directory_path = ARGV[0]
ZOS_function.force_read = true
system_command = 'D IKJTSO,SEND'

puts 'Please check each output of an system command is as expected'
puts "system command = #{system_command}"
puts

if ZOS_function.syscmd_method
  puts "When syscmd method is specified #{ZOS_function.syscmd_method}"
  puts '----------------------------------------------'
  puts syscmd_ulog(system_command)
  puts '----------------------------------------------'
  exit
end

puts 'When syscmd method is Rexx GETMSG'
puts '----------------------------------------------'
ZOS_function.syscmd_method = 'GETMSG'
puts syscmd_ulog(system_command)

puts '----------------------------------------------'
puts
puts 'When syscmd_ulog method is SDSF ISFEXEC'
puts '----------------------------------------------'

ZOS_function.syscmd_method = 'ISFEXEC'
puts syscmd_ulog(system_command)

puts '----------------------------------------------'
puts
puts 'When syscmd_ulog method is SDSF ULOG'
puts '----------------------------------------------'

ZOS_function.syscmd_method = 'ULOG'
puts syscmd_ulog(system_command)

puts '----------------------------------------------'
