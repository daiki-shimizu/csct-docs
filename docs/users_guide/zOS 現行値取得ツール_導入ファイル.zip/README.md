z/OS common library for smART
=====================
This common library is designed to provide standard functions for developers who belong to smART in GTS Japan. Use this library to automate the following daily tasks.

   - Download the contents of datasets and members.
   - Identify suffixes that are specified in PARMLIB members. 
   - Retrieve concatenated datasets from the content of the procedure.
   - Submit a JCL and download the job log.
   - Execute an MVS system command and download the output. 

 
Requirements
----------------
You have to have Ruby for Windows installed in your machine. The following versions of Ruby for Windows are tested.

- Ruby 2.2.3
- Ruby 2.2.4
- Ruby 2.3.0

If you want to use SSH connection instead of FTP, install net-ssh and net-scp ruby gems.


```
> gem install net-ssh net-scp
```


Platforms
---------
This library has been tested in the following environment.

   - Windows 7
   - RubyInstaller for Windows


Preparations
-------
You should prepare for connecting to the target z/OS (such as completing your BFS authentication). And you should have FTP login information (IP address, UserID and Password) and the location of SYSLOG dataset.  

You can use ZOS_env.json file to pass the environment parameters to the tool easily. When you put the following file in the same folder, all you have to do is to specify ZOS_function.directory_path. The tool automatically reads all relevant environment variables when ZOS_function.directory_path is set.

ZOS_env.json
```json
{
   "SAMPLE": [
    "ZOS_FTP.ipaddress = 'IP ADDRESS'",
    "ZOS_FTP.userid = 'USERID'",
    "ZOS_FTP.password = 'PASSWORD'",
    "ZOS_FTP.job_statements_jcl_filename = 'job_statements_jcl.erb'",
    "ZOS_function.syslog_dataset_name = 'SYSLOG.D150702'",
    "ZOS_function.smp_global_csi_dataset_name = 'SMPE.GLOBAL.CSI'"
  ]
}
```

Usage
-------
You can use Excel_write_Pf.rb that collects current settings from the target z/OS by using this tool and writes them into an Excel file. Open Windows Command Prompt and execute the sample program with the value of ZOS_function.directory_path.

```
> ruby Excel_write_Pf.rb SAMPLE
```


Environment parameters
-------------------------
You can specify two types of environment parameters in ZOS_env.json file.

- Environment variables provided by ZOS_ftp module, which are required when FTP access is needed.
- Environment variables provided by ZOS_funtion module


Environment variables provided by ZOS_FTP module:

- `ZOS_FTP.ipaddress = ipaddress`

  Used to declare an IP address of the target z/OS to. `ipaddress` is the IP address or host name. This must be set when the tool collect necessary information from the target z/OS.


- `ZOS_FTP.userid = userid`

  Used to declare a UserID for FTP access. `userid` is the UserID. This must be set for FTP access to the target z/OS.


- `ZOS_FTP.password = password`

  Used to declare a password for FTP access. `password` is a password of the UserID. This must be set for FTP access to the target z/OS.


Environment variables provided by ZOS_funtion moudle:

- `ZOS_function.directory_path = path`

  Specifies a relative directory_path where to read or write files. This is a mandatory parameter and must be set first because other parameters are initialized when this is set.


- `ZOS_function.syslog_dataset_name = dataset_name`

  Specifies a dataset that contains SYSLOG at z/OS IPL. If omitted, the default dataset name is 'SYSLOG'.


- `ZOS_function.smp_global_csi_dataset_name`

  Specify an SMP/E Global CSI dataset.


- `ZOS_function.force_read = boolean`

  Used to declare whether "on demand loading" should be disabled or not.  If `boolean` is  set to true, "on demand loading" becomes disabled. Default is false. Use it for developing or debugging. 


- `ZOS_function.local_mode = boolean`

  If `boolean` is  set to true, the tool uses only downloaded files and is prevented from accessing the target z/OS. The default value is false. Use it for debugging or unit test use.


Methods
----------
See RDoc documentations in the [doc directory](doc\index.html).


Developing
----------
If you're interested in contributing to this project, please contact the authors.


License and Authors
---------------------
Author:: Daiki Shimizu [dshimizu@jp.ibm.com](mailto:dshimizu@jp.ibm.com)